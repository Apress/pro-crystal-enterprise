namespace CrystalReportsViewer
{
    partial class frmCrystalReportViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.cmdChangeDataSourceForReport = new System.Windows.Forms.Button();
            this.cmdRunFromCrystalReportsWebService = new System.Windows.Forms.Button();
            this.cmdRunFromUnmanagedRAS = new System.Windows.Forms.Button();
            this.cmdChangeViewerSettings = new System.Windows.Forms.Button();
            this.cmdSetParametersForReportOnDisk = new System.Windows.Forms.Button();
            this.cmdRunFromCrystalReportsWebServiceAsmx = new System.Windows.Forms.Button();
            this.cmdSetCustomDataSource = new System.Windows.Forms.Button();
            this.cmdExportReportStructureXML = new System.Windows.Forms.Button();
            this.cmdRunFromBOServer = new System.Windows.Forms.Button();
            this.xlsIOConfig1 = new Syncfusion.XlsIO.XlsIOConfig();
            this.SuspendLayout();
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Location = new System.Drawing.Point(0, 0);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new System.Drawing.Size(688, 576);
            this.crystalReportViewer1.TabIndex = 0;
            this.crystalReportViewer1.Load += new System.EventHandler(this.crystalReportViewer1_Load);
            // 
            // cmdChangeDataSourceForReport
            // 
            this.cmdChangeDataSourceForReport.Location = new System.Drawing.Point(696, 168);
            this.cmdChangeDataSourceForReport.Name = "cmdChangeDataSourceForReport";
            this.cmdChangeDataSourceForReport.Size = new System.Drawing.Size(256, 23);
            this.cmdChangeDataSourceForReport.TabIndex = 2;
            this.cmdChangeDataSourceForReport.Text = "Change DataSource for Report on Disk";
            this.cmdChangeDataSourceForReport.UseVisualStyleBackColor = true;
            this.cmdChangeDataSourceForReport.Click += new System.EventHandler(this.cmdChangeDataSourceForReport_Click);
            // 
            // cmdRunFromCrystalReportsWebService
            // 
            this.cmdRunFromCrystalReportsWebService.Location = new System.Drawing.Point(696, 40);
            this.cmdRunFromCrystalReportsWebService.Name = "cmdRunFromCrystalReportsWebService";
            this.cmdRunFromCrystalReportsWebService.Size = new System.Drawing.Size(256, 23);
            this.cmdRunFromCrystalReportsWebService.TabIndex = 3;
            this.cmdRunFromCrystalReportsWebService.Text = "Run From Crystal Reports Web Service (Object)";
            this.cmdRunFromCrystalReportsWebService.UseVisualStyleBackColor = true;
            this.cmdRunFromCrystalReportsWebService.Click += new System.EventHandler(this.cmdRunFromCrystalReportsWebService_Click);
            // 
            // cmdRunFromUnmanagedRAS
            // 
            this.cmdRunFromUnmanagedRAS.Location = new System.Drawing.Point(696, 104);
            this.cmdRunFromUnmanagedRAS.Name = "cmdRunFromUnmanagedRAS";
            this.cmdRunFromUnmanagedRAS.Size = new System.Drawing.Size(256, 23);
            this.cmdRunFromUnmanagedRAS.TabIndex = 4;
            this.cmdRunFromUnmanagedRAS.Text = "Run From Unmanaged RAS";
            this.cmdRunFromUnmanagedRAS.UseVisualStyleBackColor = true;
            this.cmdRunFromUnmanagedRAS.Click += new System.EventHandler(this.cmdRunFromUnmanagedRAS_Click);
            // 
            // cmdChangeViewerSettings
            // 
            this.cmdChangeViewerSettings.Location = new System.Drawing.Point(696, 264);
            this.cmdChangeViewerSettings.Name = "cmdChangeViewerSettings";
            this.cmdChangeViewerSettings.Size = new System.Drawing.Size(256, 23);
            this.cmdChangeViewerSettings.TabIndex = 5;
            this.cmdChangeViewerSettings.Text = "Change Viewer Settings";
            this.cmdChangeViewerSettings.UseVisualStyleBackColor = true;
            this.cmdChangeViewerSettings.Click += new System.EventHandler(this.cmdChangeViewerSettings_Click);
            // 
            // cmdSetParametersForReportOnDisk
            // 
            this.cmdSetParametersForReportOnDisk.Location = new System.Drawing.Point(696, 136);
            this.cmdSetParametersForReportOnDisk.Name = "cmdSetParametersForReportOnDisk";
            this.cmdSetParametersForReportOnDisk.Size = new System.Drawing.Size(256, 23);
            this.cmdSetParametersForReportOnDisk.TabIndex = 6;
            this.cmdSetParametersForReportOnDisk.Text = "Set Parameters For Report On Disk";
            this.cmdSetParametersForReportOnDisk.UseVisualStyleBackColor = true;
            this.cmdSetParametersForReportOnDisk.Click += new System.EventHandler(this.cmdSetParametersForReportOnDisk_Click);
            // 
            // cmdRunFromCrystalReportsWebServiceAsmx
            // 
            this.cmdRunFromCrystalReportsWebServiceAsmx.Location = new System.Drawing.Point(696, 72);
            this.cmdRunFromCrystalReportsWebServiceAsmx.Name = "cmdRunFromCrystalReportsWebServiceAsmx";
            this.cmdRunFromCrystalReportsWebServiceAsmx.Size = new System.Drawing.Size(256, 23);
            this.cmdRunFromCrystalReportsWebServiceAsmx.TabIndex = 7;
            this.cmdRunFromCrystalReportsWebServiceAsmx.Text = "Run From Crystal Reports Web Service (asmx)";
            this.cmdRunFromCrystalReportsWebServiceAsmx.UseVisualStyleBackColor = true;
            this.cmdRunFromCrystalReportsWebServiceAsmx.Click += new System.EventHandler(this.cmdRunFromCrystalReportsWebServiceAsmx_Click);
            // 
            // cmdSetCustomDataSource
            // 
            this.cmdSetCustomDataSource.Location = new System.Drawing.Point(696, 200);
            this.cmdSetCustomDataSource.Name = "cmdSetCustomDataSource";
            this.cmdSetCustomDataSource.Size = new System.Drawing.Size(256, 23);
            this.cmdSetCustomDataSource.TabIndex = 8;
            this.cmdSetCustomDataSource.Text = "Set Custom Data Source";
            this.cmdSetCustomDataSource.UseVisualStyleBackColor = true;
            this.cmdSetCustomDataSource.Click += new System.EventHandler(this.cmdSetCustomDataSource_Click);
            // 
            // cmdExportReportStructureXML
            // 
            this.cmdExportReportStructureXML.Location = new System.Drawing.Point(696, 232);
            this.cmdExportReportStructureXML.Name = "cmdExportReportStructureXML";
            this.cmdExportReportStructureXML.Size = new System.Drawing.Size(256, 23);
            this.cmdExportReportStructureXML.TabIndex = 9;
            this.cmdExportReportStructureXML.Text = "Export Report Structure XML";
            this.cmdExportReportStructureXML.UseVisualStyleBackColor = true;
            this.cmdExportReportStructureXML.Click += new System.EventHandler(this.cmdExportReportStructureXML_Click);
            // 
            // cmdRunFromBOServer
            // 
            this.cmdRunFromBOServer.Location = new System.Drawing.Point(696, 8);
            this.cmdRunFromBOServer.Name = "cmdRunFromBOServer";
            this.cmdRunFromBOServer.Size = new System.Drawing.Size(256, 23);
            this.cmdRunFromBOServer.TabIndex = 10;
            this.cmdRunFromBOServer.Text = "Run From BusinessObjects Server";
            this.cmdRunFromBOServer.UseVisualStyleBackColor = true;
            this.cmdRunFromBOServer.Click += new System.EventHandler(this.cmdRunFromBOServer_Click);
            // 
            // frmCrystalReportViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 574);
            this.Controls.Add(this.cmdRunFromBOServer);
            this.Controls.Add(this.cmdExportReportStructureXML);
            this.Controls.Add(this.cmdSetCustomDataSource);
            this.Controls.Add(this.cmdRunFromCrystalReportsWebServiceAsmx);
            this.Controls.Add(this.cmdSetParametersForReportOnDisk);
            this.Controls.Add(this.cmdChangeViewerSettings);
            this.Controls.Add(this.cmdRunFromUnmanagedRAS);
            this.Controls.Add(this.cmdRunFromCrystalReportsWebService);
            this.Controls.Add(this.cmdChangeDataSourceForReport);
            this.Controls.Add(this.crystalReportViewer1);
            this.Name = "frmCrystalReportViewer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Crystal Report Viewer";
            this.Load += new System.EventHandler(this.frmCrystalReportViewer_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
        private System.Windows.Forms.Button cmdChangeDataSourceForReport;
        private System.Windows.Forms.Button cmdRunFromCrystalReportsWebService;
        private System.Windows.Forms.Button cmdRunFromUnmanagedRAS;
        private System.Windows.Forms.Button cmdChangeViewerSettings;
        private System.Windows.Forms.Button cmdSetParametersForReportOnDisk;
        private System.Windows.Forms.Button cmdRunFromCrystalReportsWebServiceAsmx;
        private System.Windows.Forms.Button cmdSetCustomDataSource;
        private System.Windows.Forms.Button cmdExportReportStructureXML;
        private System.Windows.Forms.Button cmdRunFromBOServer;
        private Syncfusion.XlsIO.XlsIOConfig xlsIOConfig1;
    }
}

