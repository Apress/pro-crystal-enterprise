using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using CrystalDecisions.Shared;
using CrystalDecisions.Enterprise;
using CrystalDecisions.Enterprise.Desktop;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Web.Services;
using CrystalDecisions.ReportAppServer.ClientDoc;
using CrystalDecisions.ReportAppServer.Controllers;
using CrystalDecisions.ReportAppServer.DataDefModel;
using CrystalDecisions.ReportAppServer.CommonObjectModel;
using CrystalDecisions.ReportAppServer.ObjectFactory;
using CrystalDecisions.ReportAppServer.ReportDefModel;
using BusinessObjects.Enterprise.Biar;   

namespace CrystalReportsViewer
{
    public partial class frmCrystalReportViewer : Form
    {
        public frmCrystalReportViewer()
        {
            InitializeComponent();
        }

        //Listing 7-3
        private void cmdRunFromBOServer_Click(object sender, EventArgs e)
        {
            SessionMgr oSessionMgr;
            EnterpriseSession oEnterpriseSession;
            EnterpriseService oEnterpriseService;
            InfoStore oInfoStore;
            InfoObjects oInfoObjects;
            ReportParameter oReportParameter;
            ReportParameterSingleValue oReportParameterSingleValue;
            Report oReport;
            string szSQL;

            //Logon to BO XI
            oSessionMgr = new SessionMgr();
            oEnterpriseSession = oSessionMgr.Logon("Administrator", "", "SETON-NOTEBOOK:6400", "secEnterprise");
            oEnterpriseService = oEnterpriseSession.GetService("InfoStore");
            oInfoStore = new InfoStore(oEnterpriseService);

            //Pull the needed report information and cast as a Report object
            szSQL = "SELECT SI_ID, SI_PROCESSINFO.SI_PROMPTS " +
                    "FROM CI_INFOOBJECTS " +
                    "WHERE SI_ID = 808";

            oInfoObjects = oInfoStore.Query(szSQL);
            oReport = ((Report)oInfoObjects[1]);

            //Set the value of the first parameter
            oReportParameter = oReport.ReportParameters[1];
            oReportParameterSingleValue = oReport.ReportParameters[1].CreateSingleValue();
            oReportParameterSingleValue.Value = "UK";
            oReport.ReportParameters[1].CurrentValues.Clear();
            oReport.ReportParameters[1].CurrentValues.Add(oReportParameterSingleValue);

            //Set the value of the second parameter. Even though this is a numeric value
            //it must be set as a string
            oReportParameter = oReport.ReportParameters[2];
            oReportParameterSingleValue = oReport.ReportParameters[2].CreateSingleValue();
            oReportParameterSingleValue.Value = "5";
            oReport.ReportParameters[2].CurrentValues.Clear();
            oReport.ReportParameters[2].CurrentValues.Add(oReportParameterSingleValue);

            //Commit the report to the Infostore
            oInfoStore.Commit(oInfoObjects);

            //Set the session connection to the Crystal viewer
            crystalReportViewer1.EnterpriseLogon = oEnterpriseSession;

            //Set the report object as the ReportSource and the report will display
            crystalReportViewer1.ReportSource = oReport;
        }


        //Listing 7-5
        private void cmdChangeDataSourceForReport_Click(object sender, EventArgs e)
        {
            CrystalDecisions.CrystalReports.Engine.ReportDocument oReportDocument;
            CrystalDecisions.Shared.ConnectionInfo oConnectionInfo;
            TableLogOnInfo oTableLogOnInfo;
            CrystalDecisions.CrystalReports.Engine.Tables oTables;

            //Create a ConnectionInfo object and add the database information
            oConnectionInfo = new CrystalDecisions.Shared.ConnectionInfo();
            oConnectionInfo.ServerName = "(local)";
            oConnectionInfo.DatabaseName = "Northwind";
            oConnectionInfo.IntegratedSecurity = true;
 

            //Create a ReportDocument object to encapsulate the Rpt file
            oReportDocument = new CrystalDecisions.CrystalReports.Engine.ReportDocument();

            oReportDocument.Load(Application.StartupPath + @"\myreport.rpt");

            //Reference the tables collection which in this
            //example consists of one stored procedure
            oTables = oReportDocument.Database.Tables;

            //Iterate through the individual Table objects 
            //and set the connectivity information
            foreach (CrystalDecisions.CrystalReports.Engine.Table oTable in oTables)
            {
                oTableLogOnInfo = oTable.LogOnInfo;
                oTableLogOnInfo.ConnectionInfo = oConnectionInfo;
                oTable.ApplyLogOnInfo(oTableLogOnInfo);
            }

            crystalReportViewer1.ReportSource = oReportDocument;

        }

        //Listing 7-17
        private void cmdRunFromCrystalReportsWebService_Click(object sender, EventArgs e)
        {
            ISCDReportClientDocument oReportClientDocument;
            Orders oOrders;

            oOrders = new Orders();
            oOrders.ReportAppServer = "localhost";
            oOrders.Load();
            oReportClientDocument = oOrders.ReportClientDocument;

            crystalReportViewer1.ReportSource = oReportClientDocument;
        }

        //Listing 7-18
        private void cmdRunFromUnmanagedRAS_Click(object sender, EventArgs e)
        {
            ISCDReportClientDocument oReportClientDocument;
            object oTarget;

            oTarget = Application.StartupPath + @"\EmployeeSQLServer.rpt";

            oReportClientDocument = new ReportClientDocumentClass();

            oReportClientDocument.Open(ref oTarget, 1);

            crystalReportViewer1.ReportSource = oReportClientDocument;
        }

        //Listing 7-1
        private void cmdChangeViewerSettings_Click(object sender, EventArgs e)
        {
            crystalReportViewer1.DisplayGroupTree = false;
            crystalReportViewer1.DisplayBackgroundEdge = false;
            crystalReportViewer1.DisplayStatusBar = false;

            crystalReportViewer1.DisplayToolbar = false;
            crystalReportViewer1.ShowCloseButton = false;
            crystalReportViewer1.ShowExportButton = true;
            crystalReportViewer1.ShowGotoPageButton = true;
            crystalReportViewer1.ShowGroupTreeButton = true;
            crystalReportViewer1.ShowPageNavigateButtons = true;
            crystalReportViewer1.ShowPrintButton = true;
            crystalReportViewer1.ShowRefreshButton = true;
            crystalReportViewer1.ShowTextSearchButton = true;
            crystalReportViewer1.ShowZoomButton = true;
        }

        //Listing 7-4
        private void cmdSetParametersForReportOnDisk_Click(object sender, EventArgs e)
        {
            crystalReportViewer1.ReportSource = Application.StartupPath + @"\EmployeeSQLServer.rpt";

            ParameterFields oParameterFields;
            ParameterDiscreteValue oParameterDiscreteValue;

            oParameterFields = crystalReportViewer1.ParameterFieldInfo;

            oParameterDiscreteValue = new ParameterDiscreteValue();
            oParameterDiscreteValue.Value = "UK";

            oParameterFields[0].CurrentValues.Clear();
            oParameterFields[0].CurrentValues.Add(oParameterDiscreteValue);

            oParameterDiscreteValue = new ParameterDiscreteValue();
            oParameterDiscreteValue.Value = 5;

            oParameterFields[1].CurrentValues.Clear();
            oParameterFields[1].CurrentValues.Add(oParameterDiscreteValue);

            crystalReportViewer1.ParameterFieldInfo = oParameterFields;
        }

        //Listing 7-22
        private void cmdRunFromCrystalReportsWebServiceAsmx_Click(object sender, EventArgs e)
        {
            crystalReportViewer1.ReportSource =
                "http://localhost:2662/CrystalReportsWebServices/EmployeeSQLServerService.asmx";


            localhost.EmployeeSQLServerService oEmployeeSQLServerService;

            oEmployeeSQLServerService = new CrystalReportsViewer.localhost.EmployeeSQLServerService();

            crystalReportViewer1.ReportSource = oEmployeeSQLServerService;

            ParameterFields oParameterFields;
            ParameterDiscreteValue oParameterDiscreteValue;

            oParameterFields = crystalReportViewer1.ParameterFieldInfo;

            oParameterDiscreteValue = new ParameterDiscreteValue();
            oParameterDiscreteValue.Value = "USA";

            oParameterFields[0].CurrentValues.Clear();
            oParameterFields[0].CurrentValues.Add(oParameterDiscreteValue);

            oParameterDiscreteValue = new ParameterDiscreteValue();
            oParameterDiscreteValue.Value = 2;

            oParameterFields[1].CurrentValues.Clear();
            oParameterFields[1].CurrentValues.Add(oParameterDiscreteValue);

            crystalReportViewer1.ParameterFieldInfo = oParameterFields;
        }

        //LIsting 7-19
        private void cmdSetCustomDataSource_Click(object sender, EventArgs e)
        {
            Orders oOrders;
            DataTable oDT;

            oDT = GetData();

            oOrders = new Orders();

            oOrders.SetDataSource(oDT);

            crystalReportViewer1.ReportSource = oOrders;

        }

        //LIsting 7-20
        public static DataTable GetData()
        {
            DataTable oDT;
            DataRow oDR;

            oDT = new DataTable("spc_SalesOrders");

            oDT.Columns.Add(new DataColumn("CustomerID", typeof(string)));
            oDT.Columns.Add(new DataColumn("CompanyName", typeof(string)));
            oDT.Columns.Add(new DataColumn("City", typeof(string)));
            oDT.Columns.Add(new DataColumn("Country", typeof(string)));
            oDT.Columns.Add(new DataColumn("OrderID", typeof(int)));
            oDT.Columns.Add(new DataColumn("OrderDate", typeof(DateTime)));
            oDT.Columns.Add(new DataColumn("Employee", typeof(string)));
            oDT.Columns.Add(new DataColumn("ProductName", typeof(string)));
            oDT.Columns.Add(new DataColumn("UnitPrice", typeof(int)));
            oDT.Columns.Add(new DataColumn("Quantity", typeof(int)));

            oDR = oDT.NewRow();

            oDR["CustomerID"] = "12345";
            oDR["CompanyName"] = "Seton Software Development, Inc.";
            oDR["City"] = "Raritan, NJ";
            oDR["Country"] = "USA";
            oDR["OrderID"] = 10001;
            oDR["OrderDate"] = "10/21/2006";
            oDR["Employee"] = "Carl Ganz, Jr.";
            oDR["ProductName"] = "BusinessObjects XI Book";
            oDR["UnitPrice"] = 59.99;
            oDR["Quantity"] = 5;

            oDT.Rows.Add(oDR);

            return oDT;
        }

        //Listing 7-13
        private void cmdExportReportStructureXML_Click(object sender, EventArgs e)
        {
            XmlDocument oXmlDocument = null;
            XmlElement oXmlElement = null;
            XmlElement oXmlSubElement = null;
            XmlElement oXmlReportElement = null;
            XmlElement oXmlChildElement;
            XmlText oXmlChildText;
            Orders oOrders;

            oOrders = new Orders();

            oXmlDocument = new XmlDocument();

            oXmlElement = oXmlDocument.CreateElement("", oOrders.ResourceName, "");

            oXmlDocument.AppendChild(oXmlElement);

            foreach (CrystalDecisions.CrystalReports.Engine.Section oSection in oOrders.ReportDefinition.Sections)
            {

                oXmlSubElement = oXmlDocument.CreateElement("", oSection.Kind.ToString(), "");
                oXmlSubElement.SetAttribute("Name", oSection.Name);

                oXmlElement.AppendChild(oXmlSubElement);

                foreach (CrystalDecisions.CrystalReports.Engine.ReportObject oReportObject in oSection.ReportObjects)
                {
                    oXmlReportElement = oXmlDocument.CreateElement("", oReportObject.Name, "");

                    oXmlChildElement = oXmlDocument.CreateElement(oReportObject.Kind.ToString());
                    oXmlChildText = oXmlDocument.CreateTextNode(oReportObject.Name);

                    oXmlElement.AppendChild(oXmlChildElement);
                    oXmlElement.LastChild.AppendChild(oXmlChildText);

                    oXmlSubElement.AppendChild(oXmlReportElement);
                }
            }

            oXmlDocument.Save(Application.StartupPath + @"\report.xml"); 

        }


        private void frmCrystalReportViewer_Load(object sender, EventArgs e)
        {

        }


    }
}