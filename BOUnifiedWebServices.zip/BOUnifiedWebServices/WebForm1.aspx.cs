using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using BusinessObjects.DSWS;
using BusinessObjects.DSWS.BIPlatform;
using BusinessObjects.DSWS.Session;
using BusinessObjects.DSWS.BIPlatform.Desktop;
using BusinessObjects.DSWS.BIPlatform.Constants;
using BusinessObjects.DSWS.ReportEngine;  
using BusinessObjects.DSWS.BIPlatform.Dest;

namespace BOUnifiedWebServices
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button cmdAddReport;
		protected System.Web.UI.WebControls.Button cmdCreateFolder;
		protected System.Web.UI.WebControls.Button cmdQuerySamples;
		protected System.Web.UI.WebControls.Button cmdPaging;
		protected System.Web.UI.WebControls.Button cmdSetParameters;
		protected System.Web.UI.WebControls.Button cmdScheduleReport;
		protected System.Web.UI.WebControls.Button cmdServerMetrics;
		protected System.Web.UI.WebControls.Button cmdServerStats;
		protected System.Web.UI.WebControls.Button cmdTopFolders;
		protected System.Web.UI.WebControls.Button cmdSystemProperties;
		protected System.Web.UI.WebControls.Button cmdKnownRights;
		protected System.Web.UI.WebControls.Button cmdCheckUserRights;
		protected System.Web.UI.WebControls.Button cmdViewReport;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdViewReport.Click += new System.EventHandler(this.cmdViewReport_Click);
			this.cmdCheckUserRights.Click += new System.EventHandler(this.cmdCheckUserRights_Click);
			this.cmdKnownRights.Click += new System.EventHandler(this.cmdKnownRights_Click);
			this.cmdSystemProperties.Click += new System.EventHandler(this.cmdSystemProperties_Click);
			this.cmdTopFolders.Click += new System.EventHandler(this.cmdTopFolders_Click);
			this.cmdServerStats.Click += new System.EventHandler(this.cmdServerStats_Click);
			this.cmdServerMetrics.Click += new System.EventHandler(this.cmdServerMetrics_Click);
			this.cmdScheduleReport.Click += new System.EventHandler(this.cmdScheduleReport_Click);
			this.cmdPaging.Click += new System.EventHandler(this.cmdPaging_Click);
			this.cmdCreateFolder.Click += new System.EventHandler(this.cmdCreateFolder_Click);
			this.cmdQuerySamples.Click += new System.EventHandler(this.cmdQuerySamples_Click);
			this.cmdSetParameters.Click += new System.EventHandler(this.cmdGetParameters_Click);
			this.cmdAddReport.Click += new System.EventHandler(this.cmdAddReport_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		//Listing 11-2
		string szServicesURL = "http://localhost:8080/dswsbobje/services/";
		string szAuthType = "secEnterprise";
		string szDomain = "SETON-NOTEBOOK";
		string szUser = "Administrator";
		string szPassword = "Ovaltine";

		private void cmdViewReport_Click(object sender, System.EventArgs e)
		{

			ViewReport(szServicesURL, 
							szAuthType, 
							szDomain, 
							szUser, 
							szPassword, 
							"path://InfoObjects/Root Folder/Human Resources/**/",
							"Employee Report",
							OutputFormatType.PDF);

		}

		private void cmdServerMetrics_Click(object sender, System.EventArgs e)
		{
			ServerMetrics(szServicesURL, 
					szAuthType, 
					szDomain, 
					szUser, 
					szPassword);
		}

		private void cmdServerStats_Click(object sender, System.EventArgs e)
		{
			ServerStats(szServicesURL, 
				szAuthType, 
				szDomain, 
				szUser, 
				szPassword);		
		}

		private void cmdScheduleReport_Click(object sender, System.EventArgs e)
		{
			ScheduleReport(szServicesURL, 
				szAuthType, 
				szDomain, 
				szUser, 
				szPassword, 
				"path://InfoObjects/Root Folder/Human Resources/**/",
				"EmployeeSQLServer",
				DateTime.Parse("6/1/2006 16:30:00"),
				DateTime.Parse("6/1/2010"));		
		}


		private void cmdPaging_Click(object sender, System.EventArgs e)
		{
			Paging(szServicesURL, 
				szAuthType, 
				szDomain, 
				szUser, 
				szPassword);
		}

		private void cmdCreateFolder_Click(object sender, System.EventArgs e)
		{
			CreateFolder(szServicesURL, szAuthType, szDomain, szUser, szPassword, "GanzTest");		
		}

		private void cmdAddReport_Click(object sender, System.EventArgs e)
		{
			AddReport(szServicesURL, 
				szAuthType, 
				szDomain,	
				szUser, 
				szPassword, 
				"path://InfoObjects/Root Folder/Human Resources", 
				@"c:\temp\",
				"EmployeeSQLServer.rpt",
				"Employee Report", 
				"This is the employee report.");
		}

		private void cmdGetParameters_Click(object sender, System.EventArgs e)
		{
			SetParameters(szServicesURL, 
				szAuthType, 
				szDomain, 
				szUser, 
				szPassword,
				"path://InfoObjects/Root Folder/Human Resources/",
				"Employee Report");		
		}

		private void cmdQuerySamples_Click(object sender, System.EventArgs e)
		{
			QuerySamples(szServicesURL, 
				szAuthType, 
				szDomain, 
				szUser, 
				szPassword);
		}

		private void cmdTopFolders_Click(object sender, System.EventArgs e)
		{
			TopFolders(szServicesURL, 
				szAuthType, 
				szDomain, 
				szUser, 
				szPassword);		
		}

		private void cmdSystemProperties_Click(object sender, System.EventArgs e)
		{
			SystemProperties(szServicesURL, 
				szAuthType, 
				szDomain, 
				szUser, 
				szPassword);	
		}

		private void cmdKnownRights_Click(object sender, System.EventArgs e)
		{
			KnownRights(szServicesURL, 
				szAuthType, 
				szDomain, 
				szUser, 
				szPassword);		
		}

		private void cmdCheckUserRights_Click(object sender, System.EventArgs e)
		{
			CheckUserRights(szServicesURL, 
				szAuthType, 
				szDomain, 
				szUser, 
				szPassword);
		}


		//Listing 11-3
		private BIPlatform GetBIPlatform(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword)
		{
			SessionInfo oSessionInfo;
			Session oSession;
			BusinessObjects.DSWS.Connection oConnection;
			BusinessObjects.DSWS.ConnectionState oConnectionState;
			EnterpriseCredential oEnterpriseCredential;
			BIPlatform oBIPlatform;

			//Create an EnterpriseCredential object using 
			//the user's BO XI logon information 
			oEnterpriseCredential = new EnterpriseCredential();

			oEnterpriseCredential.AuthType = szAuthType;
			oEnterpriseCredential.Domain = szDomain;
			oEnterpriseCredential.Login = szUser;
			oEnterpriseCredential.Password = szPassword;

			//Create a connection object by referencing the session URL
			oConnection = new BusinessObjects.DSWS.
				Connection(szServicesURL + "session");						

			//Instantiate a Session object using the Connection object
			oSession = new Session(oConnection);

			//Create a SessionInfo object by logging in using the credentials object
			oSessionInfo = oSession.Login(oEnterpriseCredential);
			
			//Create a connection state object
			oConnectionState = new BusinessObjects.DSWS.
				ConnectionState(oSessionInfo.SessionID);

			//Set the Connection object's URL to the biplatform service
			oConnection.URL = szServicesURL + "biplatform";

			//Finally, create a BIPlatform object using 
			//a Connection and ConnectionState object
			oBIPlatform = new BIPlatform(oConnection, oConnectionState);

			return oBIPlatform;
		}

		//Listing 11-5
		private void QuerySamples(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword)
		{
			BIPlatform oBIPlatform;
			ResponseHolder oResponseHolder;
			InfoObjects oInfoObjects;
			GetOptions oGetOptions;
			CrystalReport oCrystalReport;
			string szQuery;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, szDomain, szUser, szPassword);

			oGetOptions = new GetOptions();
			oGetOptions.IncludeSecurity = true;

			//szQuery = "cuid://<AfVEcjaDxd5Is.O2mRzz3bI>";

			//szQuery = "query://{SELECT * FROM CI_INFOOBJECTS WHERE SI_ID = 1566}";

			//szQuery = "path://InfoObjects/Root Folder/Human Resources/Employee Report";

			//szQuery = "path://InfoObjects/Root Folder/Human Resources/Employee Report/[SI_KIND='CrystalReport']";

			//szQuery = "cuid://<AfVEcjaDxd5Is.O2mRzz3bI,AdGpAJuZVl1Bj3b7lyExTos>";

			//szQuery = "path://InfoObjects/Root Folder/Human Resources/Employee Report+/*";

			//szQuery = "path://InfoObjects/Root Folder/Human Resources/[SI_KIND='CrystalReport' OR SI_KIND = 'Folder']";

			//szQuery = "path://InfoObjects/Root Folder/**/*?OrderBy=SI_NAME[SI_KIND='CrystalReport']";

			szQuery = "search://{Employee}?IncludeInstances=true&SearchKeywords=true";

			//get the report
			oResponseHolder = new ResponseHolder();
			oResponseHolder = oBIPlatform.Get(szQuery, oGetOptions);

			oInfoObjects = oResponseHolder.InfoObjects;

			oCrystalReport = ((CrystalReport) oInfoObjects.InfoObject[0]);

		}

		//Listing 11-6
		private void Paging(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword)
		{
			BIPlatform oBIPlatform;
			ResponseHolder oResponseHolder;
			ResponseHolder oPageResponseHolder;
			GetOptions oGetOptions;
			InfoObjects oInfoObjects;
			PageInfo[] aPageInfo;
			string szData;
			int y = 0;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, szDomain, szUser, szPassword);

			//By default, the page size is set to 100. Here, we're changing it to 20
			oGetOptions = new GetOptions(); 

			oGetOptions.PageSize = 20;
			oGetOptions.PageSizeSpecified = true;

			//Pull everything to get a large result set
			oResponseHolder = oBIPlatform.Get("path://InfoObjects/Root Folder/**/*", oGetOptions);

			oInfoObjects = oResponseHolder.InfoObjects;

			aPageInfo = oResponseHolder.PagingDetails.PageInfo;

			for(int x=0; x < aPageInfo.Length; x++)
			{
				oPageResponseHolder = oBIPlatform.Get(aPageInfo[x].PageURI, null);
				oInfoObjects = oPageResponseHolder.InfoObjects;
				y = 0;

				foreach(InfoObject oInfoObject in oInfoObjects.InfoObject)
				{
					y++;

					szData = string.Format("{0} - SI_ID = {1}  SI_NAME = {2}  SI_KIND = {3} <BR>",
											y.ToString(),  
											oInfoObject.ID.ToString(),
											oInfoObject.Name,
											oInfoObject.Kind);

					Response.Write(szData);
				}

			}
		}


		//Listing 11-14
		private void ServerMetrics(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword)
		{
			BIPlatform oBIPlatform;
			ServerMetrics oServerMetrics;
			string szQuery;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, szDomain, szUser, szPassword);

			szQuery = "query://{SELECT * " + 
				"FROM CI_SYSTEMOBJECTS " + 
				"WHERE SI_FRIENDLY_NAME = 'seton-notebook.cms'}";

			oServerMetrics = oBIPlatform.GetServerMetrics(szQuery);

			Response.Write("CPU = " + oServerMetrics.CPU + "<BR>");
			Response.Write("CPUCount = " + 
				oServerMetrics.CPUCount.ToString()  + "<BR>");
			Response.Write("DiskSpaceAvailable = " + 
				oServerMetrics.DiskSpaceAvailable.ToString() + "<BR>");
			Response.Write("DiskSpaceTotal = " + 
				oServerMetrics.DiskSpaceTotal.ToString() + "<BR>");
			Response.Write("Memory = " + oServerMetrics.Memory.ToString() + "<BR>");
			Response.Write("OperatingSystem = " + 
				oServerMetrics.OperatingSystem + "<BR>");
			Response.Write("ServerCUID = " + oServerMetrics.ServerCUID + "<BR>");
			Response.Write("ServerIsAlive = " + 
				oServerMetrics.ServerIsAlive.ToString() + "<BR>");
			Response.Write("ServerIsEnabled = " + 
				oServerMetrics.ServerIsEnabled.ToString() + "<BR>");
			Response.Write("StartTime = " + 
				oServerMetrics.StartTime.ToString() + "<BR>");
			Response.Write("Version = " + oServerMetrics.Version + "<BR>");
 
		}

		//Listing 11-15
		private void ServerStats(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword)
		{
			BIPlatform oBIPlatform;
			ResponseHolder oResponseHolder;	
			InfoObjects oInfoObjects;
			Server oServer;
			string szQuery;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, szDomain, szUser, szPassword);

			szQuery = "query://{SELECT * " + 
				"FROM CI_SYSTEMOBJECTS " + 
				"WHERE SI_FRIENDLY_NAME = 'seton-notebook.cms'}";

			oResponseHolder = oBIPlatform.Get(szQuery, null);

			oInfoObjects = oResponseHolder.InfoObjects;
					
			oServer = ((Server) oInfoObjects.InfoObject[0]);  

			Response.Write("Description = " + oServer.Description + "<BR>");
			Response.Write("FriendlyName = " + oServer.FriendlyName + "<BR>");
			Response.Write("Kind = " + oServer.Kind + "<BR>");
			Response.Write("Name = " + oServer.Name + "<BR>");
			Response.Write("OSServiceName = " + oServer.OSServiceName + "<BR>");
			Response.Write("ServerDescriptor = " + oServer.ServerDescriptor + "<BR>");
			Response.Write("ServerID = " + oServer.ServerID + "<BR>");
			Response.Write("ServerKind = " + oServer.ServerKind  + "<BR>");
			Response.Write("ServerName = " + oServer.ServerName  + "<BR>");
 
		}


		//Listing 11-13
		private void TopFolders(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword)
		{
			BIPlatform oBIPlatform;
			ResponseHolder oResponseHolder;	
			InfoObjects oInfoObjects;
			string szData;
			int y = 0;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, szDomain, szUser, szPassword);

			oResponseHolder = oBIPlatform.GetTopFolders(null); 

			oInfoObjects = oResponseHolder.InfoObjects;

			foreach(InfoObject oInfoObject in oInfoObjects.InfoObject)
			{
				y++;

				szData = string.Format("{0} - SI_ID = {1}  SI_NAME = {2}  SI_KIND = {3} <BR>",
					y.ToString(),  
					oInfoObject.ID.ToString(),
					oInfoObject.Name,
					oInfoObject.Kind);

				Response.Write(szData);
			}
		}


		//Listing 11-4
		private void SystemProperties(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword)
		{
			BIPlatform oBIPlatform;
			SystemProperty[] aSystemProperty;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, szDomain, szUser, szPassword);

			aSystemProperty = oBIPlatform.GetSystemInfoProperties(); 

			for(int y=0; y < aSystemProperty.Length; y++)
				Response.Write(string.Format("Name = {0} Value = {1} <BR>", 
					aSystemProperty[y].Name, aSystemProperty[y].Value)); 
		}

		//Listing 11-16
		private void KnownRights(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword)
		{
			BIPlatform oBIPlatform;
			RightInfo[] aRightInfo;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, szDomain, szUser, szPassword);

			aRightInfo = oBIPlatform.GetKnownRights("AW08OjsfXx9LgQeYdykOzkA"); 

			Response.Write("<TABLE>");

			Response.Write("<TR>");
			Response.Write("<TD>Object</TD><TD>Right</TD><TD>Denied</TD>"); 
			Response.Write("</TR>");

			for(int y=0; y < aRightInfo.Length; y++)
				Response.Write("<TR><TD>" + aRightInfo[y].ObjectKind + "</TD>" + 
					"<TD>" + aRightInfo[y].Description + "</TD>" +
					"<TD>" + aRightInfo[y].Denied + "</TD></TR>"); 

			Response.Write("</TABLE>"); 
		}


		private void CheckUserRights(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword)
		{
			BIPlatform oBIPlatform;
			Right[] aRight;
			Right[] aRightStatus;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, szDomain, szUser, szPassword);

			aRight = new Right[1];
			aRight[0] = new Right();

			aRightStatus = oBIPlatform.CheckRights("AW08OjsfXx9LgQeYdykOzkA", "12", aRight);
 
		}


		//Listing 11-8
		private void AddReport(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword,
			string szFolder,
			string szReportPath,
			string szReportFileName,
			string szReportName,
			string szDescription)
		{
			BIPlatform oBIPlatform;
			FileStream oFileStream;
			ResponseHolder oResponseHolder;
			InfoObject oInfoObject;
			InfoObjects oInfoObjects;
			CheckSumInfo oCheckSumInfo;
			UploadStatus oUploadStatus;
			CrystalReport oCrystalReport;
			InfoObject[] aInfoObject;
			Byte[] aBuffer;
			string[] aCUID;
			string szFolderCUID;
			RefreshOptionsEnum[] aRefreshOptionsEnum;
			int iBufferSize = 24576; //16384;
			int iByteCount = 0;
			int iBytesRead;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, 
				szDomain, szUser, szPassword);

			//Retrieve folder
			oResponseHolder = new ResponseHolder();
			oResponseHolder = oBIPlatform.Get(szFolder, null);
			oInfoObject = oResponseHolder.InfoObjects.InfoObject[0];
			szFolderCUID = oInfoObject.CUID;
			
			//Checksum object preservse integrity when uploading Rpt file
			oCheckSumInfo = new CheckSumInfo();
			oCheckSumInfo.CheckSumMethod = CheckSumMethodEnum.NONE;
			oCheckSumInfo.CheckSumValue = new Byte[1];

			//Begin upload
			oUploadStatus = new UploadStatus();
			oUploadStatus.UploadID = oBIPlatform.StartUpload();			

			//Send report to file stream
			oFileStream = new FileStream(szReportPath + szReportFileName, 
				FileMode.Open, FileAccess.Read);

			// create an array of bytes with a length of the specified buffer size
			aBuffer = new byte[iBufferSize];

			//upload the file in 16K chunks
			while (oFileStream.Length - iByteCount > iBufferSize) 
			{
				iBytesRead = oFileStream.Read(aBuffer, 0, iBufferSize);
				oUploadStatus = oBIPlatform.UploadFile(oUploadStatus.UploadID, 
					oCheckSumInfo, aBuffer);
				iByteCount += iBytesRead;
			}

			aBuffer = new byte[oFileStream.Length - iByteCount];
			iBytesRead = oFileStream.Read(aBuffer, 0, 
				((int) oFileStream.Length) - iByteCount);
			oUploadStatus = oBIPlatform.UploadFile(oUploadStatus.UploadID, 
				oCheckSumInfo, aBuffer);
			oFileStream.Close();

			//Obtain a CUID for the new report
			aCUID = oBIPlatform.GenerateCuids(1);

			//Set the report refresh properties
			aRefreshOptionsEnum = new RefreshOptionsEnum[3];
			aRefreshOptionsEnum[0] = RefreshOptionsEnum.DEFAULT_LOGON_INFO_VALUES;
			aRefreshOptionsEnum[1] = RefreshOptionsEnum.PRINTER_OPTIONS;
			aRefreshOptionsEnum[2] = RefreshOptionsEnum.PROMPT_VALUES;

			//Assign the attributes of the new report
			oCrystalReport = new CrystalReport();
			oCrystalReport.Name = szReportName;
			oCrystalReport.Description = szDescription;
			oCrystalReport.ParentCUID = szFolderCUID;
			oCrystalReport.CUID = aCUID[0];
			oCrystalReport.ReportRefreshOptions = aRefreshOptionsEnum;

			//Create a new InfoObject collection and add the Crystalreport object to the collection
			oInfoObjects = new InfoObjects();
			aInfoObject = new InfoObject[1];

			aInfoObject[0] = oCrystalReport;
			oInfoObjects.InfoObject = aInfoObject;

			//Complete upload process
			oUploadStatus = oBIPlatform.FinishUploadWithObject(oUploadStatus.UploadID, 
				szReportFileName, oInfoObjects, null);

		}


		//Listing 11-9
		private void SetParameters(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword,
			string szReportPath,
			string szReportName)
		{
			BIPlatform oBIPlatform;
			ResponseHolder oResponseHolder;
			GetOptions oGetOptions;
			InfoObjects oInfoObjects;
			InfoObject oInfoObject;
			ReportProcessingInfo oReportProcessingInfo;
			ReportParameter[] aReportParameters;
			CrystalReport oCrystalReport;
			BusinessObjects.DSWS.BIPlatform.Desktop.PromptValue[] aPromptValue;
			BusinessObjects.DSWS.BIPlatform.Desktop.PromptValue oPromptValue;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, 
				szDomain, szUser, szPassword);

			oGetOptions = new GetOptions();
			oGetOptions.IncludeSecurity = false;

			oResponseHolder = new ResponseHolder();
			oResponseHolder = oBIPlatform.Get(szReportPath + szReportName + 
				"@SI_PROCESSINFO", oGetOptions);

			oInfoObjects = oResponseHolder.InfoObjects;
			oInfoObject = oInfoObjects.InfoObject[0];
			
			oCrystalReport = new CrystalReport();
			oCrystalReport = ((CrystalReport) oInfoObject);
			oCrystalReport.Name = szReportName;

			oReportProcessingInfo = oCrystalReport.PluginProcessingInterface;
						
			aReportParameters = oReportProcessingInfo.ReportParameters;

			aPromptValue = new BusinessObjects.DSWS.BIPlatform.Desktop.PromptValue[1];
			oPromptValue = new BusinessObjects.DSWS.BIPlatform.Desktop.PromptValue();
			oPromptValue.Data = "USA";
			aPromptValue[0] = oPromptValue;
			aReportParameters[0].CurrentValues = aPromptValue;
			
			aPromptValue = new BusinessObjects.DSWS.BIPlatform.Desktop.PromptValue[2];
			oPromptValue = new BusinessObjects.DSWS.BIPlatform.Desktop.PromptValue();
			oPromptValue.Data = "1";
			aPromptValue[0] = oPromptValue;
			aReportParameters[1].CurrentValues = aPromptValue;

			oCrystalReport.PluginProcessingInterface = oReportProcessingInfo;

			oBIPlatform.Update(oInfoObjects);
		}


		//Listing 11-12
		private void CreateFolder(string szServicesURL,
								string szAuthType,
								string szDomain,
								string szUser,
								string szPassword,
								string szFolderName)
		{
			BIPlatform  oBIPlatform;
			Folder oFolder;
			InfoObjects oInfoObjects;
			InfoObject[] aInfoObject;
			CreateOptions oCreateOptions;
			string[] aCUID;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, 
				szDomain, szUser, szPassword);

			//Generate a new CUID for the new folder
			aCUID = oBIPlatform.GenerateCuids(1);

			//Create a Folder object and set the name, CUID, and parent CUID
			oFolder= new Folder();
			oFolder.Name = szFolderName;
			oFolder.CUID = aCUID[0];
			oFolder.ParentCUID = FixedCUIDs.RootFolder.FOLDERS;

			//Create an InfoObject collection and add the Folder object to it
			oInfoObjects = new InfoObjects();
			aInfoObject = new InfoObject[1];
			aInfoObject[0] = oFolder;
			oInfoObjects.InfoObject = aInfoObject;

			//In case a folder with the same name is already specified, 
			//another folder with a numerically incremented anme will be 
			//created and no error will occur
			oCreateOptions = new CreateOptions();
			oCreateOptions.MatchingNameRename = true;
			oCreateOptions.MatchingNameRenameSpecified = true;

			//execute creation process of new folder
			oBIPlatform.Create(oInfoObjects, oCreateOptions);
		}


		private void ScheduleReport(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword,
			string szPath,
			string szReportName,
			DateTime dStartDate,
			DateTime dEndDate)
		{ 

			//Listing 11-10
			BIPlatform  oBIPlatform;
			ResponseHolder oResponseHolder;
			InfoObjects oInfoObjects;
			InfoObject oInfoObject;
			SchedulingInfo oSchedulingInfo;
			CrystalReport oCrystalReport;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, szDomain, szUser, szPassword);

			//retrieve the report			
			oResponseHolder = new ResponseHolder();
			oResponseHolder = oBIPlatform.Get(szPath + szReportName + "@SI_SCHEDULEINFO", null);

			//get the first infobject in the collection returned to the ResponseHolder by the query
			oInfoObjects = oResponseHolder.InfoObjects;
			oInfoObject = oInfoObjects.InfoObject[0];

			//set the SchedulingInfo options
			oSchedulingInfo = new SchedulingInfo();
			oSchedulingInfo.ScheduleType = ScheduleTypeEnum.CALENDAR;
			oSchedulingInfo.ScheduleTypeSpecified = true;

			oSchedulingInfo.BeginDate = dStartDate;
			oSchedulingInfo.BeginDateSpecified = true;

			oSchedulingInfo.EndDate = dEndDate; 
			oSchedulingInfo.EndDateSpecified = true;

			oSchedulingInfo.RightNow = false;
			oSchedulingInfo.RightNowSpecified = true;


			//Listing 11-11
			//Determine the day of week
			BusinessObjects.DSWS.BIPlatform.Desktop.CalendarDay oCalendarDay;
			BusinessObjects.DSWS.BIPlatform.Desktop.CalendarDay[] aCalendarDays;

			oCalendarDay = new BusinessObjects.DSWS.BIPlatform.Desktop.CalendarDay();

			oCalendarDay.WeekNumber = WeekNumberEnum.ALL;
			oCalendarDay.WeekNumberSpecified = true;

			oCalendarDay.DayOfWeek = ((int) DayOfWeek.Monday) + 1;
			oCalendarDay.DayOfWeekSpecified = true;

			oCalendarDay.StartMonth = dStartDate.Month;
			oCalendarDay.StartMonthSpecified = true;

			oCalendarDay.StartDay = dStartDate.Day;
			oCalendarDay.StartDaySpecified = true;

			oCalendarDay.StartYear = dStartDate.Year;
			oCalendarDay.StartYearSpecified = true;

			oCalendarDay.EndMonth = dEndDate.Month;
			oCalendarDay.EndMonthSpecified = true;

			oCalendarDay.EndDay = dEndDate.Day;
			oCalendarDay.EndDaySpecified = true;

			oCalendarDay.EndYear = dEndDate.Year;
			oCalendarDay.EndYearSpecified = true;

			aCalendarDays = new BusinessObjects.DSWS.BIPlatform.Desktop.CalendarDay[1];

			aCalendarDays[0] = oCalendarDay;

			oSchedulingInfo.CalendarRunDays = aCalendarDays;

				
			//cast the infoobject to a CrystalReport object
			oCrystalReport = new CrystalReport();
			oCrystalReport = ((CrystalReport) oInfoObject);
			oCrystalReport.Name = szReportName;
			oCrystalReport.SchedulingInfo = oSchedulingInfo;

			oBIPlatform.Schedule(oInfoObjects);			
		}


		//Listing 11-7
		private void ViewReport(string szServicesURL,
			string szAuthType,
			string szDomain,
			string szUser,
			string szPassword,
			string szPath,
			string szReportName,
			OutputFormatType sOutputFormatType)
		{
			BIPlatform oBIPlatform;
			BusinessObjects.DSWS.Connection oConnection;
			BusinessObjects.DSWS.ConnectionState oConnectionState;
			ResponseHolder oResponseHolder;
			ReportEngine oReportEngine;
			RetrieveData oRetrieveData;
			RetrieveBinaryView oRetrieveBinaryView;
			ViewSupport oViewSupport;
			DocumentInformation oDocumentInformation;
			BinaryView oBinaryView;
			Action[] oActions;
			string szCUID;

			oBIPlatform = GetBIPlatform(szServicesURL, szAuthType, 
				szDomain, szUser, szPassword);			

			oResponseHolder = oBIPlatform.Get(szPath + szReportName, null);

			szCUID = oResponseHolder.InfoObjects.InfoObject[0].CUID;

			//Since we'll need the Connection and ConnectionState properties to
			//create the ReportEngine class, let's extarct them from BIPlatform
			oConnection = oBIPlatform.Connection;
			oConnectionState = oBIPlatform.ConnectionState; 

			//ReportEngine provides a gateway to the report document
			oConnection.URL = szServicesURL + "reportengine";
			oReportEngine = new ReportEngine(oConnection, oConnectionState);

			//The ViewSupport class maps the viewing preferences
			oViewSupport = new ViewSupport();
			oViewSupport.OutputFormat = sOutputFormatType;
			oViewSupport.ViewType = ViewType.BINARY;
			oViewSupport.ViewMode = ViewModeType.DOCUMENT;

			//RetrieveBinaryView indicates that a binary document,
			//as opposed to a character or XML document, should be retrieved
			oRetrieveBinaryView = new RetrieveBinaryView();
			oRetrieveBinaryView.ViewSupport = oViewSupport;

			//RetrieveData indicate what report data will be returned
			oRetrieveData = new RetrieveData();
			oRetrieveData.RetrieveView = oRetrieveBinaryView;

			//Indicate that when the report is extracted it should be refreshed
			oActions = new Action[1];
			oActions[0] = new Refresh();

			//Extract the report
			oDocumentInformation = oReportEngine.
				GetDocumentInformation(szCUID, null, oActions, null, oRetrieveData);

			//Retrieve binary view of report
			oBinaryView = ((BinaryView) oDocumentInformation.View);

			//Output report to browser
			Response.Clear();
			Response.AddHeader("Content-Length", oBinaryView.ContentLength.ToString());
			Response.AddHeader("Content-Disposition", 
				String.Format("inline; filename={0};", szReportName + 
				GetExtension(sOutputFormatType)));
			Response.ContentType = oBinaryView.MimeType;
			Response.BinaryWrite(oBinaryView.Content);
			Response.Flush();
			Response.End();
		}

		private string GetExtension(OutputFormatType sOutputFormatType)
		{
			string szResult = string.Empty;

			switch (sOutputFormatType)
			{
				case OutputFormatType.EXCEL:
					szResult = ".xls";
					break;

				case OutputFormatType.WORD:
					szResult = ".doc";
					break;

				case OutputFormatType.PDF:
					szResult = ".pdf";
					break;
			}

			return szResult;

		}


	}

}
