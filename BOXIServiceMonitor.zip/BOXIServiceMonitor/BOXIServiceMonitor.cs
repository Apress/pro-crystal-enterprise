using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Web.Mail; 
using System.Xml;
using System.Threading;

namespace BOXIServiceMonitor
{
	public class BOXIServiceMonitor : System.ServiceProcess.ServiceBase
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public BOXIServiceMonitor()
		{
			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();

		}

		// The main entry point for the process
		static void Main()
		{
			System.ServiceProcess.ServiceBase[] ServicesToRun;
	
			ServicesToRun = new System.ServiceProcess.ServiceBase[] { new BOXIServiceMonitor() };

			System.ServiceProcess.ServiceBase.Run(ServicesToRun);
		}

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			this.ServiceName = "BOXIServiceMonitor";		
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		protected override void OnStart(string[] args)
		{
			string szMsg;

			BOXIServiceMonitorMain oBOXIServiceMonitorMain;
			
			oBOXIServiceMonitorMain = new BOXIServiceMonitorMain();
 
			Thread oThread = new Thread(new ThreadStart(oBOXIServiceMonitorMain.Run)); 

			oThread.Start(); 

			szMsg = "The BO XI Service Monitor was started at " + DateTime.Now.ToString();  
					
			System.Diagnostics.EventLog.WriteEntry(this.ServiceName, szMsg); 
		}
 
		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			string szMsg;

			szMsg = "The BO XI Service Monitor was stopped at " + DateTime.Now.ToString();  
					
			System.Diagnostics.EventLog.WriteEntry(this.ServiceName, szMsg); 
		}

	}


	public class BOXIServiceMonitorMain
	{
		//Listing 9-35
		public void Run()
		{
			ServiceController oServiceController;
			XmlDocument oXmlDocument;
			XmlNode oXmlNode; 
			string szService = string.Empty;
			string szAppPath = string.Empty;
			string szCodeBase = string.Empty;
			string szMsg = string.Empty;
			string szMachineName = string.Empty;
			string szNotifyEmails = string.Empty;
			string szSmtpServer = string.Empty;
			short sFrequencyInMinutes;
			short sMaxWaitInSeconds;
			long lStartTicks;
			bool bTimeOut = false;

			//System.Diagnostics.EventLog.WriteEntry("BOXIServiceMonitorMain", "Run()"); 

			while (true)
			{
				//Get the path where the window service is executing
				szCodeBase = System.Reflection.Assembly.
					GetExecutingAssembly().GetName().CodeBase;
				szAppPath = System.IO.Path.GetDirectoryName(szCodeBase);

				//Cut off the first six characters because the directory names  
				//returns in this format: @"file:\C:\BOXIServiceMonitor\bin\Debug"
				szAppPath = szAppPath.Substring(6);

				szMachineName = Environment.MachineName;

				//Get the settings from the XML file
				sFrequencyInMinutes = GetFrequencyInMinutes(szAppPath);
				sMaxWaitInSeconds = GetMaxWaitInSeconds(szAppPath);
				szNotifyEmails = GetNotifyEmails(szAppPath);
				szSmtpServer = GetSmtpServer(szAppPath);

				//C:\WINDOWS\Microsoft.NET\Framework\v1.1.4322\InstallUtil.exe		
				
				//Open the XML file to obtain a list of BO XI Services
				oXmlDocument = new XmlDocument();
				oXmlDocument.Load(szAppPath + @"\settings.xml");

				oXmlNode = oXmlDocument.SelectSingleNode("/Settings/Services");

				//Iterate through each service
				foreach(XmlNode oChildXmlNode in oXmlNode.ChildNodes)
				{
					szService = oChildXmlNode.ChildNodes[0].InnerText;

					//Obtain an object reference to the service
					oServiceController = new ServiceController(szService);

					//If the service is either stooped or in the process of stopping...
					if (oServiceController.Status == ServiceControllerStatus.Stopped ||
						oServiceController.Status == ServiceControllerStatus.StopPending)
					{

						szMsg = "The {0} was detected down on {1} at {2}";  

						szMsg = string.Format(szMsg, szService, szMachineName, DateTime.Now.ToString()); 
					
						System.Diagnostics.EventLog.WriteEntry(szService, szMsg); 
					
						//SendEmail(szMsg, szNotifyEmails, szSmtpServer);

						lStartTicks = Environment.TickCount;

						//...start it up again
						oServiceController.Start(); 

						//keep checking every 1/2 second by refreshing the object  
						//reference to see if the service has started again
						do 
						{
							oServiceController.Refresh(); 

							System.Threading.Thread.Sleep(500); 

							//if it hasn't started by the before we reach the timeout 
							//period then indicate a time out condition and stop trying
							if ((Environment.TickCount/1000) - 
								(lStartTicks/1000)  > sMaxWaitInSeconds)
							{
								bTimeOut = true;
								break;
							}

						}
						while (oServiceController.Status != ServiceControllerStatus.Running);

						//if there was a timeout condition, indicate this in the
						//even log. Otherwise, indicate success.
						if (bTimeOut)
						{
							szMsg = "The {0} could not be restarted on {1} in the {2} seconds allotted"; 

							szMsg = string.Format(szMsg, szService, szMachineName, MaxWaitInSeconds.ToString()); 

							System.Diagnostics.EventLog.WriteEntry(szService, szMsg); 
						
							//SendEmail(szMsg, szNotifyEmails, szSmtpServer);			
						}
						else
						{
							szMsg = "The {0} was successfully restarted on {1} at {2}";  

							szMsg = string.Format(szMsg, szService, szMachineName, DateTime.Now.ToString()); 
						
							System.Diagnostics.EventLog.WriteEntry(szService, szMsg); 
						
							//SendEmail(szMsg, szNotifyEmails, szSmtpServer);			
						}

						bTimeOut = false;
					}

				}

				//Once the services have been checked, 
				//sit tight until its time to check again
				System.Threading.Thread.Sleep(sFrequencyInMinutes * 60 * 1000); 

			}
		}

		private void SendEmail(string szBody, string szNotifyEmails, string szSmtpServer)
		{
			MailMessage oMailMessage;

			oMailMessage = new MailMessage();

			oMailMessage.To = szNotifyEmails;
			oMailMessage.Subject = "BOXI Service Notification";
			oMailMessage.Body = szBody;
			oMailMessage.Priority = MailPriority.High;

			SmtpMail.SmtpServer = szSmtpServer;
			SmtpMail.Send(oMailMessage);

			oMailMessage = null;

		}

		private short GetFrequencyInMinutes(string szAppPath)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			short sResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load(szAppPath + @"\settings.xml");

			oXmlNode = oXmlDocument.SelectSingleNode("/Settings/FrequencyInMinutes");
			sResult = short.Parse(oXmlNode.InnerText);

			oXmlDocument = null;
			oXmlNode = null;

			return sResult;
		}

		private short GetMaxWaitInSeconds(string szAppPath)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			short sResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load(szAppPath + @"\settings.xml");

			oXmlNode = oXmlDocument.SelectSingleNode("/Settings/MaxWaitInSeconds");
			sResult = short.Parse(oXmlNode.InnerText);

			oXmlDocument = null;
			oXmlNode = null;

			return sResult;
		}
		

		private string GetNotifyEmails(string szAppPath)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			string szResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load(szAppPath + @"\settings.xml");

			oXmlNode = oXmlDocument.SelectSingleNode("/Settings/NotifyEmails");
			szResult = oXmlNode.InnerText;

			oXmlDocument = null;
			oXmlNode = null;

			return szResult;
		}


		private string GetSmtpServer(string szAppPath)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			string szResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load(szAppPath + @"\settings.xml");

			oXmlNode = oXmlDocument.SelectSingleNode("/Settings/SmtpServer");
			szResult = oXmlNode.InnerText;

			oXmlDocument = null;
			oXmlNode = null;

			return szResult;
		}

	}
}
