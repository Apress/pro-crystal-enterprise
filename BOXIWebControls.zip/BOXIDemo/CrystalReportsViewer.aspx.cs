using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Enterprise;

namespace BOXIDemo
{
	/// <summary>
	/// Summary description for CrystalReportsViewer.
	/// </summary>
	public class CrystalReportsViewer : System.Web.UI.Page
	{
		protected CrystalDecisions.Web.CrystalReportViewer CrystalReportViewer1;
	
		//Listing 6-33
		private void Page_Load(object sender, System.EventArgs e)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			SessionMgr oSessionMgr = null;
			InfoObjects oInfoObjects;
			InfoObject oInfoObject;
			string szReportID;
			string szSQL;

			szReportID = Request.QueryString["ID"]; 

			oSessionMgr = new SessionMgr();

			oEnterpriseSession = oSessionMgr.Logon("Administrator", "", "SETON-NOTEBOOK:6400", "secEnterprise");

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			szSQL = "Select SI_ID " + 
					"From CI_INFOOBJECTS " + 
					"Where SI_ID = " + szReportID;

			oInfoObjects = oInfoStore.Query(szSQL);
			oInfoObject = oInfoObjects[1];

			CrystalReportViewer1.EnterpriseLogon = oEnterpriseSession;
			CrystalReportViewer1.ReportSource = oInfoObject;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
