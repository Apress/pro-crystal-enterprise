using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace BOXIDemo
{
	/// <summary>
	/// Summary description for ReportHistory.
	/// </summary>
	public class ReportHistory : System.Web.UI.Page
	{
		protected CrystalDecisions.Enterprise.WebControls.EnterpriseItems enterpriseItems1;
		protected CrystalDecisions.Enterprise.WebControls.Identity identity1;
		protected CrystalDecisions.Enterprise.WebControls.ItemsGrid ItemsGrid1;
		private System.ComponentModel.IContainer components;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			enterpriseItems1.ParentItemID = Request["id"];
			ItemsGrid1.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
			this.enterpriseItems1 = new CrystalDecisions.Enterprise.WebControls.EnterpriseItems(this.components, this, "enterpriseItems1", CrystalDecisions.Enterprise.WebControls.StatePersistence.ViewState);
			this.identity1 = new CrystalDecisions.Enterprise.WebControls.Identity(this.components, this, "identity1");
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItems1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.identity1)).BeginInit();
			// 
			// ItemsGrid1
			// 
			this.ItemsGrid1.ItemClicked += new CrystalDecisions.Enterprise.WebControls.ItemClickedEventHandler(this.ItemsGrid1_ItemClicked);
			this.ItemsGrid1.ItemSource = this.enterpriseItems1;
			// 
			// enterpriseItems1
			// 
			this.enterpriseItems1.Identity = this.identity1;
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItems1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.identity1)).EndInit();

		}
		#endregion

		private void ItemsGrid1_ItemClicked(object sender, CrystalDecisions.Enterprise.WebControls.ItemEventArgs e)
		{
			if (e.ItemType == "CrystalEnterprise.Report") 
				Response.Redirect("ViewRpt.aspx?ID=" + e.ItemID.ToString());
			else
				if (e.ItemType == "CrystalEnterprise.Excel" ||
				e.ItemType == "CrystalEnterprise.Pdf" ||
				e.ItemType == "CrystalEnterprise.Powerpoint" ||
				e.ItemType == "CrystalEnterprise.Rtf" ||
				e.ItemType == "CrystalEnterprise.Txt" ||
				e.ItemType == "CrystalEnterprise.Word")
			{
				Response.Redirect("StreamReport.aspx?ID=" + e.ItemID.ToString());
			}
		}
	}
}
