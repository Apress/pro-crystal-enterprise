using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace BOXIDemo
{
	/// <summary>
	/// Summary description for Folders.
	/// </summary>
	public class Folders : System.Web.UI.Page
	{
		protected CrystalDecisions.Enterprise.WebControls.ItemsGrid ItemsGrid1;
		protected CrystalDecisions.Enterprise.WebControls.EnterpriseItems enterpriseItems1;
		protected CrystalDecisions.Enterprise.WebControls.Identity identity1;
		protected System.Web.UI.WebControls.RadioButton rbViewReport;
		protected System.Web.UI.WebControls.RadioButton rbReportHistory;
		protected System.Web.UI.WebControls.RadioButton rbScheduleReport;
		protected System.Web.UI.WebControls.RadioButton rbDatabaseLogon;
		protected System.Web.UI.WebControls.RadioButton rbFilters;
		protected System.Web.UI.WebControls.RadioButton rbFormat;
		protected System.Web.UI.WebControls.RadioButton rbParameters;
		protected System.Web.UI.WebControls.RadioButton rbPrint;
		protected System.Web.UI.WebControls.RadioButton rbDestination;
		private System.ComponentModel.IContainer components;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
			this.enterpriseItems1 = new CrystalDecisions.Enterprise.WebControls.EnterpriseItems(this.components, this, "enterpriseItems1", CrystalDecisions.Enterprise.WebControls.StatePersistence.ViewState);
			this.identity1 = new CrystalDecisions.Enterprise.WebControls.Identity(this.components, this, "identity1");
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItems1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.identity1)).BeginInit();
			// 
			// ItemsGrid1
			// 
			this.ItemsGrid1.ItemClicked += new CrystalDecisions.Enterprise.WebControls.ItemClickedEventHandler(this.ItemsGrid1_ItemClicked);
			this.ItemsGrid1.ItemSource = this.enterpriseItems1;
			// 
			// enterpriseItems1
			// 
			this.enterpriseItems1.Identity = this.identity1;
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItems1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.identity1)).EndInit();

		}
		#endregion

		//Listing 6-31
		private void ItemsGrid1_ItemClicked(object sender, CrystalDecisions.Enterprise.WebControls.ItemEventArgs e)
		{			
			if (e.ItemType == "CrystalEnterprise.Report")
			{
				if (rbViewReport.Checked) 
					//Response.Redirect("ViewRpt.aspx?ID=" + e.ItemID.ToString());
					Response.Redirect("CrystalReportsViewer.aspx?ID=" + e.ItemID.ToString());

				if (rbReportHistory.Checked)
					Response.Redirect("ReportHistory.aspx?ID=" + e.ItemID.ToString());
			
				if (rbScheduleReport.Checked)
					Response.Redirect("Schedule.aspx?ID=" + e.ItemID.ToString());

				if (rbDatabaseLogon.Checked)
					Response.Redirect("DatabaseLogon.aspx?ID=" + e.ItemID.ToString());

				if (rbFilters.Checked)
					Response.Redirect("Filters.aspx?ID=" + e.ItemID.ToString());

				if (rbFormat.Checked)
					Response.Redirect("Format.aspx?ID=" + e.ItemID.ToString());

				if (rbParameters.Checked)
					Response.Redirect("Parameters.aspx?ID=" + e.ItemID.ToString());

				if (rbPrint.Checked)
					Response.Redirect("Print.aspx?ID=" + e.ItemID.ToString());

				if (rbDestination.Checked)
					Response.Redirect("Destination.aspx?ID=" + e.ItemID.ToString());				
			}
		}
	}
}
