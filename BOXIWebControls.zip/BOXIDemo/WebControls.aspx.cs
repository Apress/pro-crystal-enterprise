using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Enterprise.WebControls; 

namespace BOXIDemo
{
	/// <summary>
	/// Summary description for WebControls.
	/// </summary>
	public class WebControls : System.Web.UI.Page
	{
		protected CrystalDecisions.Enterprise.WebControls.Logon Logon1;
		protected CrystalDecisions.Enterprise.WebControls.Identity identity1;
		private System.ComponentModel.IContainer components;
	
		//Listing 6-27
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				identity1.UserName ="Administrator";
				identity1.System = "seton-notebook:6400"; 
				identity1.SelectedAuthentication = "Enterprise";

				//Let's get creative with the button text
				Logon1.LogonButton.Text = "Enter BO XI"; 
				Logon1.LogoffButton.Text = "Say goodbye to BO XI";
 
				Logon1.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
			this.identity1 = new CrystalDecisions.Enterprise.WebControls.Identity(this.components, this, "identity1");
			((System.ComponentModel.ISupportInitialize)(this.identity1)).BeginInit();
			// 
			// Logon1
			// 
			this.Logon1.LogonClicked += new System.EventHandler(this.Logon1_LogonClicked);
			this.Logon1.Identity = this.identity1;
			// 
			// identity1
			// 
			this.identity1.PasswordExpired += new System.EventHandler(this.identity1_PasswordExpired);
			this.identity1.LogonFailed += new CrystalDecisions.Enterprise.ExceptionErrorEventHandler(this.identity1_LogonFailed);
			this.identity1.LoggedOn += new System.EventHandler(this.identity1_LoggedOn);
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.identity1)).EndInit();

		}
		#endregion

		//Listing 6-28
		private void identity1_LoggedOn(object sender, System.EventArgs e)
		{
			Response.Redirect("Folders.aspx"); 
		}

		//Listing 6-29
		private void identity1_LogonFailed(object sender, 
			CrystalDecisions.Enterprise.ExceptionEventArgs e)
		{		
			Response.Redirect("Error.aspx?Error=Not%20authorized");
		}

		//Listing 6-30
		private void identity1_PasswordExpired (object sender, 
			System.EventArgs e)
		{		
			Response.Redirect("NewPassword.aspx"); 
		}

		private void Logon1_LogonClicked(object sender, System.EventArgs e)
		{
		
		}


	}
}
