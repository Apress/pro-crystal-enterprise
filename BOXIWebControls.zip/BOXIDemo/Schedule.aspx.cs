using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Enterprise.WebControls; 

namespace BOXIDemo
{
	/// <summary>
	/// Summary description for Schedule.
	/// </summary>
	public class Schedule : System.Web.UI.Page
	{
		private System.ComponentModel.IContainer components;
		protected CrystalDecisions.Enterprise.WebControls.Schedule Schedule1;
		protected CrystalDecisions.Enterprise.WebControls.EnterpriseItem enterpriseItem1;
		protected CrystalDecisions.Enterprise.WebControls.Identity identity1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			enterpriseItem1.ItemID = Request["id"];

			Schedule1.ShowCalendars = true;
			Schedule1.VisibleSchedules = "Daily,Weekly,Monthly";

			Schedule1.SelectedSchedule = ScheduleType.Weekly; 

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
			this.identity1 = new CrystalDecisions.Enterprise.WebControls.Identity(this.components, this, "identity1");
			this.enterpriseItem1 = new CrystalDecisions.Enterprise.WebControls.EnterpriseItem(this.components, this, "enterpriseItem1", CrystalDecisions.Enterprise.WebControls.StatePersistence.ViewState);
			((System.ComponentModel.ISupportInitialize)(this.identity1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItem1)).BeginInit();
			// 
			// Schedule1
			// 
			this.Schedule1.SubmitClicked += new System.EventHandler(this.Schedule1_SubmitClicked);
			this.Schedule1.ItemSource = this.enterpriseItem1;
			// 
			// enterpriseItem1
			// 
			this.enterpriseItem1.Identity = this.identity1;
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.identity1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItem1)).EndInit();

		}
		#endregion

		//Listing 6-32
		private void Schedule1_SubmitClicked(object sender, System.EventArgs e)
		{
			ScheduleType sSelectedSchedule = Schedule1.SelectedSchedule;

			ScheduleType sScheduleType = Schedule1.SelectedType;

			Schedule1.Submit(enterpriseItem1); 
		}
	}
}
