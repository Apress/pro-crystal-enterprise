using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace BOXIDemo
{
	/// <summary>
	/// Summary description for DatabaseLogon.
	/// </summary>
	public class DatabaseLogon : System.Web.UI.Page
	{
		protected CrystalDecisions.Enterprise.WebControls.EnterpriseItem enterpriseItem1;
		protected CrystalDecisions.Enterprise.WebControls.Identity identity1;
		protected CrystalDecisions.Enterprise.WebControls.ReportDatabaseLogon ReportDatabaseLogon1;
		private System.ComponentModel.IContainer components;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			enterpriseItem1.ItemID = Request["id"];
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
			this.enterpriseItem1 = new CrystalDecisions.Enterprise.WebControls.EnterpriseItem(this.components, this, "enterpriseItem1", CrystalDecisions.Enterprise.WebControls.StatePersistence.ViewState);
			this.identity1 = new CrystalDecisions.Enterprise.WebControls.Identity(this.components, this, "identity1");
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItem1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.identity1)).BeginInit();
			// 
			// ReportDatabaseLogon1
			// 
			this.ReportDatabaseLogon1.SubmitClicked += new System.EventHandler(this.ReportDatabaseLogon1_SubmitClicked);
			this.ReportDatabaseLogon1.ItemSource = this.enterpriseItem1;
			// 
			// enterpriseItem1
			// 
			this.enterpriseItem1.Identity = this.identity1;
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItem1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.identity1)).EndInit();

		}
		#endregion

		private void ReportDatabaseLogon1_SubmitClicked(object sender, System.EventArgs e)
		{
			//ReportDatabaseLogon1.
			
		}
	}
}
