using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Enterprise; 
using CrystalDecisions.Enterprise.Dest;
using CrystalDecisions.Enterprise.Desktop;


namespace BOXIDemo
{
	/// <summary>
	/// Summary description for StreamReport.
	/// </summary>
	public class StreamReport : System.Web.UI.Page
	{
		protected CrystalDecisions.Enterprise.WebControls.EnterpriseItem enterpriseItem1;
		protected CrystalDecisions.Enterprise.WebControls.Identity identity1;
		private System.ComponentModel.IContainer components;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string szID = Request["id"];

			enterpriseItem1.ItemID = szID;

			Report2Browser();
		}

		//Listing 6-35
		private void Report2Browser()
		{
			InfoObject oInfoObject;
			Excel oExcel;
			Pdf oPdf;
			byte[] aReportData = null;
			string szFilename = String.Empty;
			string szMimeType = String.Empty;

			oInfoObject = enterpriseItem1.InfoObject;

			switch(oInfoObject.Kind)
			{
				case "Excel":
					oExcel = ((Excel) oInfoObject);
					aReportData = ((byte[]) oExcel.ByteStream);
					szFilename = oExcel.Title + ".xls";
					szMimeType = oExcel.MimeType;
					break;

				case "Pdf":
					oPdf = ((Pdf) oInfoObject);
					aReportData = ((byte[]) oPdf.ByteStream);
					szFilename = oPdf.Title + ".pdf";
					szMimeType = oPdf.MimeType;
					break;
			}

			Response.Clear();
			Response.AddHeader("Content-Length", aReportData.Length.ToString());
			Response.AddHeader("Content-Disposition", 
				String.Format("inline; filename={0};", szFilename));
			Response.ContentType = szMimeType;
			Response.BinaryWrite(aReportData);
			Response.Flush();
			Response.End();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
			this.enterpriseItem1 = new CrystalDecisions.Enterprise.WebControls.EnterpriseItem(this.components, this, "enterpriseItem1", CrystalDecisions.Enterprise.WebControls.StatePersistence.ViewState);
			this.identity1 = new CrystalDecisions.Enterprise.WebControls.Identity(this.components, this, "identity1");
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItem1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.identity1)).BeginInit();
			// 
			// enterpriseItem1
			// 
			this.enterpriseItem1.Identity = this.identity1;
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.enterpriseItem1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.identity1)).EndInit();

		}
		#endregion
	}
}
