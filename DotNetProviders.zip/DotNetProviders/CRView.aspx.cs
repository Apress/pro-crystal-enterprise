using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Enterprise;
using BusinessObjects.Enterprise.Providers;
using CrystalDecisions.Enterprise.Viewing;
using CrystalDecisions.ReportAppServer.Controllers;

public partial class CRView : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string kind = Request.QueryString.Get("kind");
        if (string.IsNullOrEmpty(kind))
        {
            Label1.Text = "Fail to view report, kind is not provided";
            return;
        }

        if (kind != "CrystalReport")
        {
            Label1.Text = "Fail to view report, kind is not CrystalReport";
            return;
        }

        string idStr = Request.QueryString.Get("id");
        if (string.IsNullOrEmpty(idStr))
        {
            Label1.Text = "Fail to view report, no ID provided";
            return;
        }

        // Get the session id
        BOEMembershipProvider boep = (BOEMembershipProvider)Membership.Provider;
        string sessionID = boep.BOESessionID;

        SessionMgr sessionMgr = null;
        EnterpriseSession enterpriseSession = null;
        try
        {
            // Recreate the session and get a ReportFactory
            sessionMgr = new SessionMgr();
            enterpriseSession = sessionMgr.GetSession(sessionID);
            EnterpriseService svc = enterpriseSession.GetService("PSReportFactory");
            PSReportFactory rptFactory = (PSReportFactory)svc.Interface;

            Label1.Text = "Report " + idStr;
            int itemID = Int32.Parse(idStr);

            ISCRReportSource rptSource = rptFactory.OpenReportSource(itemID);
            CRViewer.ReportSource = rptSource;
        }
        catch (Exception ex)
        {
            Label1.Text = "Failed to view report: " + ex.Message;
        }
        finally
        {
            if (enterpriseSession != null)
                enterpriseSession.Dispose();

            if (sessionMgr != null)
                sessionMgr.Dispose();
        }
    }
}
