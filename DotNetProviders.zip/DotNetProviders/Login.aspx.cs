using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessObjects.Enterprise.Providers;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Register for some events the the BOE membership provider supports
        BOEMembershipProvider boeprovider = (BOEMembershipProvider)Membership.Provider;
        boeprovider.LogonFailed += new BOEOperationFailedEventHandler(DoLogonFailed);
        boeprovider.PasswordExpired += new EventHandler(DoPasswordExpired);
        Session["PasswordExpired"] = false;

        // We always want to display the Login page in the full window rather than inside a frame.
        string str = "<script language=JavaScript>if (top.location != location){top.location.href = document.location.href;}</script>";
        ClientScript.RegisterStartupScript(GetType(), "FrameBreakout", str);
    }

    void DoLogonFailed(object sender, BOEOperationFailedEventArgs e)
    {
        // Just display the error message in the login control.
        LoginCtrl.FailureText = e.Message;
    }

    void DoPasswordExpired(object sender, EventArgs e)
    {
        // Set a session variable that is checked by Toolbar.aspx to detect
        // that the user must change their password.
        Session["PasswordExpired"] = true;
    }
}
