using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessObjects.Enterprise.Providers;

public partial class TreeView : System.Web.UI.Page
{
    // Default to use folder mode.
    private string m_mode = "f";

    protected void Page_Load(object sender, EventArgs e)
    {
        m_mode = Request.QueryString.Get("mode");

        // Default to folder mode
        if (string.IsNullOrEmpty(m_mode))
            m_mode = "f";

        if (m_mode == "c")
        {
            // Category mode: only show categories
            if (BOEHierarchicalDataSource.Mode != HierarchyMode.Category)
            {
                BOEHierarchicalDataSource.Mode = HierarchyMode.Category;
                BOEHierarchicalDataSource.Home = "";
                BOEHierarchicalDataSource.QueryFilter = "si_kind in ('Category', 'PersonalCategory')";
                BOEHierarchicalDataSource.Roots.Clear();
                BOEHierarchicalDataSource.Roots.Add(new Root(45));
            }
        }
        else
        {
            // Folder mode: only show folders
            if (BOEHierarchicalDataSource.Mode != HierarchyMode.Folder)
            {
                BOEHierarchicalDataSource.Mode = HierarchyMode.Folder;
                BOEHierarchicalDataSource.Home = "SampleHome";
                BOEHierarchicalDataSource.QueryFilter = "si_kind in ('Folder', 'FavoritesFolder', 'Inbox')";
                BOEHierarchicalDataSource.Roots.Clear();
            }
        }
    }

    protected void DoRefreshButtonClicked(object sender, EventArgs e)
    {
        TreeViewCtrl.DataBind();
    }

    protected void DoSelectedNodeChanged(object sender, EventArgs e)
    {
        // Determine which node was selected and get the corresponding object ID.
        string path = TreeViewCtrl.SelectedNode.DataPath;
        int id = BOEHierarchicalDataSourceView.ExtractIDFromViewPath(path);

        // Trigger Content.aspx to refresh using the new ID.
        string str = "<script language=JavaScript>parent.content.location.href='" +
                        "Content.aspx?id=" + id.ToString() + "&mode=" + m_mode + "'</script>";
        ClientScript.RegisterStartupScript(GetType(), "LoadContent", str);
    }
}
