using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Enterprise;
using BusinessObjects.Enterprise.Providers;

public partial class View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string kind = Request.QueryString.Get("kind");
        string idStr = Request.QueryString.Get("id");

        if (string.IsNullOrEmpty(idStr))
            ErrorLabel.Text = "Fail to view: no ID provided";
        else if (string.IsNullOrEmpty(kind))
            ErrorLabel.Text = "Fail to view: kind is not provided";
        else
        {
            if (kind == "CrystalReport")
            {
                // Go to view crystal report
                Server.Transfer("CRView.aspx?id=" + idStr + "&kind=" + kind);
            }
            else
            {
                // Get the session id
                BOEMembershipProvider boep = (BOEMembershipProvider)Membership.Provider;
                string sessionID = boep.BOESessionID;

                // Recreate the session and get a logon token
                SessionMgr sessionMgr = null;
                EnterpriseSession enterpriseSession = null;
                LogonTokenMgr tokenMgr = null;
                try
                {
                    sessionMgr = new SessionMgr();
                    enterpriseSession  = sessionMgr.GetSession(sessionID);
                    tokenMgr = enterpriseSession.LogonTokenMgr;
                    string logontoken = tokenMgr.CreateWCAToken(enterpriseSession.CMSName, 1, 100);

                    //Use InfoView's OpenDoc to view other data types.
                    string str = "http://localhost/businessobjects/enterprise115/InfoView/scripts/openDocument.aspx?iDocID=" +
                                    idStr + "&token=" + logontoken;
                    Response.Redirect(str);
                }
                catch (Exception ex)
                {
                    ErrorLabel.Text = "Fail to view: error retrieving logon token: " + ex.Message;
                }
                finally
                {
                    if (tokenMgr != null)
                        tokenMgr.Dispose();

                    if (enterpriseSession != null)
                        enterpriseSession.Dispose();

                    if (sessionMgr != null)
                        sessionMgr.Dispose();
                }
            }
        }
    }
}
