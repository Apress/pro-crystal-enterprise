using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class History : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string idStr = Request.QueryString.Get("id");

        // Get objects that are instances of this object
        string query = "select SI_ID, SI_NAME,SI_KIND, SI_DESCRIPTION, SI_CUID, SI_INSTANCE, SI_RECURRING," +
                        "SI_SCHEDULEINFO.SI_UISTATUS,SI_SCHEDULEINFO.SI_OUTCOME " +
                        "from ci_infoobjects where si_parentid = " + idStr;
        InstanceListDS.SelectCommand = query;
    }

    protected void DoRowSelected(object sender, EventArgs e)
    {
        int selectedID = (int)InstanceList.SelectedValue;

        String query = "select SI_ID, SI_NAME,SI_KIND, SI_DESCRIPTION, SI_CUID, SI_INSTANCE, SI_RECURRING,SI_SCHEDULEINFO.SI_UISTATUS,SI_SCHEDULEINFO.SI_OUTCOME from ci_infoobjects where si_id =" + selectedID.ToString();
        InstanceDetailsDS.SelectCommand = query;
    }
}
