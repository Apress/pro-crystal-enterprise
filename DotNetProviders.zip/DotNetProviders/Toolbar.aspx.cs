using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessObjects.Enterprise.Providers;

public partial class Toolbar : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Check to see if the user needs to change their password
        Boolean pwdExpired = false;
        Object obj = Session["PasswordExpired"];
        if (obj != null)
            pwdExpired = (Boolean)obj;
        if (pwdExpired)
        {
            DoChangePwdButtonClick(this, EventArgs.Empty);
            Session["PasswordExpired"] = false;
        }
    }

    protected void DoChangePwdButtonClick(object sender, EventArgs e)
    {
        string str = "<script language=JavaScript>parent.content.location.href='ChangePassword.aspx'</script>";
        ClientScript.RegisterStartupScript(GetType(), "ChangePwd", str);
    }

    protected void DoFindUsersButtonClick(object sender, EventArgs e)
    {
        string str = "<script language=JavaScript>parent.content.location.href='FindUsers.aspx'</script>";
        ClientScript.RegisterStartupScript(GetType(), "FindUsers", str);
    }

    protected void DoFolderViewButtonClick(object sender, EventArgs e)
    {
        string str = "<script language=JavaScript>parent.navi.location.href='TreeView.aspx?mode=f'</script>";
        ClientScript.RegisterStartupScript(GetType(), "FolderView", str);
    }

    protected void DoCategoryViewButtonClick(object sender, EventArgs e)
    {
        string str = "<script language=JavaScript>parent.navi.location.href='TreeView.aspx?mode=c'</script>";
        ClientScript.RegisterStartupScript(GetType(), "CategoryView", str);
    }

    protected void DoLoggingOut(object sender, LoginCancelEventArgs e)
    {
        // Logoff from the CMS.
        BOEMembershipProvider boeProvider = (BOEMembershipProvider)Membership.Provider;
        boeProvider.Logoff();
    }
}
