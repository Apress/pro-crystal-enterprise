using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Enterprise;
using BusinessObjects.Enterprise.Providers;

public partial class Schedule : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string kind = Request.QueryString.Get("kind");
        if (string.IsNullOrEmpty(kind))
        {
            SchedulingLabel.Text = "Disable scheduling: kind is not provided";
            return;
        }

        if (kind != "CrystalReport")
        {
            SchedulingLabel.Text = "Disable scheduling: kind is not CrystalReport";
            return;
        }

        string idStr = Request.QueryString.Get("id");
        if (string.IsNullOrEmpty(idStr))
        {
            SchedulingLabel.Text = "Disable scheduling: no ID provided";
            return;
        }

        ScheduleTypeRadioButton.Enabled = true;
        ScheduleButton.Enabled = true;
        IdLabel.Text = idStr;
        KindLabel.Text = kind;
    }
    protected void DoScheduleButtonClicked(object sender, EventArgs e)
    {
        // Get the session id
        BOEMembershipProvider boep = (BOEMembershipProvider)Membership.Provider;
        string sessionID = boep.BOESessionID;

        SessionMgr sessionMgr = null;
        EnterpriseSession enterpriseSession = null;
        InfoStore infoStore = null;
        try 
        {
            // Recreate the session and get an InfoStore
            sessionMgr = new SessionMgr();
            enterpriseSession = sessionMgr.GetSession(sessionID);
            infoStore = (InfoStore)enterpriseSession.GetService("InfoStore");

            // Query for the InfoObject that will be scheduled.
            string query = "select SI_SCHEDULEINFO  from ci_infoobjects where si_id=" + IdLabel.Text;
            InfoObjects objs = infoStore.Query(query);
            InfoObject obj = objs[1];
            SchedulingInfo schedInfo = obj.SchedulingInfo;

            // Set the schedule type 
            int selectedIndex = ScheduleTypeRadioButton.SelectedIndex;
            switch (selectedIndex)
            {
                case 0:
                    schedInfo.Type = CeScheduleType.ceScheduleTypeOnce;
                    schedInfo.RightNow = true;
                    break;
                case 1:
                    schedInfo.Type = CeScheduleType.ceScheduleTypeHourly;
                    schedInfo.RightNow = false;
                    break;
                case 2:
                    schedInfo.Type = CeScheduleType.ceScheduleTypeDaily;
                    schedInfo.RightNow = false;
                    break;
                default:
                    SchedulingLabel.Text = "Error: Unknown schedule type.";
                    break;
            }

            // Actually schedule the object and go to the history page to display it.
            infoStore.Schedule(objs);
            Server.Transfer("History.aspx?id=" + IdLabel.Text + "&kind=" + KindLabel.Text);
        }
        catch (Exception ex)
        {
            SchedulingLabel.Text = "Error: " + ex.Message;
        }
        finally
        {
            if (infoStore != null)
                infoStore.Dispose();

            if (enterpriseSession != null)
                enterpriseSession.Dispose();

            if (sessionMgr != null)
                sessionMgr.Dispose();
        }
    }
}
