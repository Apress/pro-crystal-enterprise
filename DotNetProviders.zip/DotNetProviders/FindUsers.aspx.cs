using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessObjects.Enterprise.Providers;

public partial class FindUsers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void DoFindButtonClicked(object sender, EventArgs e)
    {
        // Do the search.
        BOEMembershipProvider boep = (BOEMembershipProvider)Membership.Provider;
        int totalRecords = -1;
        MembershipUserCollection users = null;

        try
        {
            users = boep.FindUsersByName(SearchTextBox.Text, Int32.Parse(IndexTextBox.Text), Int32.Parse(PageSizeTextBox.Text), out totalRecords);
        }
        catch (Exception ex)
        {
            TotalCountLabel.Text = "Total: " + totalRecords.ToString();
            ResultsLabel.Text = "Error: " + ex.Message;
            return;
        }

        // Display the total record count.
        TotalCountLabel.Text = "Total: " + totalRecords.ToString();

        // Loop through users that match the search
        string msg = "";
        int index = 0;
        foreach (MembershipUser user in users)
        {
            msg += "[" + index + "]: " + user.ProviderUserKey + ", " + user.UserName + "<BR>";
            index++;
        }

        ResultsLabel.Text = msg;
    }
}
