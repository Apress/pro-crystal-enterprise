using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.Enterprise;
using BusinessObjects.Enterprise.Desktop;
using BusinessObjects.Enterprise.Providers;

public partial class Content : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string idStr = Request.QueryString.Get("id");
        string modeStr = Request.QueryString.Get("mode");

        if (string.IsNullOrEmpty(modeStr))
        {
            // Default to folder mode.
            modeStr = "f";
        }

        if (string.IsNullOrEmpty(idStr))
        {
            // Default to root folder.
            idStr = "23";
        }

        InfoLabel.Text = "ID:" + idStr + ", Mode:" + modeStr;

        if (modeStr == "c")
        {
            // Get the session id
            BOEMembershipProvider boep = (BOEMembershipProvider)Membership.Provider;
            string sessionID = boep.BOESessionID;

            // Recreate the session and get an InfoStore
            SessionMgr sessionMgr = null;
            EnterpriseSession enterpriseSession = null;
            InfoStore infoStore = null;
            try
            {
                sessionMgr = new SessionMgr();
                enterpriseSession = sessionMgr.GetSession(sessionID);
                infoStore = (InfoStore)enterpriseSession.GetService("InfoStore");

                // Get the ID's of the objects in the specified category.
                string query = "select si_documents from ci_infoobjects where si_id=" + idStr;
                InfoObjects objs = infoStore.Query(query);

                if (objs.Count < 1 || !(objs[1] is Category))
                {
                    // The selected object isn't really a category
                    BOEDataSource.SelectCommand = "";
                    return;
                }

                Category cat = (Category)objs[1];
                ObjectRelativeIDs objIDs = cat.Documents;

                if (objIDs.Count < 1)
                {
                    // There are no objects in the category so just set a blank query
                    BOEDataSource.SelectCommand = "";
                }
                else
                {
                    // Objects exist in the category so build up a query to retrieve them.
                    query = "select SI_ID, SI_NAME,SI_KIND from ci_infoobjects where si_id in (" + objIDs[1].ToString();
                    for (int i = 2; i <= objIDs.Count; i++)
                    {
                        query += ", " + objIDs[i].ToString();
                    }

                    query += ") order by si_id";
                    BOEDataSource.SelectCommand = query;
                }
            }
            catch (Exception)
            {
                BOEDataSource.SelectCommand = "";
            }
            finally
            {
                if (infoStore != null)
                    infoStore.Dispose();

                if (enterpriseSession != null)
                    enterpriseSession.Dispose();

                if (sessionMgr != null)
                    sessionMgr.Dispose();
            }
        }
        else
        {
            // Get infoobjects that are not folder
            string query = "select SI_ID, SI_NAME,SI_KIND from ci_infoobjects where si_parentid = " + idStr + 
                                " and si_kind != 'Folder' order by si_id";
            BOEDataSource.SelectCommand = query;
        }
    }
}
