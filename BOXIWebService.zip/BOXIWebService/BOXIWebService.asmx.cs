using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Xml;
using CrystalDecisions.Enterprise; 
using CrystalDecisions.Enterprise.Dest;
using CrystalDecisions.Enterprise.Desktop;
using CrystalDecisions.Enterprise.Admin;
using CrystalDecisions.CrystalReports; 
using BusinessObjects.Enterprise.Desktop;
using CrystalDecisions.ReportAppServer.ClientDoc;
using CrystalDecisions.ReportAppServer.Controllers;
using CrystalDecisions.ReportAppServer.DataDefModel;
using CrystalDecisions.ReportAppServer.CommonObjectModel;
using CrystalDecisions.ReportAppServer.ObjectFactory;
using CrystalDecisions.ReportAppServer.ReportDefModel;
using ActiveDs;
using System.DirectoryServices;


public enum CEResponse 
{ 
	Base64EncodedString = 0, 
	ServerFile = 1 
}

public enum CEOptions 
{ 
	No = 0,
	Yes = 1, 
	Both = 2
}
	
namespace BOXIWebService
{
	public class BOXIWebService : System.Web.Services.WebService
	{
				
		public BOXIWebService()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}
		
		#endregion


		#region Folders

		#region GetApplications

		//Listing 5-1
		[WebMethod(MessageName="GetApplicationsViaLogonID")] 
		public System.Data.DataSet GetApplications(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication)
		{	
			return GetApplications(szUserID, szPassword, szSystem, szAuthentication, null);
		}

		[WebMethod(MessageName="GetApplicationsViaServer")] 
		public System.Data.DataSet GetApplications(string szServer)
		{	
			return GetApplications(null, null, null, null, szServer);
		}
	
		private System.Data.DataSet GetApplications(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer)
		{		
			//Listing 5-13
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;

			//Listing 5-14
			oEnterpriseSession = GetIdentity(szUserID, szPassword, 
				szSystem, szAuthentication, szServer);	

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Listing 5-15
			try
			{
				szSQL = "Select SI_ID, SI_NAME " + 
					"From CI_INFOOBJECTS " + 
					"Where SI_KIND = 'Folder' " + 
					"And SI_PARENTID = 0 " + 
					"Order By SI_NAME";

				oInfoObjects = oInfoStore.Query(szSQL);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			//Listing 5-16
			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("Name"));

			foreach (InfoObject oInfoObject in oInfoObjects)
			{
				oDR = oDT.NewRow();

				oDR["ID"] = oInfoObject.Properties["SI_ID"]; 
				oDR["Name"] = oInfoObject.Properties["SI_NAME"]; 

				oDT.Rows.Add(oDR);  
			}

			//Listing 5-17
			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose();
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);  

			return oDS;
		}

		#endregion

		#region CreateFolder

		//Listing 5-19
		[WebMethod(MessageName="CreateFolderViaLogonID")] 
		public string CreateFolder(string szUserID, string szPassword, string szSystem, string szAuthentication, string szFolderName, int iParentFolderID)
		{	
			return CreateFolder(szUserID, szPassword, szSystem, szAuthentication, null, szFolderName, iParentFolderID);
		}

		[WebMethod(MessageName="AddFolderViaServer")] 
		public string CreateFolder(string szServer, string szFolderName, int iParentFolderID)
		{	
			return CreateFolder(null, null, null, null, szServer, szFolderName, iParentFolderID);
		}
	
		private string CreateFolder(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szFolderName, 
			int iParentFolderID)
		{	
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;			
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			Folder oFolder = null;
			string szResult;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			oInfoObjects = oInfoStore.NewInfoObjectCollection();

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("Folder");
			oInfoObject = oInfoObjects.Add(oPluginInfo);
			oFolder = ((Folder) oInfoObject);

			oFolder.Title = szFolderName;
			oFolder.Properties.Add ("SI_PARENTID", iParentFolderID.ToString());

			try
			{
				oInfoStore.Commit(oInfoObjects);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			szResult = oFolder.ID.ToString();

			oEnterpriseSession.Logoff();

			oPluginManager.Dispose();
			oPluginInfo.Dispose(); 
			oFolder.Dispose(); 
			oInfoStore.Dispose();
			oInfoObject.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			return szResult;			
		}

		#endregion

		#region DeleteFolder

		//Listing 5-20
		[WebMethod(MessageName="DeleteFolderViaLogonID")] 
		public void DeleteFolder(string szUserID, string szPassword, string szSystem, string szAuthentication, int iFolderID)
		{	
			DeleteFolder(szUserID, szPassword, szSystem, szAuthentication, null, iFolderID);
		}

		[WebMethod(MessageName="DeleteFolderViaServer")] 
		public void DeleteFolder(string szServer, int iFolderID)
		{	
			DeleteFolder(null, null, null, null, szServer, iFolderID);
		}
	
		private void DeleteFolder(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			int iFolderID)
		{	
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			Folder oFolder = null;
			string szSQL = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				szSQL = "SELECT SI_ID " + 
					"FROM CI_INFOOBJECTS " + 
					"WHERE SI_ID = " + iFolderID.ToString();

				oInfoObjects = oInfoStore.Query(szSQL); 
				oInfoObject = oInfoObjects[1]; 
			}
			catch(Exception ex)
			{
				throw ex;
			}

			try
			{
				oFolder = ((Folder) oInfoObject);

				oFolder.DeleteNow();

				oInfoStore.Commit(oInfoObjects);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oEnterpriseSession.Logoff();

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

		}

		#endregion

		#endregion

		#region Reports

		#region GetReports

		[WebMethod(MessageName="GetReportsViaLogonID")] 
		public System.Data.DataSet GetReports(string szUserID, string szPassword, string szSystem, string szAuthentication, string szReportID)
		{	
			return GetReports(szUserID, szPassword, szSystem, szAuthentication, null, szReportID);
		}

		[WebMethod(MessageName="GetReportsViaServer")] 
		public System.Data.DataSet GetReports(string szServer, string szReportID)
		{	
			return GetReports(null, null, null, null, szServer, szReportID);
		}

		[WebMethod]
		public System.Data.DataSet GetReports(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szReportID)
		{			
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Listing 5-18
			try
			{
				szSQL = "Select SI_ID, SI_NAME " + 
					"From CI_INFOOBJECTS " + 
					"Where SI_KIND = 'CrystalReport' " + 
					"And SI_INSTANCE = 0 " + 
					"And SI_PARENTID = " + szReportID + 
					" Order By SI_NAME";

				oInfoObjects = oInfoStore.Query(szSQL);
			}			
			catch(Exception ex)
			{
				throw ex;
			}

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("Name"));

			foreach (InfoObject oInfoObject in oInfoObjects)
			{
				oDR = oDT.NewRow();
 
				oDR["ID"] = oInfoObject.Properties["SI_ID"]; 
				oDR["Name"] = oInfoObject.Properties["SI_NAME"]; 

				oDT.Rows.Add(oDR);  
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);  

			return oDS;
		}

		#endregion

		#region GetReportHistory

		//Listing 5-21
		[WebMethod(MessageName="GetReportHistoryViaLogonID")] 
		public System.Data.DataSet GetReportHistory(string szUserID, string szPassword, string szSystem, string szAuthentication, string szParentID)
		{	
			return GetReportHistory(szUserID, szPassword, szSystem, szAuthentication, null, szParentID);
		}

		[WebMethod(MessageName="GetReportHistoryViaServer")] 
		public System.Data.DataSet GetReportHistory(string szServer, string szParentID)
		{	
			return GetReportHistory(null, null, null, null, szServer, szParentID);
		}

		[WebMethod]
		public System.Data.DataSet GetReportHistory(string szUserID, string szPassword, string szSystem, string szAuthentication, string szServer, string szParentID)
		{			
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL = string.Empty;
			string szFormat = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				szSQL = "Select SI_ID, SI_NAME, SI_CREATION_TIME, " +
					"SI_SCHEDULE_STATUS, SI_KIND, SI_PROCESSINFO.SI_PROMPTS " +
					"From CI_INFOOBJECTS " +
					"Where SI_PARENTID = " + szParentID + 
					" And SI_INSTANCE != 0 " +
					"Order By SI_CREATION_TIME DESC";

				oInfoObjects = oInfoStore.Query(szSQL);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("Name"));
			oDT.Columns.Add(new DataColumn("CreationDate"));
			oDT.Columns.Add(new DataColumn("Status"));
			oDT.Columns.Add(new DataColumn("Format"));
			oDT.Columns.Add(new DataColumn("Parameters"));

			foreach (InfoObject oInfoObject in oInfoObjects)
			{
				switch (oInfoObject.Properties["SI_KIND"].ToString())
				{
					case "CrystalReport":
						szFormat = "Crystal Report";
						break;

					case "Pdf":
						szFormat = "Acrobat PDF";
						break;

					case "Excel":
						szFormat = "Microsoft Excel";
						break;

					case "Word":
						szFormat = "Microsoft Word";
						break;
				}

				oDR = oDT.NewRow();

				oDR["ID"] = oInfoObject.Properties["SI_ID"].ToString(); 
				oDR["Name"] = oInfoObject.Properties["SI_NAME"].ToString(); 
				oDR["CreationDate"] = oInfoObject.Properties["SI_CREATION_TIME"].ToString(); 
				oDR["Status"] = GetScheduleStatus(((CeScheduleStatus) 
					int.Parse(oInfoObject.Properties["SI_SCHEDULE_STATUS"].ToString())));
				oDR["Format"] = szFormat;
				oDR["Parameters"] = GetParameters(oInfoObject.ProcessingInfo);

				oDT.Rows.Add(oDR);  
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);  

			return oDS;
		}

		//Listing 5-22
		private string GetParameters(ProcessingInfo oProcessingInfo)
		{
			System.Text.StringBuilder oResult = null;  
			Property oProperty;
			int iCnt = 0;
			string szPromptName;
			string szPromptValue;

			oResult = new System.Text.StringBuilder();

			//How many prompts are there
			iCnt = ((int) oProcessingInfo.Properties["SI_PROMPTS"].Properties["SI_NUM_PROMPTS"].Value);
 
			if (iCnt != 0)
			{
				//start iterating at the second property
				for (int i=2; i<=iCnt+1; i++)
				{	
					//Let's abbreviate our code a bit
					oProperty = oProcessingInfo.Properties["SI_PROMPTS"].Properties[i];

					//Get the name
					szPromptName = ((string) oProperty.Properties["SI_NAME"].Value);

					try
					{
						szPromptValue = ((string) oProperty.Properties["SI_CURRENT_VALUES"].
							Properties["SI_VALUE1"].Properties["SI_DATA"].Value);
					}
					catch 
					{
						szPromptValue = string.Empty;
					}

					oResult.Append(szPromptName);
					oResult.Append(": ");
					oResult.Append(szPromptValue);
					oResult.Append("\n");

				}
			}

			return oResult.ToString();
		}

		private string GetScheduleStatus(CeScheduleStatus sCeScheduleStatus)
		{
			string szStatus = string.Empty;

			switch (sCeScheduleStatus)
			{
				case CeScheduleStatus.ceStatusFailure: 
					szStatus = "Failure";
					break;

				case CeScheduleStatus.ceStatusPaused: 
					szStatus = "Paused";
					break;

				case CeScheduleStatus.ceStatusPending: 
					szStatus = "Pending";
					break;

				case CeScheduleStatus.ceStatusRunning: 
					szStatus = "Running";
					break;

				case CeScheduleStatus.ceStatusSuccess: 
					szStatus = "Success";
					break;
			}

			return szStatus;

		}


		private string GetFormatType(string szKind)		
		{
			string szFormat = string.Empty;

			switch (szKind)
			{
				case "CrystalReport":
					szFormat = "Crystal Report";
					break;

				case "Pdf":
					szFormat = "Acrobat PDF";
					break;

				case "Excel":
					szFormat = "Microsoft Excel";
					break;

				case "Word":
					szFormat = "Microsoft Word";
					break;

				case "Powerpoint":
					szFormat = "Microsoft PowerPoint";
					break;

				case "Rtf":
					szFormat = "Rich Text Format";
					break;

				case "Txt":
					szFormat = "ASCII";
					break;
			}

			return szFormat;
		}

		#endregion

		#region LoadReport
		
		//Listing 5-23
		[WebMethod(MessageName="LoadReportViaLogonID")] 
		public string LoadReport(string szUserID, string szPassword, string szSystem, string szAuthentication, int iFolderID, string szReportName)
		{	
			return LoadReport(szUserID, szPassword, szSystem, szAuthentication, null, iFolderID, szReportName);
		}

		[WebMethod(MessageName="LoadReportViaServer")] 
		public string LoadReport(string szServer, int iFolderID, string szReportName)
		{	
			return LoadReport(null, null, null, null, szServer, iFolderID, szReportName);
		}
	
		private string LoadReport(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			int iFolderID,
			string szReportName)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			Report oReport = null;
			string szSQL = string.Empty;
			string szResult = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 
			
			try
			{
				szSQL = "SELECT SI_ID " + 
					"FROM CI_INFOOBJECTS " + 
					"WHERE SI_ID = " + iFolderID.ToString() + 
					"AND SI_KIND = 'Folder'";

				oInfoObjects = oInfoStore.Query(szSQL); 
				oInfoObject = oInfoObjects[1]; 
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oInfoObjects = oInfoStore.NewInfoObjectCollection();

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("Report");
			oInfoObject = oInfoObjects.Add(oPluginInfo);
			oReport = ((Report) oInfoObject);

			oReport.Files.Add(szReportName);			
			oReport.Properties.Add ("SI_PARENTID", iFolderID.ToString());
			oReport.EnableThumbnail = true;

			oInfoStore.Commit(oInfoObjects);

			szResult = oReport.ID.ToString();

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObject.Dispose();
			oInfoObjects.Dispose();
			oPluginManager.Dispose();
			oPluginInfo.Dispose();
			oReport.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			return szResult;
		}

		#endregion

		#region GetReportLimits
		
		[WebMethod(MessageName="GetReportLimitsViaLogonID")] 
		public System.Data.DataSet GetReportLimits(string szUserID, string szPassword, string szSystem, string szAuthentication, string szReportID)
		{	
			return GetReportLimits(szUserID, szPassword, szSystem, szAuthentication, null, szReportID);
		}

		[WebMethod(MessageName="GetReportLimitsViaServer")] 
		public System.Data.DataSet GetReportLimits(string szServer, string szReportID)
		{	
			return GetReportLimits(null, null, null, null, szServer, szReportID);
		}
	
		private System.Data.DataSet GetReportLimits(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szReport)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			Report oReport = null;
			System.Data.DataSet oDS = null;
			DataTable oDT = null;
			DataRow oDR = null;
			string szSQL = string.Empty;
			string szResult = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);
			
			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " + 
					"FROM CI_INFOOBJECTS " + 
					"WHERE SI_ID = " + szReport;

				oInfoObjects = oInfoStore.Query(szSQL); 
				oInfoObject = oInfoObjects[1]; 
				oReport = ((Report) oInfoObject);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("Description"));
			oDT.Columns.Add(new DataColumn("Inherited"));
			oDT.Columns.Add(new DataColumn("UseMaximumValue"));
			oDT.Columns.Add(new DataColumn("Value"));

			foreach (SecurityLimit oSecurityLimit in oReport.SecurityInfo.KnownLimits)
			{
				oDR = oDT.NewRow();

				oDR["ID"] = oSecurityLimit.ID; 
				oDR["Description"] = oSecurityLimit.Description;  
				oDR["Inherited"] = oSecurityLimit.Inherited;
				oDR["UseMaximumValue"] = oSecurityLimit.UseMaximumValue; 
				oDR["Value"] = oSecurityLimit.Value; 

				oDT.Rows.Add(oDR); 
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObject.Dispose();
			oInfoObjects.Dispose();
			oReport.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;
 
			oDS = new System.Data.DataSet();
 
			oDS.Tables.Add(oDT);  

			return oDS;
		}

		#endregion

		#region LoadProgram
		
		//Listing 5-28
		[WebMethod(MessageName="LoadProgramViaLogonID")] 
		public string LoadProgram(string szUserID, 
								string szPassword, 
								string szSystem, 
								string szAuthentication, 
								int iFolderID, 
								string szTitle,
								string szProgramFileName, 
								string szAuxiliaryFileName, 
								string szArgs, 
								string szUserName, 
								string szUserPassword)
		{	
			return LoadProgram(szUserID, szPassword, szSystem, szAuthentication, null, 
								iFolderID, szTitle, szProgramFileName, szAuxiliaryFileName, szArgs, szUserName, szUserPassword);
		}

		[WebMethod(MessageName="LoadProgramViaServer")] 
		public string LoadProgram(string szServer, 
								int iFolderID, 
								string szTitle,
								string szProgramFileName, 
								string szAuxiliaryFileName, 
								string szArgs, 
								string szUserName, 
								string szUserPassword)
		{	
			return LoadProgram(null, null, null, null, szServer, iFolderID, 
								szTitle, szProgramFileName, szAuxiliaryFileName, szArgs, szUserName, szUserPassword);
		}
	
		private string LoadProgram(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			int iFolderID,
			string szTitle,
			string szProgramFileName,
			string szAuxiliaryFileName,
			string szArgs, 
			string szUserName, 
			string szUserPassword)
		{

			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			Program oProgram = null;
			string szSQL = string.Empty;
			string szResult = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 			

			oInfoObjects = oInfoStore.NewInfoObjectCollection();

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("Program");
			oInfoObject = oInfoObjects.Add(oPluginInfo);
			oProgram = ((Program) oInfoObject);

			oProgram.ParentID = iFolderID;
			oProgram.Title = szTitle;
			oProgram.ProgramType = CeProgramType.ceBinary;
			oProgram.BinaryProgram.File = szProgramFileName;
			oProgram.BinaryProgram.AddFile(szAuxiliaryFileName);
			oProgram.BinaryProgram.Args = szArgs;
			oProgram.BinaryProgram.UserName = szUserName;
			oProgram.BinaryProgram.Password = szUserPassword;

			oInfoStore.Commit(oInfoObjects);

			szResult = oProgram.ID.ToString();

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObject.Dispose();
			oInfoObjects.Dispose();
			oPluginManager.Dispose();
			oPluginInfo.Dispose();
			oProgram.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			return szResult;

		}

		#endregion

		#region Extracting Prompt Settings

		//Listing 5-29
		[WebMethod(MessageName="ExtractingPromptsViaLogonID")] 
		public System.Data.DataSet ExtractingPrompts(string szUserID, string szPassword, string szSystem, string szAuthentication, string szReportID)
		{	
			return ExtractingPrompts(szUserID, szPassword, szSystem, szAuthentication, null, szReportID);
		}

		[WebMethod(MessageName="ExtractingPromptsViaServer")] 
		public System.Data.DataSet ExtractingPrompts(string szServer, string szReportID)
		{	
			return ExtractingPrompts(null, null, null, null, szServer, szReportID);
		}

		[WebMethod]
		public System.Data.DataSet ExtractingPrompts(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szReportID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			InfoObject oInfoObject = null;
			Properties oPropertyBag = null;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;
			string szCnt;
			string szDefaultValue;
			int iCnt;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			szSQL = "Select SI_ID, SI_NAME, SI_PROCESSINFO.SI_PROMPTS " + 
					"From CI_INFOOBJECTS " + 
					"Where SI_ID = " + szReportID;

			oInfoObjects = oInfoStore.Query(szSQL);

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("Name"));
			oDT.Columns.Add(new DataColumn("PromptType"));
			oDT.Columns.Add(new DataColumn("DefaultValue"));

			if (oInfoObjects.Count != 0) 
			{
				oInfoObject = oInfoObjects[1];

				if (HasMember(oInfoObject.ProcessingInfo.Properties, "SI_PROMPTS"))
				{
					//Abbreviate the code a bit
					oPropertyBag = oInfoObject.ProcessingInfo.Properties["SI_PROMPTS"].Properties;

					//How many prompts
					iCnt = ((int) oPropertyBag["SI_NUM_PROMPTS"].Value);
   
					for (int x=1; x<=iCnt; x++)
					{
						szCnt = x.ToString();

						oDR = oDT.NewRow();

						oDR["Name"] = GetPropertyValue(oPropertyBag["SI_PROMPT" + szCnt].
							Properties, "SI_NAME", string.Empty); 
						oDR["PromptType"] = GetPropertyValue(oPropertyBag["SI_PROMPT" + szCnt].
							Properties, "SI_PROMPT_TYPE", "0");
      
						if (HasMember(oPropertyBag["SI_PROMPT" + szCnt].Properties["SI_CURRENT_VALUES"].
							Properties, "SI_VALUE1"))
						{
							szDefaultValue = GetPropertyValue(oPropertyBag["SI_PROMPT" + szCnt].
								Properties["SI_CURRENT_VALUES"].Properties["SI_VALUE1"].
								Properties, "SI_DATA", string.Empty);

							//If it's a date in the BO "DateTime(2006,12,21,0,0,0)"  
							//format let's make it presentable as "12/21/2006"
							if (szDefaultValue.Length > 9 && szDefaultValue.Substring(0, 8) == "DateTime")
								szDefaultValue = FormatInfoStoreDate(szDefaultValue);

							oDR["DefaultValue"] = szDefaultValue;
						}

						oDT.Rows.Add(oDR);  
					}
				}
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);  

			return oDS;
		}

		public static string FormatInfoStoreDate(string szPromptValue)
		{
			string szResult;
			string[] aDate;
			char[] aDelimiters = {','};
			szPromptValue = szPromptValue.Replace("DateTime", string.Empty);  
			szPromptValue = szPromptValue.Replace("(", string.Empty);
			szPromptValue = szPromptValue.Replace(")", string.Empty);
			DateTime dDate;

			aDate = szPromptValue.Split(aDelimiters);

			dDate = new DateTime(int.Parse(aDate[0]), int.Parse(aDate[1]), int.Parse(aDate[2]));
			
			szResult = dDate.ToShortDateString();

			return szResult;
		}

		#endregion

		#region Saving Prompt Settings

		//Listing 5-30
		[WebMethod(MessageName="SavingPromptSettingsViaLogonID")] 
		public void SavingPromptSettings(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szReportID, 
			string szField, 
			string szValue)
		{	
			SavingPromptSettings(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null, 
				szReportID,
				szField,
				szValue);
		}

		[WebMethod(MessageName="SavingPromptSettingsViaServer")] 
		public void SavingPromptSettings(string szServer, 
			string szReportID, 
			string szField, 
			string szValue)
		{	
			SavingPromptSettings(null, 
				null, 
				null, 
				null, 
				szServer, 
				szReportID,
				szField,
				szValue);
		}

		[WebMethod]
		public void SavingPromptSettings(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szReportID, 
			string szField, 
			string szValue)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			InfoObject oInfoObject = null;
			Properties oPropertyBag = null;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;
			string szCnt;
			int iCnt;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			szSQL = "Select SI_ID, SI_NAME, SI_PROCESSINFO.SI_PROMPTS " +   
				"From CI_INFOOBJECTS " +   
				"Where SI_ID = " + szReportID;
         
			oInfoObjects = oInfoStore.Query(szSQL);

			if (oInfoObjects.Count != 0) 
			{
				oInfoObject = oInfoObjects[1];

				//Abbreviate the code a bit
				oPropertyBag = oInfoObject.ProcessingInfo.Properties["SI_PROMPTS"].Properties;

				//How many prompts?
				iCnt = ((int) oPropertyBag["SI_NUM_PROMPTS"].Value);
   
				for (int x=1; x<=iCnt; x++)
				{
					szCnt = x.ToString();

					if (szField == GetPropertyValue(oPropertyBag["SI_PROMPT" + szCnt].
						Properties, "SI_NAME", string.Empty))
					{
						oPropertyBag["SI_PROMPT" + szCnt].Properties["SI_CURRENT_VALUES"].
							Properties["SI_VALUE1"].Properties["SI_DATA"].Value = szValue; 
						break;
					}
				}
			}

			oInfoStore.Commit(oInfoObjects);

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;
		}

		#endregion

		#endregion

		#region Categories

		#region CreateCategory

		//Listing 6-18
		[WebMethod(MessageName="CreateCategoryViaLogonID")] 
		public string CreateCategory(string szUserID, string szPassword, string szSystem, string szAuthentication, string szCategoryName)
		{	
			return CreateCategory(szUserID, szPassword, szSystem, szAuthentication, null, szCategoryName);
		}

		[WebMethod(MessageName="CreateCategoryViaServer")] 
		public string CreateCategory(string szServer, string szCategoryName)
		{	
			return CreateCategory(null, null, null, null, szServer, szCategoryName);
		}
	
		private string CreateCategory(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szCategoryName)
		{	
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;			
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			Category oCategory = null;
			string szResult;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			oInfoObjects = oInfoStore.NewInfoObjectCollection();

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("Category");
			oInfoObject = oInfoObjects.Add(oPluginInfo);
			oCategory = ((Category) oInfoObject);

			oCategory.Title = szCategoryName;

			try
			{
				oInfoStore.Commit(oInfoObjects);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			szResult = oCategory.ID.ToString();

			oEnterpriseSession.Logoff();

			oPluginManager.Dispose();
			oPluginInfo.Dispose(); 
			oCategory = null;
			oInfoStore.Dispose();
			oInfoObject.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			return szResult;			
		}

		#endregion

		#region CreatePersonalCategory

		//Listing 6-19
		[WebMethod(MessageName="CreatePersonalCategoryViaLogonID")] 
		public string CreatePersonalCategory(string szUserID, string szPassword, string szSystem, string szAuthentication, string szCategoryName, int iBOUserID)
		{	
			return CreatePersonalCategory(szUserID, szPassword, szSystem, szAuthentication, null, szCategoryName, iBOUserID);
		}

		[WebMethod(MessageName="CreatePersonalCategoryViaServer")] 
		public string CreatePersonalCategory(string szServer, string szCategoryName, int iBOUserID)
		{	
			return CreatePersonalCategory(null, null, null, null, szServer, szCategoryName, iBOUserID);
		}

		private string CreatePersonalCategory(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szCategoryName,
			int iBOUserID)
		{	
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;			
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			PersonalCategory oPersonalCategory = null;
			string szResult;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			oInfoObjects = oInfoStore.NewInfoObjectCollection();

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("PersonalCategory");
			oInfoObject = oInfoObjects.Add(oPluginInfo);
			oPersonalCategory = ((PersonalCategory) oInfoObject);

			oPersonalCategory.Title = szCategoryName;
			oPersonalCategory.ParentID = iBOUserID;

			try
			{
				oInfoStore.Commit(oInfoObjects);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			szResult = oPersonalCategory.ID.ToString();

			oEnterpriseSession.Logoff();

			oPluginManager.Dispose();
			oPluginInfo.Dispose(); 
			oPersonalCategory = null;
			oInfoStore.Dispose();
			oInfoObject.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			return szResult;			
		}

		#endregion

		#region GetCategories

		//Listing 6-20
		[WebMethod(MessageName="GetCategoriesViaLogonID")] 
		public System.Data.DataSet GetCategories(string szUserID, string szPassword, string szSystem, string szAuthentication, string szID)
		{	
			return GetCategories(szUserID, szPassword, szSystem, szAuthentication, null, szID);
		}

		[WebMethod(MessageName="GetCategoriesViaServer")] 
		public System.Data.DataSet GetCategories(string szServer, string szID)
		{	
			return GetCategories(null, null, null, null, szServer, szID);
		}

		private System.Data.DataSet GetCategories(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szID)
		{	
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			InfoObjects oCategories = null;		
			Properties oPropertyBag;
			System.Data.DataSet oDS = null;
			DataTable oDT = null;
			DataRow oDR = null;
			string szSQL;
			string szField;
			string szType;
			int iCnt;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("Description"));
			oDT.Columns.Add(new DataColumn("Type"));

			//Run this twice for each category type
			for (int x=1; x<=2; x++)
			{
				if (x == 1)
				{
					szField = "SI_CORPORATE_CATEGORIES";
					szType = "Corporate";
				}
				else
				{
					szField = "SI_PERSONAL_CATEGORIES";
					szType = "Personal";
				}

				try
				{
					szSQL = "Select " + szField + 
						" From CI_INFOOBJECTS " + 
						"Where SI_INSTANCE=0 " + 
						"And SI_ID= " + szID;

					oInfoObjects = oInfoStore.Query(szSQL); 
				}
				catch(Exception ex)
				{
					throw ex;
				}


				//How many categories were found
				oPropertyBag = oInfoObjects[1].Properties[szField].Properties;
				iCnt = ((int) oPropertyBag["SI_TOTAL"].Value);

				//For each one extract the name 
				//and add everything to the DataTable
				for (int y=1; y<=iCnt; y++)
				{
					oDR = oDT.NewRow();

					szSQL = "Select SI_NAME " +
						"From CI_INFOOBJECTS " + 
						"Where SI_ID= " + 
						oPropertyBag[y.ToString()].Value;

					oCategories = oInfoStore.Query(szSQL); 

					oDR["ID"] = oCategories[1].ID; 
					oDR["Description"] = oCategories[1].Title;  
					oDR["Type"] = szType;

					oDT.Rows.Add(oDR); 
				}
			}

			oEnterpriseSession.Logoff();

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);
  
			return oDS;
		
		}

		#endregion

		#endregion

		#region GetReportTree

		//Listing 9-38
		[WebMethod(MessageName="GetReportTreeViaLogonID")] 
		public string GetReportTree(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szParentID,
			string szParentName,
			CEOptions sRecurring,
			CEOptions sTemplateHistory,
			bool bFolderInfo,
			bool bBasicInfo,
			bool bPromptInfo,
			bool bLogonInfo,
			bool bScheduleInfo,
			bool bNotificationInfo)
		{			
			return GetReportTree(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null, 
				szParentID, 
				szParentName, 
				sRecurring,
				sTemplateHistory,
				bFolderInfo,
				bBasicInfo,
				bPromptInfo, 
				bLogonInfo, 
				bScheduleInfo,
				bNotificationInfo);
		}

		[WebMethod(MessageName="GetReportTreeViaServer")] 
		public string GetReportTree(string szServer, 
			string szParentID,
			string szParentName,
			CEOptions sRecurring,
			CEOptions sTemplateHistory,
			bool bFolderInfo,
			bool bBasicInfo,
			bool bPromptInfo,
			bool bLogonInfo,
			bool bScheduleInfo,
			bool bNotificationInfo)
		{			
			return GetReportTree(null, 
				null, 
				null, 
				null, 
				szServer,		 
				szParentID, 
				szParentName, 
				sRecurring,
				sTemplateHistory,
				bFolderInfo,
				bBasicInfo,
				bPromptInfo, 
				bLogonInfo, 
				bScheduleInfo,
				bNotificationInfo);
		}

		private string GetReportTree(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szParentID,
			string szParentName,
			CEOptions sRecurring,
			CEOptions sTemplateHistory,
			bool bFolderInfo,
			bool bBasicInfo,
			bool bPromptInfo,
			bool bLogonInfo,
			bool bScheduleInfo,
			bool bNotificationInfo)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			XmlDocument oXmlDocument;
			XmlElement oXmlElement;
			string szSQL;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			szParentName = szParentName.Replace(" ", string.Empty);

			//Get the top most folders
			szSQL = BuildFolderSQL(szParentID,	
				sTemplateHistory,
				bBasicInfo,
				bPromptInfo, 
				bLogonInfo, 
				bScheduleInfo,
				bNotificationInfo);

			//Instantiate an XMLDocument object that will hold
			//all the InfoStore data
			oXmlDocument = new XmlDocument();
			oXmlElement = oXmlDocument.CreateElement("", szParentName, "");
			oXmlDocument.AppendChild(oXmlElement);

			//Get the data at the levels below the top most folders
			oXmlDocument = BuildSubTree(oInfoStore, 
				oXmlDocument, 
				oXmlElement, 
				szSQL,
				szParentID,
				sTemplateHistory,
				bFolderInfo,
				bBasicInfo, 
				bPromptInfo, 
				bLogonInfo, 
				bScheduleInfo,
				bNotificationInfo);

			return oXmlDocument.OuterXml;
		}


		private XmlDocument BuildSubTree(InfoStore oInfoStore, 
			XmlDocument oXmlDocument, 
			XmlElement oXmlElement, 
			string szSQL,
			string szParentID,
			CEOptions sTemplateHistory,
			bool bFolderInfo,
			bool bBasicInfo,
			bool bPromptInfo,
			bool bLogonInfo,
			bool bScheduleInfo,
			bool bNotificationInfo)
		{
			InfoObjects oInfoObjects = null;
			XmlElement oXmlMainElement = null;
			XmlElement oXmlSubElement = null;

			//If the folder SQL is not passed in then the 
			//method is recursing so get the report data.
			if (szSQL == null)
				szSQL = BuildReportSQL(szParentID,	
					sTemplateHistory,
					bBasicInfo,
					bPromptInfo, 
					bLogonInfo, 
					bScheduleInfo,
					bNotificationInfo);
					
			oInfoObjects = oInfoStore.Query(szSQL);

			//Listing 9-40
			foreach (InfoObject oInfoObject in oInfoObjects)
			{
				//If the object is a folder then create a Folder element, optionally 
				//add the folder information, and continue with the recursion
				if (oInfoObject.Properties["SI_KIND"].ToString() == "Folder")
				{
					oXmlMainElement = oXmlDocument.CreateElement("Folder");
					oXmlMainElement.SetAttribute("SI_FOLDER_NAME", 
						oInfoObject.Properties["SI_NAME"].ToString());

					if (bFolderInfo)
						oXmlMainElement = 
							FolderInfo(oInfoObject, oXmlDocument, oXmlMainElement);

					oXmlElement.AppendChild(oXmlMainElement);  

					szParentID = oInfoObject.Properties["SI_ID"].ToString();

					oXmlDocument = BuildSubTree(oInfoStore, 
						oXmlDocument, 
						oXmlMainElement, 
						null,
						szParentID,	
						sTemplateHistory,
						bFolderInfo,
						bBasicInfo,
						bPromptInfo, 
						bLogonInfo, 
						bScheduleInfo,
						bNotificationInfo);
				}
				//Listing 9-41
				else
				{
					//If this is a report object (or PDF, or Excel, etc) then 
					//create a Report element and add the requested sections of 
					//report information. Since there is nothing below 
					//a report, no further recursion is necessary.
					oXmlMainElement = oXmlDocument.CreateElement("Report");
					oXmlMainElement.SetAttribute("SI_REPORT_NAME", 
						oInfoObject.Properties["SI_NAME"].ToString());

					oXmlMainElement = 
						BaseReportInfo(oInfoObject, oXmlDocument, oXmlMainElement, bBasicInfo);

					if (bPromptInfo)
					{
						oXmlSubElement = PromptInfo(oInfoObject, oXmlDocument);
						
						if (oXmlSubElement != null)
							oXmlMainElement.AppendChild(oXmlSubElement);
					}

					if (bLogonInfo)
					{
						oXmlSubElement = LogonInfo(oInfoObject, oXmlDocument);
						
						if (oXmlSubElement != null)
							oXmlMainElement.AppendChild(oXmlSubElement);
					}

					if (bScheduleInfo)
					{
						oXmlSubElement = ScheduleInfo(oInfoObject, oXmlDocument);

						if (oXmlSubElement != null)
							oXmlMainElement.AppendChild(oXmlSubElement);
					}

					if (bNotificationInfo)
					{
						oXmlSubElement = NotificationInfo(oInfoObject, oXmlDocument);

						if (oXmlSubElement != null)
							oXmlMainElement.AppendChild(oXmlSubElement);
					}

					oXmlElement.AppendChild(oXmlMainElement);
				}
			}

			return oXmlDocument;
		}

		//Listing 9-39
		private string BuildFolderSQL(string szParentID,
			CEOptions sTemplateHistory,
			bool bBasicInfo,
			bool bPromptInfo,
			bool bLogonInfo,
			bool bScheduleInfo,
			bool bNotificationInfo)
		{
			string szSQL = string.Empty;
			string szField = string.Empty;

			szField = "SI_CHILDREN, SI_FLAGS, SI_ID, SI_OBTYPE, SI_OWNER, " +   
				"SI_OWNERID, SI_PARENT_FOLDER, SI_PARENTID, SI_INSTANCE, " +  
				"SI_UPDATE_TS, SI_OBJECT_IS_CONTAINER, SI_CREATION_TIME, " +   
				"SI_HIDDEN_OBJECT, SI_DESCRIPTION, SI_PROGID, SI_KIND, SI_NAME, " +   
				"SI_HASTHUMBNAIL, SI_TURNONTHUMBNAIL, SI_TURNONREPOSITORY, " +  
				"SI_SYSTEM_OBJECT, SI_RUNNABLE_OBJECT, SI_PLUGIN_OBJECT, " +   
				"SI_INSTANCE_OBJECT, SI_GUID, SI_CUID, SI_RUID, " +   
				"SI_APPLICATION_OBJECT, SI_TABLE, SI_PARENT_CUID, SI_COMPONENT, " +  
				"SI_PARENT_FOLDER_CUID, SI_REFRESH_OPTIONS, SI_RECURRING, ";

			if (bPromptInfo)
				szField += "SI_PROCESSINFO.SI_PROMPTS, ";

			if (bLogonInfo)
				szField += "SI_PROCESSINFO.SI_LOGON_INFO, ";

			if (bScheduleInfo)
				szField += "SI_SCHEDULEINFO.SI_SCHEDULE_TYPE, " + 
					"SI_SCHEDULEINFO.SI_STARTTIME, " + 
					"SI_SCHEDULEINFO.SI_RUN_ON_TEMPLATE, ";

			if (bNotificationInfo)
				szField += "SI_SCHEDULEINFO.SI_NOTIFICATION, ";

			szField = szField.Substring(0, szField.Length - 2) + " ";  

			szSQL ="Select " + szField + 
				"From CI_INFOOBJECTS " + 
				"Where (SI_KIND = 'Folder' " +
				"Or SI_KIND = 'CrystalReport' " + 
				"Or SI_KIND = 'Excel' " + 
				"Or SI_KIND = 'Pdf' " + 
				"Or SI_KIND = 'Rtf' " + 
				"Or SI_KIND = 'Txt' " + 
				"Or SI_KIND = 'Word') ";

			if (sTemplateHistory == CEOptions.No)  
				szSQL += " And SI_INSTANCE = 0 ";

			if (sTemplateHistory == CEOptions.Yes)  
				szSQL += " And SI_INSTANCE = 1 ";

			if (szParentID != "0")
				szSQL += "And SI_ANCESTOR = " + szParentID;

			return szSQL;
		}


		private string BuildReportSQL(string szParentID,
			CEOptions sTemplateHistory,
			bool bBasicInfo,
			bool bPromptInfo,
			bool bLogonInfo,
			bool bScheduleInfo,
			bool bNotificationInfo)
		{
			string szSQL = string.Empty;
			string szField = string.Empty;

			if (bBasicInfo)
				szField = "SI_CHILDREN, SI_FLAGS, SI_ID, SI_OBTYPE, SI_OWNER, SI_OWNERID, " +   
					"SI_PARENT_FOLDER, SI_PARENTID, SI_INSTANCE, SI_UPDATE_TS,  " +  
					"SI_OBJECT_IS_CONTAINER, SI_CREATION_TIME, SI_HIDDEN_OBJECT, " +   
					"SI_DESCRIPTION, SI_PROGID, SI_KIND, SI_NAME, SI_HASTHUMBNAIL, " +   
					"SI_TURNONTHUMBNAIL, SI_TURNONREPOSITORY, SI_SYSTEM_OBJECT, " +  
					"SI_RUNNABLE_OBJECT, SI_PLUGIN_OBJECT, SI_INSTANCE_OBJECT, " +   
					"SI_GUID, SI_CUID, SI_RUID, SI_APPLICATION_OBJECT, SI_TABLE, " +   
					"SI_PARENT_CUID, SI_COMPONENT, SI_PARENT_FOLDER_CUID, " +  
					"SI_REFRESH_OPTIONS, SI_RECURRING, ";
			else
				szField = "SI_ID, SI_NAME, SI_PROGID, SI_KIND, ";

			if (bPromptInfo)
				szField += "SI_PROCESSINFO.SI_PROMPTS, ";

			if (bLogonInfo)
				szField += "SI_PROCESSINFO.SI_LOGON_INFO, ";

			if (bScheduleInfo)
				szField += "SI_SCHEDULEINFO.SI_SCHEDULE_TYPE, " + 
					"SI_SCHEDULEINFO.SI_STARTTIME, " + 
					"SI_SCHEDULEINFO.SI_RUN_ON_TEMPLATE, ";

			if (bNotificationInfo)
				szField += "SI_SCHEDULEINFO.SI_NOTIFICATION, ";

			szField = szField.Substring(0, szField.Length - 2) + " ";  


			szSQL = "Select " + szField + 
				"From CI_INFOOBJECTS " + 
				"Where (SI_KIND = 'Folder' " + 
				"Or SI_KIND = 'CrystalReport' " + 
				"Or SI_KIND = 'Excel' " + 
				"Or SI_KIND = 'Pdf' " + 
				"Or SI_KIND = 'Rtf' " + 
				"Or SI_KIND = 'Txt' " + 
				"Or SI_KIND = 'Word') ";

			if (sTemplateHistory == CEOptions.No)  
				szSQL += " And SI_INSTANCE = 0 ";

			if (sTemplateHistory == CEOptions.Yes)  
				szSQL += " And SI_INSTANCE = 1 ";

			if (szParentID != "0")
				szSQL += "And SI_ANCESTOR = " + szParentID;

			return szSQL;
		}


		private XmlElement FolderInfo(InfoObject oInfoObject, XmlDocument oXmlDocument, XmlElement oXmlElement)
		{
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_CHILDREN", GetPropertyValue(oInfoObject.Properties, "SI_CHILDREN", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_FLAGS", GetPropertyValue(oInfoObject.Properties, "SI_FLAGS", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_ID", GetPropertyValue(oInfoObject.Properties, "SI_ID", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_OBTYPE", GetPropertyValue(oInfoObject.Properties, "SI_OBTYPE", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_OWNER", GetPropertyValue(oInfoObject.Properties, "SI_OWNER", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_OWNERID", GetPropertyValue(oInfoObject.Properties, "SI_OWNERID", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PARENT_FOLDER", GetPropertyValue(oInfoObject.Properties, "SI_PARENT_FOLDER", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_INSTANCE", GetPropertyValue(oInfoObject.Properties, "SI_INSTANCE", "False"), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_UPDATE_TS", GetPropertyValue(oInfoObject.Properties, "SI_UPDATE_TS", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_OBJECT_IS_CONTAINER", GetPropertyValue(oInfoObject.Properties, "SI_OBJECT_IS_CONTAINER", "False"), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_CREATION_TIME", GetPropertyValue(oInfoObject.Properties, "SI_CREATION_TIME", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_HIDDEN_OBJECT", GetPropertyValue(oInfoObject.Properties, "SI_HIDDEN_OBJECT", "False"), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_DESCRIPTION", GetPropertyValue(oInfoObject.Properties, "SI_DESCRIPTION", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PROGID", GetPropertyValue(oInfoObject.Properties, "SI_PROGID", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_NAME", GetPropertyValue(oInfoObject.Properties, "SI_NAME", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_SYSTEM_OBJECT", GetPropertyValue(oInfoObject.Properties, "SI_SYSTEM_OBJECT", "False"), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_RUNNABLE_OBJECT", GetPropertyValue(oInfoObject.Properties, "SI_RUNNABLE_OBJECT", "False"), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PLUGIN_OBJECT", GetPropertyValue(oInfoObject.Properties, "SI_PLUGIN_OBJECT", "False"), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_INSTANCE_OBJECT", GetPropertyValue(oInfoObject.Properties, "SI_INSTANCE_OBJECT", "False"), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_GUID", GetPropertyValue(oInfoObject.Properties, "SI_GUID", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_CUID", GetPropertyValue(oInfoObject.Properties, "SI_CUID", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_RUID", GetPropertyValue(oInfoObject.Properties, "SI_RUID", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_APPLICATION_OBJECT", GetPropertyValue(oInfoObject.Properties, "SI_APPLICATION_OBJECT", "False"), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_TABLE", GetPropertyValue(oInfoObject.Properties, "SI_TABLE", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PARENT_CUID", GetPropertyValue(oInfoObject.Properties, "SI_PARENT_CUID", string.Empty), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_COMPONENT", GetPropertyValue(oInfoObject.Properties, "SI_COMPONENT", "False"), null, null);
			oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PARENT_FOLDER_CUID", GetPropertyValue(oInfoObject.Properties, "SI_PARENT_FOLDER_CUID", string.Empty), null, null);

			return oXmlElement;
		}

		private XmlElement BaseReportInfo(InfoObject oInfoObject, XmlDocument oXmlDocument, XmlElement oXmlElement, bool bBasicInfo)
		{
			Properties oProperties = null;

			oProperties = oInfoObject.Properties;

			if (bBasicInfo)
			{
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_CHILDREN", GetPropertyValue(oProperties, "SI_CHILDREN", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_FLAGS", GetPropertyValue(oProperties, "SI_FLAGS", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_ID", GetPropertyValue(oProperties, "SI_ID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_OBTYPE", GetPropertyValue(oProperties, "SI_OBTYPE", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_OWNER", GetPropertyValue(oProperties, "SI_OWNER", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_OWNERID", GetPropertyValue(oProperties, "SI_OWNERID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PARENT_FOLDER", GetPropertyValue(oProperties, "SI_PARENT_FOLDER", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PARENTID", GetPropertyValue(oProperties, "SI_PARENTID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_INSTANCE", GetPropertyValue(oProperties, "SI_INSTANCE", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_UPDATE_TS", GetPropertyValue(oProperties, "SI_UPDATE_TS", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_OBJECT_IS_CONTAINER", GetPropertyValue(oProperties, "SI_OBJECT_IS_CONTAINER", "False"), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_CREATION_TIME", GetPropertyValue(oProperties, "SI_CREATION_TIME", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_HIDDEN_OBJECT", GetPropertyValue(oProperties, "SI_HIDDEN_OBJECT", "False"), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_DESCRIPTION", GetPropertyValue(oProperties, "SI_DESCRIPTION", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PROGID", GetPropertyValue(oProperties, "SI_PROGID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_KIND", GetPropertyValue(oProperties, "SI_KIND", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_NAME", GetPropertyValue(oProperties, "SI_NAME", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_KIND", GetPropertyValue(oProperties, "SI_KIND", string.Empty), null, null);				
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_HASTHUMBNAIL", GetPropertyValue(oProperties, "SI_HASTHUMBNAIL", "False"), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_TURNONTHUMBNAIL", GetPropertyValue(oProperties, "SI_TURNONTHUMBNAIL", "False"), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_TURNONREPOSITORY", GetPropertyValue(oProperties, "SI_TURNONREPOSITORY", "False"), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_SYSTEM_OBJECT", GetPropertyValue(oProperties, "SI_SYSTEM_OBJECT", "False"), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_RUNNABLE_OBJECT", GetPropertyValue(oProperties, "SI_RUNNABLE_OBJECT", "False"), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PLUGIN_OBJECT", GetPropertyValue(oProperties, "SI_PLUGIN_OBJECT", "False"), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_INSTANCE_OBJECT", GetPropertyValue(oProperties, "SI_INSTANCE_OBJECT", "False"), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_GUID", GetPropertyValue(oProperties, "SI_GUID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_CUID", GetPropertyValue(oProperties, "SI_CUID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_RUID", GetPropertyValue(oProperties, "SI_RUID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_APPLICATION_OBJECT", GetPropertyValue(oProperties, "SI_APPLICATION_OBJECT", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_TABLE", GetPropertyValue(oProperties, "SI_TABLE", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PARENT_CUID", GetPropertyValue(oProperties, "SI_PARENT_CUID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_COMPONENT", GetPropertyValue(oProperties, "SI_COMPONENT", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PARENT_FOLDER_CUID", GetPropertyValue(oProperties, "SI_PARENT_FOLDER_CUID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_REFRESH_OPTIONS", GetPropertyValue(oProperties, "SI_REFRESH_OPTIONS", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_RECURRING", GetPropertyValue(oProperties, "SI_RECURRING", "False"), null, null);
			}
			else
			{
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_ID", GetPropertyValue(oProperties, "SI_ID", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_NAME", GetPropertyValue(oProperties, "SI_NAME", string.Empty), null, null);
			}

			//oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_CALENDAR_ID", GetPropertyValue(oInfoObject, "SI_CALENDAR_ID", "False"), null, null);

			return oXmlElement;
		}

		private XmlElement PromptInfo(InfoObject oInfoObject, XmlDocument oXmlDocument)
		{
			XmlElement oXmlElement = null;
			Properties oProperties = null;
			int iCnt;
			string szPromptName = string.Empty;
			string szPromptValue = string.Empty;

			oProperties = oInfoObject.ProcessingInfo.Properties["SI_PROMPTS"].Properties;
		
			//SI_PROMPTS will always have at least one property - SI_NUM_PROMPTS
			iCnt = ((int) oProperties["SI_NUM_PROMPTS"].Value);
 
			if (iCnt != 0)
			{
				oXmlElement = oXmlDocument.CreateElement("SI_PROMPTS");

				for (int i=2; i<=iCnt+1; i++)
				{	
					szPromptName = ((string) oProperties[i].Properties["SI_NAME"].Value);

					if (HasMember(oProperties[i].Properties["SI_CURRENT_VALUES"].Properties, "SI_VALUE1"))
						szPromptValue = GetPropertyValue(oProperties[i].Properties["SI_CURRENT_VALUES"].Properties["SI_VALUE1"].Properties, "SI_DATA", "[Empty]");

					oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_VALUE" + (i - 1).ToString(), szPromptValue, "SI_NAME", szPromptName);
				}

			}

			return oXmlElement;
		}


		private XmlElement LogonInfo(InfoObject oInfoObject, XmlDocument oXmlDocument)
		{
			XmlElement oXmlElement = null;
			Properties oProperties = null;
			int iCnt;

			oProperties = oInfoObject.ProcessingInfo.Properties["SI_LOGON_INFO"].Properties;

			//SI_LOGON_INFO will always have at least one property - SI_NUM_LOGONS
			iCnt = ((int) oProperties["SI_NUM_LOGONS"].Value);

			if (iCnt != 0)
			{
				oXmlElement = oXmlDocument.CreateElement("SI_LOGONS");

				for (int i=2; i<=iCnt+1; i++)
				{	
					oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_SERVER", GetPropertyValue(oProperties[i].Properties, "SI_SERVER", ""), null, null);
					oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_USER", GetPropertyValue(oProperties[i].Properties, "SI_USER", ""), null, null);
					oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_SERVER_TYPE", GetPropertyValue(oProperties[i].Properties, "SI_SERVER_TYPE", ""), null, null);
				}
				
			}

			return oXmlElement;
		}


		private XmlElement ScheduleInfo(InfoObject oInfoObject, XmlDocument oXmlDocument)
		{
			XmlElement oXmlElement = null;
			Properties oProperties = null;
			int iCnt;
			string szTemplateDay = string.Empty;
			string szDOW = string.Empty;

			oProperties = oInfoObject.SchedulingInfo.Properties;

			if(oProperties.Count > 0)
			{
				oXmlElement = oXmlDocument.CreateElement("SI_SCHEDULE");

				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_SCHEDULE_TYPE", GetScheduleType(GetPropertyValue(oProperties, "SI_SCHEDULE_TYPE", "0")), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_STARTTIME", GetPropertyValue(oProperties, "SI_STARTTIME", string.Empty), null, null);

				if (HasMember(oProperties, "SI_RUN_ON_TEMPLATE"))
				{
					iCnt = ((int) oProperties["SI_RUN_ON_TEMPLATE"].Properties["SI_NUM_TEMPLATE_DAYS"].Value);
 
					if (iCnt != 0)
					{
						for (int i=1; i<=iCnt; i++)
						{	
							szTemplateDay = "SI_TEMPLATE_DAY" + i.ToString();
							szDOW = oProperties["SI_RUN_ON_TEMPLATE"].Properties[szTemplateDay].Properties["SI_DAYS_OF_WEEK"].Value.ToString();

							oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_TEMPLATE_DAY", DayOfWeek(szDOW), null, null);
						}
					
					}
				}
			}

			return oXmlElement;
		}


		private XmlElement NotificationInfo(InfoObject oInfoObject, XmlDocument oXmlDocument)
		{
			XmlElement oXmlMainElement = null;
			XmlElement oXmlElement = null;
			XmlElement oXmlSubElement = null;
			Properties oProperties = null;
			Properties oDestProperties = null;
			int iCnt;

			oProperties = oInfoObject.SchedulingInfo.Properties;

			oXmlMainElement = oXmlDocument.CreateElement("SI_NOTIFICATION");

			if (HasMember(oProperties, "SI_NOTIFICATION"))
			{
				iCnt = ((int) oProperties["SI_NOTIFICATION"].Properties["SI_DESTINATION_SUCCESS"].Properties["SI_TOTAL"].Value);
 
				if (iCnt != 0)
				{
					oXmlElement= oXmlDocument.CreateElement("SI_DESTINATION_SUCCESS");

					for (int i=1; i<=iCnt; i++)
					{
						oDestProperties = oProperties["SI_NOTIFICATION"].Properties["SI_DESTINATION_SUCCESS"].Properties[i.ToString()].Properties;
	
						oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PROGID", GetPropertyValue(oDestProperties, "SI_PROGID", string.Empty), null, null);

						oXmlSubElement = DestScheduleInfo(oInfoObject, oXmlDocument, "SI_DESTINATION_SUCCESS");

						if (oXmlSubElement != null)
							oXmlElement.AppendChild(oXmlSubElement);
					}

					oXmlMainElement.AppendChild(oXmlElement);
				}


				iCnt = ((int) oProperties["SI_NOTIFICATION"].Properties["SI_DESTINATION_FAILURE"].Properties["SI_TOTAL"].Value);
 
				if (iCnt != 0)
				{
					oXmlElement= oXmlDocument.CreateElement("SI_DESTINATION_FAILURE");

					for (int i=1; i<=iCnt; i++)
					{
						oDestProperties = oProperties["SI_NOTIFICATION"].Properties["SI_DESTINATION_SUCCESS"].Properties[i.ToString()].Properties;	
						
						oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PROGID", GetPropertyValue(oDestProperties, "SI_PROGID", string.Empty), null, null);

						oXmlSubElement = DestScheduleInfo(oInfoObject, oXmlDocument, "SI_DESTINATION_FAILURE");

						if (oXmlSubElement != null)
							oXmlElement.AppendChild(oXmlSubElement);
					}

					oXmlMainElement.AppendChild(oXmlElement);
				}
			}

			return oXmlMainElement;
		}

		private XmlElement DestScheduleInfo(InfoObject oInfoObject, XmlDocument oXmlDocument, string szNotificationType)
		{
			XmlElement oXmlElement = null;
			XmlElement oXmlSubElement = null;
			Properties oProperties = null;

			oProperties = oInfoObject.SchedulingInfo.Properties["SI_NOTIFICATION"].Properties[szNotificationType].Properties["1"].Properties;

			if (HasMember(oProperties, "SI_DEST_SCHEDULEOPTIONS"))
			{
				oXmlElement = oXmlDocument.CreateElement("SI_DEST_SCHEDULEOPTIONS");

				oProperties = oInfoObject.SchedulingInfo.Properties["SI_NOTIFICATION"].Properties[szNotificationType].Properties["1"].Properties["SI_DEST_SCHEDULEOPTIONS"].Properties;

				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_SERVER", GetPropertyValue(oProperties, "SI_SERVER", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PASSWORD", GetPropertyValue(oProperties, "SI_PASSWORD", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_USERNAME", GetPropertyValue(oProperties, "SI_USERNAME", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_MAIL_MESSAGE", GetPropertyValue(oProperties, "SI_MAIL_MESSAGE", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_DOMAIN_NAME", GetPropertyValue(oProperties, "SI_DOMAIN_NAME", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_PORT", GetPropertyValue(oProperties, "SI_PORT", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_SENDER_NAME", GetPropertyValue(oProperties, "SI_SENDER_NAME", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_MAIL_SUBJECT", GetPropertyValue(oProperties, "SI_MAIL_SUBJECT", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_AUTH_TYPE", GetPropertyValue(oProperties, "SI_AUTH_TYPE", string.Empty), null, null);
				oXmlElement = AddElement(oXmlDocument, oXmlElement, "SI_SMTP_ENABLEATTACHMENTS", GetPropertyValue(oProperties, "SI_SMTP_ENABLEATTACHMENTS", string.Empty), null, null);

				oXmlSubElement = DestEMailInfo(oInfoObject, oXmlDocument, szNotificationType, "SI_MAIL_ADDRESSES", "SI_MAIL_ADDRESS");

				if (oXmlSubElement != null)
					oXmlElement.AppendChild(oXmlSubElement);

				oXmlSubElement = DestEMailInfo(oInfoObject, oXmlDocument, szNotificationType, "SI_MAIL_CC", "SI_MAIL_CC_ADDRESS");

				if (oXmlSubElement != null)
					oXmlElement.AppendChild(oXmlSubElement);
			}

			return oXmlElement;
		}

		private XmlElement DestEMailInfo(InfoObject oInfoObject, XmlDocument oXmlDocument, string szNotificationType, string szEmailType, string szElementName)
		{
			XmlElement oXmlElement = null;
			Properties oProperties = null;
			int iCnt;

			if (HasMember(oInfoObject.SchedulingInfo.Properties["SI_NOTIFICATION"].Properties[szNotificationType].Properties, "1"))
			{
				oXmlElement = oXmlDocument.CreateElement(szEmailType);

				oProperties = oInfoObject.SchedulingInfo.Properties["SI_NOTIFICATION"].Properties[szNotificationType].Properties["1"].Properties["SI_DEST_SCHEDULEOPTIONS"].Properties[szEmailType].Properties;

				//oInfoObject.SchedulingInfo.Properties["SI_NOTIFICATION"].Properties["SI_DESTINATION_SUCCESS"].Properties["1"].Properties["SI_DEST_SCHEDULEOPTIONS"].Properties["SI_MAIL_ADDRESSES"].Properties["SI_TOTAL"].Value;

				iCnt = ((int) oProperties["SI_TOTAL"].Value);

				for (int x=1; x<=iCnt; x++)
					oXmlElement = AddElement(oXmlDocument, oXmlElement, szElementName, GetPropertyValue(oProperties, x.ToString(), string.Empty), null, null);
			}

			return oXmlElement;
		}


		private XmlElement AddElement(XmlDocument oXmlDocument, 
			XmlElement oXmlElement, 
			string szDescription, 
			string szText, 
			string szAttrName,
			string szAttrValue)
		{
			XmlElement oXmlChildElement;
			XmlText oXmlChildText;

			oXmlChildElement = oXmlDocument.CreateElement(szDescription);
			oXmlChildText = oXmlDocument.CreateTextNode(szText);

			if (szAttrName != null)
				oXmlChildElement.SetAttribute(szAttrName, szAttrValue);

			oXmlElement.AppendChild(oXmlChildElement);  
			oXmlElement.LastChild.AppendChild(oXmlChildText);  

			return oXmlElement;
		}

		private string GetPropertyValue(Properties oPropertyBag, string szMember, string szDefault)
		{
			string szResult;

			if (HasMember(oPropertyBag, szMember))
				szResult = oPropertyBag[szMember].ToString();
			else
				szResult = szDefault;

			return szResult;
		}

		private bool HasMember(Properties oPropertyBag, string szMember)
		{
			int iCnt = oPropertyBag.Count;
			bool bResult = false;
  
			for (int i = 1; i<=iCnt; i++)
			{
				if (oPropertyBag[i].Name == szMember)
				{
					bResult = true;
					break;
				}
			}

			return bResult;
		}

		private string DayOfWeek(string szDayOfWeekCode)
		{
			string szResult = string.Empty;

			switch(szDayOfWeekCode)
			{
				case "1":
					szResult = "Sunday";
					break;

				case "2":
					szResult = "Monday";
					break;

				case "3":
					szResult = "Tuesday";
					break;

				case "4":
					szResult = "Wednesday";
					break;

				case "5":
					szResult = "Thursday";
					break;

				case "6":
					szResult = "Friday";
					break;

				case "7":
					szResult = "Saturday";
					break;
			}

			return szResult;

		}

		private string GetScheduleType(string szScheduleType)
		{
			CrystalDecisions.Enterprise.CeScheduleType sScheduleType;
			string szResult = string.Empty;

			sScheduleType = ((CrystalDecisions.Enterprise.CeScheduleType) Int32.Parse(szScheduleType));

			switch(sScheduleType)
			{
				case CrystalDecisions.Enterprise.CeScheduleType.ceScheduleType1stMonday:
					szResult = "1st Monday";
					break;

				case CrystalDecisions.Enterprise.CeScheduleType.ceScheduleTypeCalendar:
					szResult = "Calendar";
					break;

				case CrystalDecisions.Enterprise.CeScheduleType.ceScheduleTypeDaily:
					szResult = "Daily";
					break;

				case CrystalDecisions.Enterprise.CeScheduleType.ceScheduleTypeHourly:
					szResult = "Hourly";
					break;

				case CrystalDecisions.Enterprise.CeScheduleType.ceScheduleTypeLastDay:
					szResult = "Last Day";
					break;

				case CrystalDecisions.Enterprise.CeScheduleType.ceScheduleTypeMonthly:
					szResult = "Monthly";
					break;

				case CrystalDecisions.Enterprise.CeScheduleType.ceScheduleTypeNthDay:
					szResult = "Nth Day";
					break;

				case CrystalDecisions.Enterprise.CeScheduleType.ceScheduleTypeOnce:
					szResult = "Once";
					break;

				case CrystalDecisions.Enterprise.CeScheduleType.ceScheduleTypeWeekly:
					szResult = "Weekly";
					break;
	
			}

			return szResult;

		}

		#endregion

		#region Security And User Management

		#region GetUserGroups

		[WebMethod(MessageName="GetUserGroupsViaLogonID")] 
		public System.Data.DataSet GetUserGroups(string szUserID, string szPassword, string szSystem, string szAuthentication)
		{	
			return GetUserGroups(szUserID, szPassword, szSystem, szAuthentication, null);
		}

		[WebMethod(MessageName="GetUserGroupsViaServer")] 
		public System.Data.DataSet GetUserGroups(string szServer)
		{	
			return GetUserGroups(null, null, null, null, szServer);
		}

		private System.Data.DataSet GetUserGroups(string szUserID, string szPassword, string szSystem, string szAuthentication, string szServer)
		{			
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);


			try
			{
				szSQL = "Select SI_ID, SI_NAME " +
					"From CI_SYSTEMOBJECTS " +
					"Where SI_KIND='UserGroup' " +
					"Order By SI_NAME";

				oInfoObjects = oInfoStore.Query(szSQL);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("Name"));

			foreach (InfoObject oInfoObject in oInfoObjects)
			{
				oDR = oDT.NewRow();
 
				oDR["ID"] = oInfoObject.Properties["SI_ID"]; 
				oDR["Name"] = oInfoObject.Properties["SI_NAME"]; 

				oDT.Rows.Add(oDR);  
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);  

			return oDS;
		}

		#endregion

		#region GetUsers

		//Listing 10-4
		[WebMethod(MessageName="GetUsersViaLogonID")] 
		public System.Data.DataSet GetUsers(string szUserID, string szPassword, string szSystem, string szAuthentication, string szUserGroup)
		{	
			return GetUsers(szUserID, szPassword, szSystem, szAuthentication, null, szUserGroup);
		}

		[WebMethod(MessageName="GetUsersViaServer")] 
		public System.Data.DataSet GetUsers(string szServer, string szUserGroup)
		{	
			return GetUsers(null, null, null, null, szServer, szUserGroup);
		}

		private System.Data.DataSet GetUsers(string szUserID, string szPassword, string szSystem, string szAuthentication, string szServer, string szUserGroup)
		{			
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			InfoObjects oUserObjects = null;
			Property oProperty = null;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;
			int iUserID;
			int iCnt;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Extract a group object
			try
			{
				szSQL = "SELECT SI_GROUP_MEMBERS " +
						"FROM CI_SYSTEMOBJECTS " +
						"WHERE SI_ID = " + szUserGroup;

				oInfoObjects = oInfoStore.Query(szSQL);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("Name"));
			oDT.Columns.Add(new DataColumn("Description"));			

			if (HasMember(oInfoObjects[1].Properties, "SI_GROUP_MEMBERS"))
			{
				//Set a property bag reference so the code's not so long
				oProperty = oInfoObjects[1].Properties["SI_GROUP_MEMBERS"];

				//How many members does the group have?
				iCnt = ((int) oProperty.Properties["SI_TOTAL"].Value);

				//The name start with the second property
				for (int x = 2; x <= iCnt + 1; x++)
				{
					oDR = oDT.NewRow();

					//Get the user id of the member
					iUserID = ((int) oProperty.Properties[x].Value);

					//Get a user object for that user...
					szSQL = "SELECT SI_ID, SI_DESCRIPTION, SI_NAME " +
						"FROM CI_SYSTEMOBJECTS " +
						"WHERE SI_ID = " + iUserID.ToString();

					oUserObjects = oInfoStore.Query(szSQL);

					//...and assign the user's information to the DataTable
					oDR["ID"] = oUserObjects[1].Properties["SI_ID"].Value; 
					oDR["Name"] = oUserObjects[1].Properties["SI_NAME"].Value; 
					oDR["Description"] = 
						oUserObjects[1].Properties["SI_DESCRIPTION"].Value; 

					oDT.Rows.Add(oDR);  
				}
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);  

			return oDS;
		}
		
		#endregion

		#region CreateUser

		//Listing 10-1
		[WebMethod(MessageName="CreateUserViaLogonID")] 
		public string CreateUser(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szAccountName,
			string szDescription,
			string szFullName,
			string szEmailAddress,
			bool bPasswordExpires,
			bool bAllowChangePassword,
			string szUserPassword)
		{	
			return CreateUser(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null,
				szAccountName,
				szDescription,
				szFullName,
				szEmailAddress,
				bPasswordExpires,
				bAllowChangePassword,
				szUserPassword);
		}

		[WebMethod(MessageName="CreateUserViaServer")] 
		public string CreateUser(string szServer, 								
			string szAccountName,
			string szDescription,
			string szFullName,
			string szEmailAddress,
			bool bPasswordExpires,
			bool bAllowChangePassword,
			string szUserPassword)
		{	
			return CreateUser(null, 
				null, 
				null, 
				null, 
				szServer, 
				szAccountName,
				szDescription,
				szFullName,
				szEmailAddress,
				bPasswordExpires,
				bAllowChangePassword,
				szUserPassword);
		}
	
		private string CreateUser(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szAccountName,
			string szDescription,
			string szFullName,
			string szEmailAddress,
			bool bPasswordExpires,
			bool bAllowChangePassword,
			string szUserPassword)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			User oUser;
			string szSQL = string.Empty;
			string szResult = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			oInfoObjects = oInfoStore.NewInfoObjectCollection();

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("CrystalEnterprise.User");
			oInfoObject = oInfoObjects.Add(oPluginInfo);
			oUser =	((User) oInfoObject);

			oUser.Title = szAccountName;
			oUser.Description = szDescription;
			oUser.FullName = szFullName;
			oUser.EmailAddress = szEmailAddress;
			oUser.PasswordExpires = bPasswordExpires;
			oUser.AllowChangePassword = bAllowChangePassword;
			oUser.NewPassword = szUserPassword;
			oUser.ChangePasswordAtNextLogon = true;

			try
			{
				oInfoStore.Commit(oInfoObjects);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			szResult = oUser.ID.ToString();

			return szResult;
		}

		#endregion

		#region CreateUserGroup

		//Listing 10-2
		[WebMethod(MessageName="CreateUserGroupViaLogonID")] 
		public string CreateUserGroup(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szName,
			string szDescription)
		{	
			return CreateUserGroup(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null,
				szName,
				szDescription);
		}

		[WebMethod(MessageName="CreateUserGroupViaServer")] 
		public string CreateUserGroup(string szServer, 								
			string szName,
			string szDescription)
		{	
			return CreateUserGroup(null, 
				null, 
				null, 
				null, 
				szServer, 
				szName,
				szDescription);
		}
	
		private string CreateUserGroup(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szName,
			string szDescription)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			UserGroup oUserGroup;
			string szSQL = string.Empty;
			string szResult = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			oInfoObjects = oInfoStore.NewInfoObjectCollection();

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("CrystalEnterprise.UserGroup");
			oInfoObject = oInfoObjects.Add(oPluginInfo);
			oUserGroup = ((UserGroup) oInfoObject);

			oUserGroup.Title = szName;
			oUserGroup.Description = szDescription;

			try
			{
				oInfoStore.Commit(oInfoObjects);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			szResult = oUserGroup.ID.ToString();

			return szResult;
		}

		#endregion

		#region AssignUserToGroup

		//Listing 10-3
		[WebMethod(MessageName="AssignUserToGroupViaLogonID")] 
		public void AssignUserToGroup(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szUserCodeID,
			string szGroupID)
		{	
			AssignUserToGroup(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null,
				szUserCodeID,
				szGroupID);
		}

		[WebMethod(MessageName="AssignUserToGroupViaServer")] 
		public void AssignUserToGroup(string szServer, 								
			string szUserCodeID,
			string szGroupID)
		{	
			AssignUserToGroup(null, 
				null, 
				null, 
				null, 
				szServer, 
				szUserCodeID,
				szGroupID);
		}

		public void AssignUserToGroup(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szUserCodeID,
			string szGroupID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			User oUser = null;
			CrystalDecisions.Enterprise.Desktop.Groups oGroups = null;
			string szSQL = string.Empty;
			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			szSQL = "Select SI_ID " +
				"From CI_SYSTEMOBJECTS " +
				"Where SI_ID = " + szUserCodeID;

			oInfoObjects = oInfoStore.Query(szSQL);
			oInfoObject = oInfoObjects[1];

			oUser =	((User) oInfoObject);

			oUser.Groups.Add(int.Parse(szGroupID));

			try
			{
				oInfoStore.Commit(oInfoObjects);
			}
			catch (Exception ex)
			{
				throw ex;
			}

		}

		#endregion

		#region GetRightsForObject

		[WebMethod(MessageName="GetRightsForObjectViaLogonID")] 
		public string GetRightsForObject(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szObjectID)
		{	
			return GetRightsForObject(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null,
				szObjectID);
		}

		[WebMethod(MessageName="GetRightsForObjectViaServer")] 
		public string GetRightsForObject(string szServer, 								
			string szObjectID)
		{	
			return GetRightsForObject(null, 
				null, 
				null, 
				null, 
				szServer, 
				szObjectID);
		}

		public string GetRightsForObject(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szObjectID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;	
			ObjectPrincipals oObjectPrincipals = null;
			XmlDocument oXmlDocument = null;
			XmlElement oXmlElement = null;
			XmlElement oXmlSubElement = null;
			XmlElement oXmlRightsElement = null;
			string szSQL = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Listing 10-10
			szSQL = "Select SI_ID, SI_NAME, SI_KIND " +
				"From CI_INFOOBJECTS " +
				"Where SI_ID = " + szObjectID;

			oInfoObjects = oInfoStore.Query(szSQL);
			oInfoObject = oInfoObjects[1];

			oObjectPrincipals = oInfoObject.SecurityInfo.ObjectPrincipals;  

			oXmlDocument = new XmlDocument();

			oXmlElement = oXmlDocument.CreateElement("", 
				oInfoObject.Properties["SI_NAME"].ToString(), "");

			oXmlElement.SetAttribute("SI_KIND", 
				oInfoObject.Properties["SI_KIND"].ToString());

			oXmlDocument.AppendChild(oXmlElement);

			//Listing 10-11
			foreach (ObjectPrincipal oObjectPrincipal in oObjectPrincipals)
			{
				oXmlSubElement = oXmlDocument.CreateElement("", "ObjectPrincipal", "");
				oXmlSubElement.SetAttribute("SI_NAME", oObjectPrincipal.Name);

				oXmlElement.AppendChild(oXmlSubElement);

				if (oObjectPrincipal.Rights.Count > 0)
				{
					oXmlRightsElement = oXmlDocument.CreateElement("", "Rights", "");

					foreach(SecurityRight oSecurityRight in oObjectPrincipal.Rights)
						oXmlRightsElement = AddElement(oXmlDocument, oXmlRightsElement, 
							"ID", oSecurityRight.ID.ToString(), "Rights", 
							oSecurityRight.Description);
						
					oXmlSubElement.AppendChild(oXmlRightsElement);

				}

				if (oObjectPrincipal.InheritedRights.Count > 0)
				{
					oXmlRightsElement = oXmlDocument.CreateElement("", "InheritedRights", "");

					foreach(SecurityRight oSecurityRight in oObjectPrincipal.InheritedRights)
						oXmlRightsElement = AddElement(oXmlDocument, oXmlRightsElement, 
							"ID", oSecurityRight.ID.ToString(), "InheritedRights", 
							oSecurityRight.Description);
						
					oXmlSubElement.AppendChild(oXmlRightsElement);

				}

				//Listing 10-17
				if (oObjectPrincipal.Limits.Count > 0)
				{
					oXmlRightsElement = oXmlDocument.CreateElement("", "Limits", "");

					foreach(SecurityLimit oSecurityLimit in oObjectPrincipal.Limits)
						oXmlRightsElement = AddElement(oXmlDocument, oXmlRightsElement, 
							"Value", oSecurityLimit.Value.ToString(), "Limits", 
							oSecurityLimit.Description);
						
					oXmlSubElement.AppendChild(oXmlRightsElement);

				}

			}			

			return oXmlDocument.OuterXml;
		}

		#endregion

		#region AssignSecurityRights

		//Listing 10-8
		[WebMethod(MessageName="AssignSecurityRightsViaLogonID")] 
		public void AssignSecurityRights(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szReportID, 
			string szUserCodeID,
			CeSystemRights[] aRights)
		{	
			AssignSecurityRights(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null,
				szReportID,
				szUserCodeID,
				aRights);
		}

		[WebMethod(MessageName="AssignSecurityRightsViaServer")] 
		public void AssignSecurityRights(string szServer, 	
			string szReportID, 				
			string szUserCodeID,
			CeSystemRights[] aRights)
		{	
			AssignSecurityRights(null, 
				null, 
				null, 
				null, 
				szServer, 
				szReportID,
				szUserCodeID,
				aRights);
		}

		public void AssignSecurityRights(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szReportID, 
			string szUserCode,
			CeSystemRights[] aRights)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			ObjectPrincipals oObjectPrincipals = null;
			SecurityRights oSecurityRights = null;
			SecurityRight oNewRight = null;
			Report oReport = null;
			string szSQL = string.Empty;
			int iCnt;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Get report reference
			szSQL = "Select SI_ID " +
				"From CI_INFOOBJECTS " +
				"Where SI_ID = " + szReportID;

			oInfoObjects = oInfoStore.Query(szSQL);
			oInfoObject = oInfoObjects[1];

			oReport = ((Report) oInfoObject);

			//Retrieve ObjectPrincipals collection and security rights collection
			oObjectPrincipals = oReport.SecurityInfo.ObjectPrincipals;  

			oSecurityRights = oObjectPrincipals["#" + szUserCode].Rights;

			//Deny all rights
			foreach(SecurityRight oSecurityRight in oSecurityRights)
				oSecurityRight.Granted = false;

			//Iterate through rights array and 
			//assign only those right specified
			iCnt = aRights.Length; 

			for (int x=0; x < iCnt; x++)
			{
				oNewRight = oSecurityRights.Add((int) aRights[x]);

				if (! oNewRight.Inherited)
					oNewRight.Granted = true;
			}

			oInfoStore.Commit(oInfoObjects);
		}

		#endregion

		#region AssignSecurityLimits

		[WebMethod(MessageName="AssignSecurityLimitsViaLogonID")] 
		public void AssignSecurityLimits(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szReportID, 
			string szUserCodeID,
			int[][] aLimits,
			int iMaxInstances)
		{	
			AssignSecurityLimits(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null,
				szReportID,
				szUserCodeID,
				aLimits,
				iMaxInstances);
		}

		[WebMethod(MessageName="AssignSecurityLimitsViaServer")] 
		public void AssignSecurityLimits(string szServer, 	
			string szReportID, 				
			string szUserCodeID,
			int[][] aLimits,
			int iMaxInstances)
		{
			AssignSecurityLimits(null, 
				null, 
				null, 
				null, 
				szServer, 
				szReportID,
				szUserCodeID,
				aLimits,
				iMaxInstances);
		}

		public void AssignSecurityLimits(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szReportID, 
			string szUserCode,
			int[][] aLimits,
			int iMaxInstances)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			ObjectPrincipals oObjectPrincipals = null;
			SecurityLimits oSecurityLimits = null;
			Report oReport = null;
			string szSQL = string.Empty;
			int iCnt;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Listing 10-15
			//Get report reference
			szSQL = "Select SI_ID " +
				"From CI_INFOOBJECTS " +
				"Where SI_ID = " + szReportID;

			oInfoObjects = oInfoStore.Query(szSQL);
			oInfoObject = oInfoObjects[1];

			oReport = ((Report) oInfoObject);

			//Get ObjectPrincipals reference for the entire report
			oObjectPrincipals = oReport.SecurityInfo.ObjectPrincipals;

			//Iterate until we find the Everyone entry
			foreach(ObjectPrincipal oObjectPrincipal in oObjectPrincipals)
			{
				if (oObjectPrincipal.Name == "Everyone")
				{
					//Get the limits for the Everyone entry...
					oSecurityLimits = oObjectPrincipal.Limits;

					//...and iterate until the "Maximum instance 
					//count per object" is located
					foreach(SecurityLimit oSecurityLimit in oSecurityLimits)
					{
						if (oSecurityLimit.Description == "Maximum instance count per object")
						{
							//when found assign the limit value
							oSecurityLimits.Add(((int) CeSystemLimits.ceLimitMaxInstanceCount), 
								iMaxInstances);
							oInfoStore.Commit(oInfoObjects);
							break;
						}
					}

					break;
				}
			}


			//Listing 10-16
			//Get ObjectPrincipals reference for the specified user
			oSecurityLimits = oObjectPrincipals["#" + szUserCode].Limits;

			//Iterate through rights array and 
			//assign only those right specified
			iCnt = aLimits.Length; 

			for (int x=0; x < iCnt; x++)
				oSecurityLimits.Add(aLimits[x][0], aLimits[x][1]);

			oInfoStore.Commit(oInfoObjects);
		}

		#endregion

		#region AssignSubGroup

		//Listing 10-5
		[WebMethod(MessageName="AssignSubGroupViaLogonID")] 
		public void AssignSubGroup(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szGroupID, 
			int iParentGroupID)
		{	
			AssignSubGroup(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null,
				szGroupID,
				iParentGroupID);
		}

		[WebMethod(MessageName="AssignSubGroupViaServer")] 
		public void AssignSubGroup(string szServer, 
			string szGroupID, 
			int iParentGroupID)
		{
			AssignSubGroup(null, 
				null, 
				null, 
				null, 
				szServer, 
				szGroupID,
				iParentGroupID);
		}


		public void AssignSubGroup(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szGroupID, 
			int iParentGroupID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			UserGroup oUserGroup = null;
			string szSQL = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);
 
			//Get group reference
			szSQL = "Select SI_ID " +
				"From CI_SYSTEMOBJECTS " +
				"Where SI_ID = " + szGroupID;

			oInfoObjects = oInfoStore.Query(szSQL);
			oInfoObject = oInfoObjects[1];

			oUserGroup = ((UserGroup) oInfoObject);

			//Give the group a parent group
			oUserGroup.ParentGroups.Add(iParentGroupID);

			oInfoStore.Commit(oInfoObjects);
		}

		#endregion

		#region AssignRole

		//Listing 10-6
		[WebMethod(MessageName="AssignRoleViaLogonID")] 
		public void AssignRole(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			int iUserID, 
			string szReportID,
			CeRole sRole)
		{	
			AssignRole(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null,
				iUserID,
				szReportID,
				sRole);
		}

		[WebMethod(MessageName="AssignRoleViaServer")] 
		public void AssignRole(string szServer, 
			int iUserID, 
			string szReportID,
			CeRole sRole)
		{
			AssignRole(null, 
				null, 
				null, 
				null, 
				szServer, 
				iUserID,
				szReportID,
				sRole);
		}

		public void AssignRole(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			int iUserID, 
			string szReportID,
			CeRole sRole)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			ObjectPrincipal oObjectPrincipal = null;
			Report oReport = null;
			string szSQL = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);
 
			//Get report reference
			szSQL = "Select SI_ID " +
				"From CI_INFOOBJECTS " +
				"Where SI_ID = " + szReportID;

			oInfoObjects = oInfoStore.Query(szSQL);
			oInfoObject = oInfoObjects[1];

			oReport = ((Report) oInfoObject);

			oObjectPrincipal = oReport.SecurityInfo.ObjectPrincipals.Add(iUserID);

			oObjectPrincipal.Role = sRole;  

			oInfoStore.Commit(oInfoObjects);
		}

		#endregion

		#region CheckRights

		//Listing 10-13
		[WebMethod(MessageName="CheckRightsViaLogonID")] 
		public object[] CheckRights(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szReportID,
			int[] aRights)
		{	
			return CheckRights(szUserID, 
					szPassword, 
					szSystem, 
					szAuthentication, 
					null,
					szReportID,
					aRights);
		}

		[WebMethod(MessageName="CheckRightsViaServer")] 
		public object[] CheckRights(string szServer, 
			string szReportID,
			int[] aRights)
		{
			return CheckRights(null, 
					null, 
					null, 
					null, 
					szServer, 
					szReportID,
					aRights);
		}

		public object[] CheckRights(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szReportID,
			int[] aRights)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			Report oReport = null;
			object aRightData;
			object[] aRightDataArray;
			string szSQL = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);
 
			//Get report reference
			szSQL = "Select SI_ID " +
				"From CI_INFOOBJECTS " +
				"Where SI_ID = " + szReportID;

			oInfoObjects = oInfoStore.Query(szSQL);
			oInfoObject = oInfoObjects[1];

			oReport = ((Report) oInfoObject);

			aRightData = oReport.SecurityInfo.CheckRights(aRights);

			aRightDataArray = ((object[]) aRightData); 

			return aRightDataArray;
  
		}

		#endregion

		#region IsAuthorizedForReport

		[WebMethod(MessageName="IsAuthorizedForReportViaLogonID")] 
		public bool IsAuthorizedForReport(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szReportID,
			string szNTUserID)
		{	
			return IsAuthorizedForReport(szUserID, 
				szPassword, 
				szSystem, 
				szAuthentication, 
				null,
				szReportID,
				szNTUserID);
		}

		[WebMethod(MessageName="IsAuthorizedForReportViaServer")] 
		public bool IsAuthorizedForReport(string szServer, 								
			string szReportID,
			string szNTUserID)
		{	
			return IsAuthorizedForReport(null, 
				null, 
				null, 
				null, 
				szServer, 
				szReportID,
				szNTUserID);
		}

		public bool IsAuthorizedForReport(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szReportID, 
			string szNTUserID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects objReports = null;
			InfoObject objReport = null;
			ObjectPrincipals objObjectPrincipals = null;
			ArrayList aUsersGroupMembership = null;
			string szResult = "NOACCESS";
			string szSQL = string.Empty;
			string szDomain = string.Empty;
			string szGroup = string.Empty;
			bool bResult = false;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);	

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Retrieve report object
			szSQL = "Select SI_ID, SI_NAME " + 
				"From CI_INFOOBJECTS " + 
				"Where SI_ID = " + szReportID;

			objReports = oInfoStore.Query(szSQL);
			objReport = objReports[1];

			if (szNTUserID.IndexOf(@"\") != 0)
				szDomain = szNTUserID.Substring(0, szNTUserID.IndexOf(@"\"));

			//Listing 10-20
			//Get an ArrayList containing all the NT groups this users belongs to
			aUsersGroupMembership = new ArrayList();
			aUsersGroupMembership = LoadNTGroups(aUsersGroupMembership, szNTUserID);

			if (aUsersGroupMembership.ToArray().Length != 0)
			{
				//Get a list of all users and NT Groups authorized for this report
				objObjectPrincipals = objReport.SecurityInfo.ObjectPrincipals;

				//See if there is a match
				foreach (ObjectPrincipal objObjectPrincipal in objObjectPrincipals)
				{
					szGroup = objObjectPrincipal.Name.Replace(szDomain + @"\", string.Empty);

					bResult = (aUsersGroupMembership.IndexOf(szGroup) > -1);

					if (bResult)
						break;
				}
			}

			oInfoStore.Dispose();
			objReports.Dispose();
			objReport.Dispose();
			objObjectPrincipals.Dispose();

			return bResult;

		}


		//Listing 10-21
		private ArrayList LoadNTGroups(ArrayList aUsersGroupMembership, string szNTUserID)
		{
			IADsMembers oIADsMembers = null;
			DirectoryEntry oDirectoryEntry = null;

			//In order to retrieve a given users list of NT group memberships, the Web.config 
			//file must be set with the proper authentication settings
			//<authentication mode="Windows" /> 
			//      <identity impersonate="true" userName="domain\userid" password="mypass"/>


			//Passing a name that doesn't exist at all causes an error
			try
			{
				oDirectoryEntry = new DirectoryEntry("WinNT://" + szNTUserID + ",user");
				oIADsMembers = oDirectoryEntry.Invoke("Groups") as IADsMembers;
			}
			catch (Exception ex)
			{
				return aUsersGroupMembership;
			}

			foreach (IADsGroup oIADsGroup in oIADsMembers)
				aUsersGroupMembership.Add(oIADsGroup.Name);

			return aUsersGroupMembership;

		}

		#endregion

		#endregion

		#region ExportMultipleFormats

		[WebMethod]
		public void ExportMultipleFormats(string szServer, string szReportID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oReports = null;
			InfoObject oReport = null;
			InfoObjects oScheduledObjects = null;
			PluginInterface oPluginInterface = null;
			ReportFormatOptions oReportFormatOpts = null;
			Report oReportPlugIn = null;
			ReportAppFactory oReportAppFactory = null;
			ReportClientDocument oReportClientDocument = null;
			PrintOutputController oPrintOutputController = null;
			CeScheduleStatus iStatus = CeScheduleStatus.ceStatusFailure;
			ByteArray aByteArray;
			Byte[] aByte;
			System.IO.FileStream oFileStream;
			string szSQL;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 

			//Listing 8-27
			//Get the specified report
			try
			{
				szSQL = "SELECT SI_ID " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_ID = " + szReportID;

				oReports = oInfoStore.Query(szSQL); 

				oReport = oReports[1];
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oPluginInterface = oReport.GetPluginInterface(""); 
			oReportPlugIn = new Report(oPluginInterface); 

			oReport.SchedulingInfo.RightNow = true; 
			oReport.SchedulingInfo.Type = CeScheduleType.ceScheduleTypeOnce;	

			oReportFormatOpts = oReportPlugIn.ReportFormatOptions; 
			oReportFormatOpts.Format = CeReportFormat.ceFormatCrystalReport; 

			try
			{
				oInfoStore.Schedule(oReports); 
			}
			catch(Exception ex)
			{
				throw ex;
			}


			szReportID = oReport.Properties["SI_NEW_JOB_ID"].Value.ToString();

			//Listing 8-28
			do 
			{ 
				szSQL = "Select SI_SCHEDULE_STATUS " + 
						"From CI_INFOOBJECTS " + 
						"Where SI_ID = " + szReportID; 

				oScheduledObjects = oInfoStore.Query(szSQL); 
					
				iStatus = oScheduledObjects[1].SchedulingInfo.Status;    
				
				if (iStatus == CeScheduleStatus.ceStatusFailure) 
					break; 
				
				System.Threading.Thread.Sleep(500); 

			} while (((iStatus != CeScheduleStatus.ceStatusSuccess))); 	
		

			//Listing 8-29
			if (iStatus == CeScheduleStatus.ceStatusSuccess)
			{
				oEnterpriseService = oEnterpriseSession.GetService("","RASReportFactory");
				oReportAppFactory = ((ReportAppFactory) oEnterpriseService.Interface);
				oReportClientDocument = oReportAppFactory.OpenDocument(int.Parse(szReportID), 0);

				oPrintOutputController = oReportClientDocument.PrintOutputController;

				aByteArray = oPrintOutputController.
					Export(CrReportExportFormatEnum.crReportExportFormatPDF, 0);
				aByte = aByteArray.ByteArray;

				oFileStream = new System.IO.
					FileStream(@"c:\temp\myreport.pdf", System.IO.FileMode.Create);
				oFileStream.Write(aByte, 0, aByte.Length - 1); 
				oFileStream.Close();

				//			//Listing 8-30
				//			Response.Clear();
				//			Response.AddHeader("content-disposition", "inline;filename=untitled.pdf");
				//			Response.ContentType = "application/pdf";
				//			Response.BinaryWrite(aByte);
				//			Response.End();
			}

		}
		#endregion

		#region RunNow

		//Listing 5-24
		[WebMethod]
		public void RunNow(string szServer, string szApplication, string szReportName)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oInfoObjects = null; 
			InfoObject oReport = null; 
			InfoObjects oUserReports = null; 
			string szSQL;
			string szID = string.Empty;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 

			//Get Top Application folder
			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " + 
					"FROM CI_INFOOBJECTS " + 
					"WHERE SI_NAME = '" + szApplication + "' " +
					"AND SI_KIND = 'Folder'";

				oInfoObjects = oInfoStore.Query(szSQL);  
			}
			catch(Exception ex)
			{
				throw ex;
			}

			szID = oInfoObjects[1].Properties["SI_ID"].ToString();

			//Get all reports of specified name which belong under the top folder
			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_NAME = '" + szReportName + "' " +
					"AND SI_KIND = 'CrystalReport' " + 
					"AND SI_INSTANCE = 0 " + 
					"AND SI_ANCESTOR = " + szID;

				oInfoObjects = oInfoStore.Query(szSQL); 
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oInfoObjects[1].SchedulingInfo.RightNow = true; 
			oInfoObjects[1].SchedulingInfo.Type = CeScheduleType.ceScheduleTypeOnce;

			oInfoStore.Schedule(oInfoObjects); 

		}
		#endregion

		#region Schedule and Notifications

		#region DestinationFtp

		//Listing 6-15
		[WebMethod]
		public void DestinationFtp(string szServer, string szReportID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oReportInfoObjects = null; 
			InfoObjects oInfoObjects = null; 
			InfoObject oInfoObject = null; 
			Report oReport = null; 
			DestinationPlugin oDestinationPlugin = null;
			Destination oDestination = null; 
			FtpOptions oFtpOptions = null;
			string szSQL;
			string szID = string.Empty;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_ID = " + szReportID;

				oReportInfoObjects = oInfoStore.Query(szSQL);
				oReport = ((Report) oReportInfoObjects[1]);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			//You need to pull both SI_DEST_SCHEDULEOPTIONS and SI_PROGID in order for the 
			//SetFromPlugin() method to write the DestinationPlugin object
			try
			{
				szSQL = "Select SI_DEST_SCHEDULEOPTIONS, SI_PROGID " + 
					"From CI_SYSTEMOBJECTS " + 
					"Where SI_PARENTID=29 " + 
					"And SI_NAME = 'CrystalEnterprise.Ftp'";

				oInfoObjects = oInfoStore.Query(szSQL);
				oInfoObject = oInfoObjects[1];
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oDestinationPlugin = new DestinationPlugin(oInfoObject.PluginInterface);

			oFtpOptions = new FtpOptions(oDestinationPlugin.ScheduleOptions);

			oFtpOptions.ServerName = "myServerName";
			oFtpOptions.UserName = "myUserName";
			oFtpOptions.Password = "myPassword";
			oFtpOptions.Port = 21;
			oFtpOptions.Account = "myAccount";
			oFtpOptions.DestinationFiles.Add("thisfile.rpt");  
			oFtpOptions.DestinationFiles.Add("thatfile.rpt");

			oDestination = oReport.SchedulingInfo.Destination; 

			oDestination.SetFromPlugin(oDestinationPlugin);

			oInfoStore.Commit(oReportInfoObjects);

		}

		#endregion

		#region DestinationSmtp

		[WebMethod]
		public void DestinationSmtp(string szServer, string szReportID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oReportInfoObjects = null; 
			InfoObjects oInfoObjects = null; 
			InfoObject oInfoObject = null; 
			Report oReport = null; 
			DestinationPlugin oDestinationPlugin = null;
			Destination oDestination = null; 
			SmtpOptions oSmtpOptions = null;
			string szSQL;
			string szID = string.Empty;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Listing 6-13
			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_ID = " + szReportID;

				oReportInfoObjects = oInfoStore.Query(szSQL);
				oReport = ((Report) oReportInfoObjects[1]);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			//You need to pull both SI_DEST_SCHEDULEOPTIONS and SI_PROGID in order for the 
			//SetFromPlugin() method to write the DestinationPlugin object
			try
			{
				szSQL = "Select SI_DEST_SCHEDULEOPTIONS, SI_PROGID " + 
					"From CI_SYSTEMOBJECTS " + 
					"Where SI_PARENTID=29 " + 
					"And SI_NAME = 'CrystalEnterprise.Smtp'";

				oInfoObjects = oInfoStore.Query(szSQL);
				oInfoObject = oInfoObjects[1];
			}
			catch(Exception ex)
			{
				throw ex;
			}

			//Listing 6-14
			oDestinationPlugin = new DestinationPlugin(oInfoObject.PluginInterface);

			oSmtpOptions = new SmtpOptions(oDestinationPlugin.ScheduleOptions);

			oSmtpOptions.EnableAttachments = true;
			oSmtpOptions.SMTPAuthentication = CeAuthentication.ceAuthLogin; 
			oSmtpOptions.SMTPPassword = "mypassword";
			oSmtpOptions.SMTPUserName = "myuserName";
			oSmtpOptions.ServerName = "mysmtpserver";
			oSmtpOptions.DomainName = "mydomain";
			oSmtpOptions.Port = 80;
			oSmtpOptions.SenderAddress = "BOXIAdmin@mycompany.com";
			oSmtpOptions.ToAddresses.Add("seton.software@verizon.net");
			oSmtpOptions.CCAddresses.Add("youraddress@verizon.net");
			oSmtpOptions.Delimiter = ";";
			oSmtpOptions.Subject = "Daily Sales Report";
			oSmtpOptions.Message = "Click here %SI_VIEWER_URL% to view your report." ;
			oSmtpOptions.Attachments.Add("mimeType", "myfile.txt");

			oDestination = oReport.SchedulingInfo.Destination; 

			oDestination.SetFromPlugin(oDestinationPlugin);

			oInfoStore.Commit(oReportInfoObjects);

		}

		#endregion

		#region DestinationDisk

		//Listing 6-16
		[WebMethod]
		public void DestinationDisk(string szServer, string szReportID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oReportInfoObjects = null; 
			InfoObjects oInfoObjects = null; 
			InfoObject oInfoObject = null; 
			Report oReport = null; 
			DestinationPlugin oDestinationPlugin = null;
			Destination oDestination = null; 
			DiskUnmanagedOptions oDiskUnmanagedOptions = null;
			string szSQL;
			string szID = string.Empty;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_ID = " + szReportID;

				oReportInfoObjects = oInfoStore.Query(szSQL);
				oReport = ((Report) oReportInfoObjects[1]);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			//You need to pull both SI_DEST_SCHEDULEOPTIONS and SI_PROGID in order for the 
			//SetFromPlugin() method to write the DestinationPlugin object
			try
			{
				szSQL = "Select SI_DEST_SCHEDULEOPTIONS, SI_PROGID " + 
					"From CI_SYSTEMOBJECTS " + 
					"Where SI_PARENTID=29 " + 
					"And SI_NAME = 'CrystalEnterprise.DiskUnmanaged'";

				oInfoObjects = oInfoStore.Query(szSQL);
				oInfoObject = oInfoObjects[1];
			}
			catch(Exception ex)
			{
				throw ex;
			}			

			oDestinationPlugin = new DestinationPlugin(oInfoObject.PluginInterface);
		
			oDiskUnmanagedOptions = new DiskUnmanagedOptions(oDestinationPlugin.ScheduleOptions);

			oDiskUnmanagedOptions.DestinationFiles.Add("targetfile.pdf");  

			oDestination = oReport.SchedulingInfo.Destination; 

			oDestination.SetFromPlugin(oDestinationPlugin);

			oInfoStore.Commit(oReportInfoObjects);

		}

		#endregion

		#region ScheduleReport

		[WebMethod]
		public void ScheduleReport(string szServer, string szApplication, string szReportName)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oReports = null; 
			InfoObject oReport = null; 
			InfoObjects oUserReports = null; 
			InfoObjects oSingleReports = null;
			string szSQL;
			string szID = string.Empty;
			int iCalendarID = 0;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 

			//Get Top Application folder
			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " + 
					"FROM CI_INFOOBJECTS " + 
					"WHERE SI_NAME = '" + szApplication + "' " +
					"AND SI_KIND = 'Folder'";

				oReports = oInfoStore.Query(szSQL); 
				oReport = oReports[1]; 
			}
			catch(Exception ex)
			{
				throw ex;
			}

			szID = oReport.Properties["SI_ID"].ToString();

			//Get all recurring reports of specified name which belong under the top folder
			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_NAME = '" + szReportName + "' " +
					"AND SI_KIND = 'Report' " + 
					"AND SI_RECURRING = 1 " + 
					"AND SI_ANCESTOR = " + szID;

				oReports = oInfoStore.Query(szSQL); 
			}
			catch(Exception ex)
			{
				throw ex;
			}

			//Delete each recurring report instance
			foreach (InfoObject oNewReport in oReports)
			{
				szSQL = "SELECT SI_ID, SI_NAME " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_ID = " + oNewReport.Properties["SI_ID"].ToString();

				oUserReports = oInfoStore.Query(szSQL); 

				oUserReports.Delete(oUserReports[1]); 

				oInfoStore.Commit(oUserReports); 
			}

			iCalendarID = GetCalendarID(oInfoStore, "Tues-Sat");


			//Pull each base instance of the report and schedule it again
			szSQL = "SELECT SI_ID, SI_NAME " +  
				"FROM CI_INFOOBJECTS " +  
				"WHERE SI_NAME = '" + szReportName + "' " +
				"AND SI_KIND = 'Report' " + 
				"AND SI_INSTANCE = 0 " +
				"AND SI_ANCESTOR = " + szID;

			oReports = oInfoStore.Query(szSQL); 

			foreach (InfoObject oNewReport in oReports)
			{				 
				szID = oNewReport.Properties["SI_ID"].ToString();

				szSQL = "SELECT SI_ID, SI_NAME " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_ID = " + szID;

				oSingleReports = oInfoStore.Query(szSQL); 

				foreach (InfoObject oSingleReport in oSingleReports)
				{
					oSingleReport.SchedulingInfo.BeginDate = DateTime.Parse(DateTime.Today.ToShortDateString() + " 1:00:00 PM");
					oSingleReport.SchedulingInfo.EndDate = DateTime.Today.AddYears(10); 
					oSingleReport.SchedulingInfo.Type = CeScheduleType.ceScheduleTypeCalendarTemplate;
					oSingleReport.SchedulingInfo.RightNow = false;
					oSingleReport.SchedulingInfo.CalendarTemplate = iCalendarID;

					//schedule the report
					oInfoStore.Schedule(oSingleReports);
				}

			}

		}

		private int GetCalendarID(InfoStore oInfoStore, string szCalendarName)
		{
			InfoObjects oCalendarObjects = null;
			string szSQL;
			int iCalendarID = 0;

			szSQL = "Select SI_ID " +
				"From CI_SYSTEMOBJECTS " +
				"Where SI_NAME = '" + szCalendarName + "'";

			oCalendarObjects = oInfoStore.Query(szSQL);

			if (oCalendarObjects.Count > 0)
				iCalendarID = oCalendarObjects[1].ID;

			return iCalendarID;
		}

		private string GetCalendarName(InfoStore oInfoStore, string szCalendarID)
		{
			InfoObjects oCalendarObjects = null;
			string szSQL;
			string szCalendarName = string.Empty;

			szSQL = "Select SI_NAME " +
				"From CI_SYSTEMOBJECTS " +
				"Where SI_ID = " + szCalendarID;

			oCalendarObjects = oInfoStore.Query(szSQL);

			if (oCalendarObjects.Count > 0)
				szCalendarName = oCalendarObjects[1].Properties["SI_NAME"].ToString();

			return szCalendarName;
		}

		#endregion

		#region SaveSchedule

		//Listing 5-26
		[WebMethod]
		public void SaveSchedule(string szServer,
			string szReportID,
			System.DateTime dTime,
			System.DateTime dStartDate,
			System.DateTime dEndDate,
			string szDays)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			Report oReport = null;
			string szSQL;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 

			szSQL = "Select * " +
				"From CI_INFOOBJECTS " +
				"Where SI_ID = " + szReportID;

			oInfoObjects = oInfoStore.Query(szSQL);

			oReport = ((Report) oInfoObjects[1]);

			oReport.SchedulingInfo.BeginDate = 
				DateTime.Parse(dStartDate.ToShortDateString() + " " + 
				dTime.ToShortTimeString());
			oReport.SchedulingInfo.EndDate = dEndDate; 
			oReport.SchedulingInfo.Type = CeScheduleType.ceScheduleTypeCalendar;
			oReport.SchedulingInfo.RightNow = false;

			if (szDays.IndexOf("1") != -1)
				oReport.SchedulingInfo.CalendarRunDays.Add(
					dStartDate.Day, dStartDate.Month, dStartDate.Year, 
					dEndDate.Day, dEndDate.Month, dEndDate.Year, CeDayOfWeek.ceDaySunday);

			if (szDays.IndexOf("2") != -1)
				oReport.SchedulingInfo.CalendarRunDays.Add(
					dStartDate.Day, dStartDate.Month, dStartDate.Year, 
					dEndDate.Day, dEndDate.Month, dEndDate.Year, CeDayOfWeek.ceDayMonday);

			if (szDays.IndexOf("3") != -1)
				oReport.SchedulingInfo.CalendarRunDays.Add(
					dStartDate.Day, dStartDate.Month, dStartDate.Year, 
					dEndDate.Day, dEndDate.Month, dEndDate.Year, CeDayOfWeek.ceDayTuesday);

			if (szDays.IndexOf("4") != -1)
				oReport.SchedulingInfo.CalendarRunDays.Add(
					dStartDate.Day, dStartDate.Month, dStartDate.Year, 
					dEndDate.Day, dEndDate.Month, dEndDate.Year, CeDayOfWeek.ceDayWednesday);

			if (szDays.IndexOf("5") != -1)
				oReport.SchedulingInfo.CalendarRunDays.Add(
					dStartDate.Day, dStartDate.Month, dStartDate.Year, 
					dEndDate.Day, dEndDate.Month, dEndDate.Year, CeDayOfWeek.ceDayThursday);

			if (szDays.IndexOf("6") != -1)
				oReport.SchedulingInfo.CalendarRunDays.Add(
					dStartDate.Day, dStartDate.Month, dStartDate.Year, 
					dEndDate.Day, dEndDate.Month, dEndDate.Year, CeDayOfWeek.ceDayFriday);

			if (szDays.IndexOf("7") != -1)
				oReport.SchedulingInfo.CalendarRunDays.Add(
					dStartDate.Day, dStartDate.Month, dStartDate.Year, 
					dEndDate.Day, dEndDate.Month, dEndDate.Year, CeDayOfWeek.ceDaySaturday);

			//schedule the report
			oInfoStore.Schedule(oInfoObjects);

		}

		#endregion

		#region GetSchedule

		//Listing 5-25
		[WebMethod]
		public System.Data.DataSet GetSchedule(string szServer,
			string szReportID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			Report oReport = null;
			Properties oPropertyBag;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;
			int iCnt = 0;
			int iDay = 0;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 

			szSQL = "SELECT SI_ID, SI_SCHEDULEINFO.SI_STARTTIME, " +
					"SI_SCHEDULEINFO.SI_ENDTIME, " +
					"SI_SCHEDULEINFO.SI_RUN_ON_TEMPLATE " +
					"FROM CI_INFOOBJECTS  " +
					"WHERE SI_PARENTID = " + szReportID +
					" AND SI_RECURRING = 1";

			oInfoObjects = oInfoStore.Query(szSQL);

			oReport = ((Report) oInfoObjects[1]);

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("StartDate"));
			oDT.Columns.Add(new DataColumn("EndDate"));
			oDT.Columns.Add(new DataColumn("Sunday"));
			oDT.Columns.Add(new DataColumn("Monday"));
			oDT.Columns.Add(new DataColumn("Tuesday"));
			oDT.Columns.Add(new DataColumn("Wednesday"));
			oDT.Columns.Add(new DataColumn("Thursday"));
			oDT.Columns.Add(new DataColumn("Friday"));
			oDT.Columns.Add(new DataColumn("Saturday"));


			oDR = oDT.NewRow();

			oDR["ID"] = oReport.Properties["SI_ID"]; 
			oDR["StartDate"] = oReport.SchedulingInfo.Properties["SI_STARTTIME"]; 
			oDR["EndDate"] = oReport.SchedulingInfo.Properties["SI_ENDTIME"]; 
			oDR["Sunday"] = false; 
			oDR["Monday"] = false;
			oDR["Tuesday"] = false;
			oDR["Wednesday"] = false;
			oDR["Thursday"] = false;
			oDR["Friday"] = false;
			oDR["Saturday"] = false; 


			oPropertyBag = oReport.SchedulingInfo.Properties["SI_RUN_ON_TEMPLATE"].Properties;

			iCnt = ((int) oPropertyBag["SI_NUM_TEMPLATE_DAYS"].Value);

			for (int x=1; x<=iCnt; x++)
			{
				iDay = ((int) oPropertyBag["SI_TEMPLATE_DAY" + x.ToString()].
					Properties["SI_DAYS_OF_WEEK"].Value);

				switch (iDay)
				{
					case 1:
						oDR["Sunday"] = true;
						break;

					case 2:
						oDR["Monday"] = true;
						break;

					case 3:
						oDR["Tuesday"] = true;
						break;

					case 4:
						oDR["Wednesday"] = true;
						break;

					case 5:
						oDR["Thursday"] = true;
						break;

					case 6:
						oDR["Friday"] = true;
						break;

					case 7:
						oDR["Saturday"] = true;
						break;
				}
			}

			oDT.Rows.Add(oDR); 

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);

			return oDS;

		}

		#endregion

		#region SetNotifications

		//Listing 6-1
		[WebMethod]
		public void SetNotifications(string szServer, string szReportID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oReportInfoObjects = null; 
			InfoObjects oInfoObjects = null; 
			InfoObject oInfoObject = null; 
			Report oReport = null; 
			DestinationPlugin oDestinationPlugin = null;
			Destination oDestination = null; 
			SmtpOptions oSmtpOptions = null;
			string szSQL;
			string szID = string.Empty;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_ID = " + szReportID;

				oReportInfoObjects = oInfoStore.Query(szSQL);
				oReport = ((Report) oReportInfoObjects[1]);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			//You need to pull both SI_DEST_SCHEDULEOPTIONS and SI_PROGID in order for the 
			//SetFromPlugin() method to write the DestinationPlugin object
			try
			{
				szSQL = "Select SI_DEST_SCHEDULEOPTIONS, SI_PROGID " + 
					"From CI_SYSTEMOBJECTS " + 
					"Where SI_PARENTID=29 " + 
					"And SI_NAME = 'CrystalEnterprise.Smtp'";

				oInfoObjects = oInfoStore.Query(szSQL);
				oInfoObject = oInfoObjects[1];
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oDestinationPlugin = new DestinationPlugin(oInfoObject.PluginInterface);

			oSmtpOptions = new SmtpOptions(oDestinationPlugin.ScheduleOptions);

			oSmtpOptions.ServerName = "MyServer";
			oSmtpOptions.Port = 25;
			oSmtpOptions.DomainName = "mydomain.com";
			oSmtpOptions.SenderAddress = "seton.software@verizon.net";
			oSmtpOptions.ToAddresses.Add("carlganz@myclient.com");
			oSmtpOptions.Subject = "Your Employee report is now ready";
			oSmtpOptions.Message = "Please click on the link below to see your report.";
			oSmtpOptions.SMTPAuthentication = CeAuthentication.ceAuthNone; 
			oSmtpOptions.SMTPUserName = "myname";
			oSmtpOptions.SMTPPassword = "mypass";

			oDestination = oReport.SchedulingInfo.Notifications.DestinationsOnSuccess.Add("new");    

			oDestination.SetFromPlugin(oDestinationPlugin);

			try
			{
				oInfoStore.Commit(oReportInfoObjects);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oEnterpriseSession.Logoff();

			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null; 
			oInfoStore.Dispose(); 
			oReportInfoObjects.Dispose(); 
			oInfoObjects.Dispose(); 
			oInfoObject.Dispose(); 
			oReport.Dispose(); 
			oDestinationPlugin.Dispose(); 
			oDestination.Dispose(); 
			oSmtpOptions.Dispose(); 

		}

		#endregion

		#region SetAlert

		//Listing 6-2
		[WebMethod]
		public void SetAlert(string szServer, string szReportID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oReportInfoObjects = null; 
			InfoObjects oInfoObjects = null; 
			InfoObject oInfoObject = null; 
			Report oReport = null; 
			DestinationPlugin oDestinationPlugin = null;
			SmtpOptions oSmtpOptions = null;
			string szSQL;
			string szID = string.Empty;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				szSQL = "SELECT SI_ID, SI_NAME " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_ID = " + szReportID;

				oReportInfoObjects = oInfoStore.Query(szSQL); 
				oReport = ((Report) oReportInfoObjects[1]);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			//You need to pull both SI_DEST_SCHEDULEOPTIONS and SI_PROGID in order for the 
			//SetFromPlugin() method to write the DestinationPlugin object
			try
			{
				szSQL = "Select SI_DEST_SCHEDULEOPTIONS, SI_PROGID " + 
					"From CI_SYSTEMOBJECTS " + 
					"Where SI_PARENTID=29 " + 
					"And SI_NAME = 'CrystalEnterprise.Smtp'";

				oInfoObjects = oInfoStore.Query(szSQL);
				oInfoObject = oInfoObjects[1];
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oDestinationPlugin = new DestinationPlugin(oInfoObject.PluginInterface);

			oSmtpOptions = new SmtpOptions(oDestinationPlugin.ScheduleOptions);

			oSmtpOptions.ServerName = "MyServer";
			oSmtpOptions.Port = 25;
			oSmtpOptions.DomainName = "mydomain.com";
			oSmtpOptions.SenderAddress = "seton.software@verizon.net";
			oSmtpOptions.ToAddresses.Add("carlganz@myclient.com");
			oSmtpOptions.Subject = "Your new Daily Hiring report is ready";
			oSmtpOptions.Message = "Please click on the link below to see your report.";
			oSmtpOptions.SMTPAuthentication = CeAuthentication.ceAuthNone; 
			oSmtpOptions.SMTPUserName = "myname";
			oSmtpOptions.SMTPPassword = "mypass";

			oReport.SchedulingInfo.AlertDestination.SetFromPlugin(oDestinationPlugin);

			try
			{
				oInfoStore.Commit(oReportInfoObjects);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oEnterpriseSession.Logoff();

			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null; 
			oInfoStore.Dispose(); 
			oReportInfoObjects.Dispose(); 
			oInfoObjects.Dispose(); 
			oInfoObject.Dispose(); 
			oReport.Dispose(); 
			oDestinationPlugin.Dispose();  
			oSmtpOptions.Dispose(); 

		}

		#endregion

		#region CreateCalendar

		//Listing 6-23
		[WebMethod]
		public void CreateCalendar(string szServer, string szCalendarName)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oInfoObjects = null; 
			InfoObject oInfoObject = null;
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			Calendar oCalendar = null; 
			string szSQL;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 

			szSQL = "Select SI_ID " +
				"From CI_SYSTEMOBJECTS " +
				"Where SI_NAME = '" + szCalendarName + "' " +
				"And SI_KIND='Calendar'";

			oInfoObjects = oInfoStore.Query(szSQL); 

			//If calendar of this name exists, delete and recreate
			if (oInfoObjects.Count != 0) 
			{
				oCalendar = ((Calendar) oInfoObjects[1]);
				oCalendar.DeleteNow(); 
			}

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("CrystalEnterprise.Calendar");
			oInfoObjects = oInfoStore.NewInfoObjectCollection();
			oInfoObjects.Add(oPluginInfo);

			oInfoObject = oInfoObjects[1];
			oCalendar = ((Calendar) oInfoObject);

			oCalendar.Title = szCalendarName;

			try
			{
				//Runs the first Monday of the month for all of 2006
				//oCalendar.Days.Add(1,1,2006,31,12,2006,CeDayOfWeek.ceDayMonday,1);     

				//Runs every Monday for all of 2006
				//oCalendar.Days.Add(1,1,2006,31,12,2006,CeDayOfWeek.ceDayMonday,0);  

				//Listing 6-24
				//Runs every business day for all of 2006
				oCalendar.Days.Add(1,1,2006,31,12,2006,CeDayOfWeek.ceDayMonday,0);  
				oCalendar.Days.Add(1,1,2006,31,12,2006,CeDayOfWeek.ceDayTuesday,0);  
				oCalendar.Days.Add(1,1,2006,31,12,2006,CeDayOfWeek.ceDayWednesday,0); 
				oCalendar.Days.Add(1,1,2006,31,12,2006,CeDayOfWeek.ceDayThursday,0); 
				oCalendar.Days.Add(1,1,2006,31,12,2006,CeDayOfWeek.ceDayFriday,0);		

				//But let's not run on Christmas day, Mr. Scrooge
				oCalendar.Remove(25,12,2006,25,12,2006);  

				//But we do need a report for New Years Eve even though its a Saturday
				oCalendar.Days.Add(31,12,2006,31,12,2006);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			oInfoStore.Commit(oInfoObjects);

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObject.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;
			oPluginManager.Dispose();
			oPluginInfo.Dispose();
			oCalendar.Dispose();
		}

		#endregion

		#region SetFormats

		//Listing 6-3
		[WebMethod]
		public void SetFormats(string szServer, string szReportID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oReportInfoObjects = null; 
			InfoObject oInfoObject = null; 
			Report oReport = null; 
			ReportFormatOptions oReportFormatOpts = null;
			string szSQL;
			string szID = string.Empty;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				szSQL = "SELECT SI_ID " +  
					"FROM CI_INFOOBJECTS " +  
					"WHERE SI_ID = " + szReportID;

				oReportInfoObjects = oInfoStore.Query(szSQL); 
				oReport = ((Report) oReportInfoObjects[1]);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oReportFormatOpts = oReport.ReportFormatOptions; 



			oReportFormatOpts.Format = CeReportFormat.ceFormatWord;

			WordFormat oWordFormat;

			oWordFormat = oReportFormatOpts.WordFormat;

			oWordFormat.StartPageNumber = 1;
			oWordFormat.EndPageNumber = 10;
			oWordFormat.ExportAllPages = false;



			//Listing 6-4
			oReportFormatOpts.Format = CeReportFormat.ceFormatTextTabSeparated;

			TextFormatTabSeparated oTextFormatTabSeparated;

			oTextFormatTabSeparated = oReportFormatOpts.TextFormatTabSeparated;

			oTextFormatTabSeparated.IsSameDate = true; 
			oTextFormatTabSeparated.IsSameNumber = true; 



			//Listing 6-5
			oReportFormatOpts.Format = CeReportFormat.ceFormatTextPaginated;

			TextFormatPaginated oTextFormatPaginated;

			oTextFormatPaginated = oReportFormatOpts.TextFormatPaginated;

			oTextFormatPaginated.CharactersPerInch = 10; 
			oTextFormatPaginated.LinesPerPage = 50;



			//Listing 6-7
			oReportFormatOpts.Format = CeReportFormat.ceFormatRTF;

			RichTextFormat oRichTextFormat;

			oRichTextFormat = oReportFormatOpts.RichTextFormat;

			oRichTextFormat.StartPageNumber = 1;
			oRichTextFormat.EndPageNumber = 1; 
			oRichTextFormat.ExportAllPages = true;



			//Listing 6-8
			oReportFormatOpts.Format = CeReportFormat.ceFormatRTFEditable;

			RichTextEditableFormat oRichTextEditableFormat;

			oRichTextEditableFormat = oReportFormatOpts.RichTextEditableFormat;

			oRichTextEditableFormat.StartPageNumber = 1;
			oRichTextEditableFormat.EndPageNumber = 1;
			oRichTextEditableFormat.ExportAllPages = true;
			oRichTextEditableFormat.PageBreakAfterEachReportPage = true;


			//Listing 6-9
			oReportFormatOpts.Format = CeReportFormat.ceFormatTextPlain;

			PlainTextFormat oPlainTextFormat;

			oPlainTextFormat = oReportFormatOpts.PlainTextFormat;

			oPlainTextFormat.CharactersPerInch = 10;


			//Listing 6-10
			oReportFormatOpts.Format = CeReportFormat.ceFormatPDF;

			PDFFormat oPDFFormat;

			oPDFFormat = oReportFormatOpts.PDFFormat; 

			oPDFFormat.StartPageNumber = 1;
			oPDFFormat.EndPageNumber = 1;
			oPDFFormat.ExportAllPages = true;
			oPDFFormat.CreateBookmarksFromGroupTree  = true;



			//Listing 6-11
			oReportFormatOpts.Format = CeReportFormat.ceFormatExcel;

			ExcelFormat oExcelFormat;

			oExcelFormat = oReportFormatOpts.ExcelFormat; 

			oExcelFormat.BaseAreaGroupNum = 1;
			oExcelFormat.BaseAreaType = CeSectionType.ceDetail;
			oExcelFormat.ConstColWidth = 30;
			oExcelFormat.ConvertDateToString = true;
			oExcelFormat.CreatePageBreak = true;
			oExcelFormat.ExportAllPages = true;
			oExcelFormat.ExportPageHeader = true;
			oExcelFormat.ExportPageHeaderFooter = 
				CeReportHeaderFooterOption.ceReportHeaderFooterForEachPage;
			oExcelFormat.ExportShowGridlines = true;
			oExcelFormat.HasColumnHeadings = true;
			oExcelFormat.IsTabularFormat = true;
			oExcelFormat.StartPageNumber = 1 ;
			oExcelFormat.EndPageNumber = 1;
			oExcelFormat.UseConstColWidth = true;



			//Listing 6-12
			oReportFormatOpts.Format = CeReportFormat.ceFormatExcelDataOnly;

			ExcelDataOnlyFormat oExcelDataOnlyFormat;

			oExcelDataOnlyFormat = oReportFormatOpts.ExcelDataOnlyFormat;

			oExcelDataOnlyFormat.BaseAreaGroupNum = 1;
			oExcelDataOnlyFormat.BaseAreaType = CeSectionType.ceGroupHeader;
			oExcelDataOnlyFormat.ConstColWidth = 10;
			oExcelDataOnlyFormat.ExportImage = true;
			oExcelDataOnlyFormat.ExportPageHeader = true;
			oExcelDataOnlyFormat.MaintainColAlignment = true;
			oExcelDataOnlyFormat.MaintainRelativeObjPosition = true;
			oExcelDataOnlyFormat.ShowGroupOutlines = true;;
			oExcelDataOnlyFormat.SimplifyPageHeader = true;
			oExcelDataOnlyFormat.UseConstColWidth = true;
			oExcelDataOnlyFormat.UseFormat = true;
			oExcelDataOnlyFormat.UseWorksheetFunc = true;



			//Listing 6-6
			oReportFormatOpts.Format = CeReportFormat.ceFormatTextCharacterSeparated;

			TextFormatCharacterSeparated oTextFormatCharacterSeparated;

			oTextFormatCharacterSeparated = 
				oReportFormatOpts.TextFormatCharacterSeparated;

			oTextFormatCharacterSeparated.Delimiter = ",";
			oTextFormatCharacterSeparated.Separator = ",";
			oTextFormatCharacterSeparated.Quote = "'";
			oTextFormatCharacterSeparated.ExportMode = 
				CeSVExportMode.ceSVExportModeStandard; 
			oTextFormatCharacterSeparated.GroupSectionsOption = 
				CeGroupSectionsOption.ceGroupSectionsExportIsolated;
			oTextFormatCharacterSeparated.ReportSectionsOption = 
				CeReportSectionsOption.ceReportSectionsExportIsolated;
			oTextFormatCharacterSeparated.IsSameDate = true;
			oTextFormatCharacterSeparated.IsSameNumber = true;

			try
			{
				oInfoStore.Commit(oReportInfoObjects);
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oEnterpriseSession.Logoff();

			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null; 
			oInfoStore.Dispose(); 
			oReportInfoObjects.Dispose(); 
			//oInfoObjects.Dispose(); 
			oInfoObject.Dispose(); 
			oReport.Dispose(); 
			oReportFormatOpts.Dispose();
		}

		#endregion

		#region AssignEvents

		//Listing 6-22
		[WebMethod(MessageName="AssignEventsViaLogonID")] 
		public void AssignEvents(string szUserID, string szPassword, string szSystem, string szAuthentication, string szReportID, int iEventID)
		{	
			AssignEvents(szUserID, szPassword, szSystem, szAuthentication, null, szReportID, iEventID);
		}

		[WebMethod(MessageName="AssignEventsViaServer")] 
		public void AssignEvents(string szServer, string szReportID, int iEventID)
		{	
			AssignEvents(null, null, null, null, szServer, szReportID, iEventID);
		}
	
		private void AssignEvents(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szReportID, 
			int iEventID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oInfoObjects = null;
			Report oReport = null;
			string szSQL;
			string szID = string.Empty;
			string szStartDateTime = string.Empty;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			szSQL = "SELECT SI_ID " +
					"FROM CI_INFOOBJECTS " +
					"WHERE SI_ID=" + szReportID;

			oInfoObjects = oInfoStore.Query(szSQL);

			oReport = ((Report) oInfoObjects[1]);

			//Assign the event
			oReport.SchedulingInfo.Dependencies.Add(iEventID);

			//Schedule the report
			szStartDateTime = DateTime.Today.ToShortDateString() + " 1:00:00 PM";

			oReport.SchedulingInfo.IntervalDays = 1;
			oReport.SchedulingInfo.BeginDate = DateTime.Parse(szStartDateTime);
			oReport.SchedulingInfo.EndDate = DateTime.Today.AddYears(10); 
			oReport.SchedulingInfo.Type = CeScheduleType.ceScheduleTypeDaily;
			oReport.SchedulingInfo.RightNow = false;

			//Write the new schedule to the InfoStore
			oInfoStore.Schedule(oInfoObjects);

		}

		#endregion

		#region CreateEvents

		//Listing 6-21
		[WebMethod(MessageName="CreateEventsViaLogonID")] 
		public void CreateEvents(string szUserID, string szPassword, string szSystem, string szAuthentication)
		{	
			CreateEvents(szUserID, szPassword, szSystem, szAuthentication, null);
		}

		[WebMethod(MessageName="CreateEventsViaServer")] 
		public void CreateEvents(string szServer)
		{	
			CreateEvents(null, null, null, null, szServer);
		}
	
		private void CreateEvents(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;			
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			Event oEvent = null;

			oEnterpriseSession = GetIdentity(null, null, null, null, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			oInfoObjects = oInfoStore.NewInfoObjectCollection();

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("Event");
			oInfoObject = oInfoObjects.Add(oPluginInfo);
			oEvent = ((Event) oInfoObject);

			oEvent.Title = "My New File Event"; 
			oEvent.EventType = CeEventType.ceFile;
			oEvent.FileEvent.FileName = @"c:\temp\myfile.txt";
			oEvent.FileEvent.ServerFriendlyName = "seton-notebook.eventserver"; 

//			oEvent.Title = "My New Custom Event"; 
//			oEvent.EventType = CeEventType.ceUser;
//
//			oEvent.UserEvent.Trigger();  

			try
			{
				oInfoStore.Commit(oInfoObjects);
			}
			catch (Exception ex)
			{
				throw ex;
			}

		}
		
		#endregion

		#endregion

		#region RunReportOnDemand

		[WebMethod(MessageName="RunReportOnDemandViaLogonIDWithParams")] 
		public string RunReportOnDemand(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szApplication, 
			string szReportName, 
			CeReportFormat sReportFormat, 
			Int32 iUserID, 
			string[] aParams, 
			CEResponse sCEResponse)
		{	
			return RunReportOnDemand(szUserID, szPassword, szSystem, szAuthentication, null, szApplication, szReportName, sReportFormat, iUserID, aParams, sCEResponse);
		}

		[WebMethod(MessageName="RunReportOnDemandViaServerWithParams")] 
		public string RunReportOnDemand(string szServer, 
			string szApplication, 
			string szReportName, 
			CeReportFormat sReportFormat, 
			Int32 iUserID, 
			string[] aParams, 
			CEResponse sCEResponse)
		{	
			return RunReportOnDemand(null, null, null, null, szServer, szApplication, szReportName, sReportFormat, iUserID, aParams, sCEResponse);
		}

		[WebMethod(MessageName="RunReportOnDemandViaLogonIDWithoutParams")] 
		public string RunReportOnDemand(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szApplication, 
			string szReportName, 
			CeReportFormat sReportFormat, 
			Int32 iUserID, 
			CEResponse sCEResponse)
		{	
			return RunReportOnDemand(szUserID, szPassword, szSystem, szAuthentication, null, szApplication, szReportName, sReportFormat, iUserID, null, sCEResponse);
		}

		[WebMethod(MessageName="RunReportOnDemandViaServerWithoutParams")] 
		public string RunReportOnDemand(string szServer, 
			string szApplication, 
			string szReportName, 
			CeReportFormat sReportFormat, 
			Int32 iUserID, 
			CEResponse sCEResponse)
		{	
			return RunReportOnDemand(null, null, null, null, szServer, szApplication, szReportName, sReportFormat, iUserID, null, sCEResponse);
		}

		private string RunReportOnDemand(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szApplication, 
			string szReportName, 
			CeReportFormat sReportFormat, 
			Int32 iUserID, 
			string[] aParams, 
			CEResponse sCEResponse) 
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null; 
			InfoObjects oReports = null; 
			InfoObject oReport = null; 
			ReportFormatOptions oReportFormatOpts = null; 
			SchedulingInfo oSchedulingInfo = null; 
			InfoObjects oDestinationObjects = null; 
			InfoObject oDestinationObject = null; 
			InfoObjects oScheduledObjects = null; 
			DestinationPlugin oDisk = null; 
			DiskUnmanagedOptions oDiskOpts = null; 
			Destination oDestination = null; 
			ReportParameters oReportParameters = null; 
			ReportParameterSingleValue oReportParameterSingleValue = null; 
			PluginInterface oPluginInterface = null; 
			Report oReportPlugIn = null; 
			string szSQL = string.Empty; 
			string szFileName = string.Empty; 
			string szWorkingDirectory = string.Empty; 
			string szResult = string.Empty; 
			int iLength; 
			int sReportFormatInt16; 
			int sCEResponseInt16; 
			sReportFormatInt16 = ((int)(sReportFormat)); 
			sCEResponseInt16 = ((int)(sCEResponse)); 
			CeScheduleStatus iStatus = CeScheduleStatus.ceStatusFailure;
			string szReportID;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 


			//Listing 9-4
			if (szServer == null)
				szWorkingDirectory = GetDefaultWorkingDirectory();
			else
				szWorkingDirectory = GetCEWorkingDirectory(szServer);

			szFileName = GetTempFileName(iUserID) + GetExtension(sReportFormat); 
			
			
//						Listing 9-11
//						ReportLogons oLogons = null;
//						ReportLogon oLogon = null;
//
//						oPluginInterface = oReport.GetPluginInterface("");
//						oReportPlugIn = new Report(oPluginInterface);
//
//						oLogons = oReportPlugIn.ReportLogons;
//
//						oLogon = oLogons[1];
//
//						oLogon.UseOriginalDataSource = false;
//
//						oLogon.CustomDatabaseDLLName = szDatabaseDLLName;
//						oLogon.CustomServerName = szServerName;
//						oLogon.CustomDatabaseName = szDatabaseName;
//						oLogon.CustomUserName = szUserName;
//						oLogon.CustomPassword = szPassword;
			

			//Listing 9-5
			try 
			{ 
				szSQL = "Select SI_ID,SI_NAME " + 
					"From CI_INFOOBJECTS " + 
					"Where SI_KIND = 'Folder' " + 					
					"And SI_NAME = '" + szApplication + "'"; 

				oReports = oInfoStore.Query(szSQL); 
				oReport = oReports[1]; 
			} 
			catch (Exception ex) 
			{ 
				throw ex; 
			} 

			//Listing 9-6
			try 
			{ 
				//This construct assumes that report names will not be 
				//duplicated across the subfolders within a top folder.

				//szSQL = "Select SI_ID, SI_NAME, SI_PROCESSINFO.SI_PROMPTS, SI_PROCESSINFO.SI_LOGON_INFO " + 
				szSQL = "Select SI_ID, SI_NAME, SI_PROCESSINFO.SI_PROMPTS " + 
					"From CI_INFOOBJECTS " + 
					"Where SI_KIND = 'CrystalReport' " + 
					"And SI_INSTANCE = 0 " + 
					"And SI_ANCESTOR = " + oReport.Properties["SI_ID"].ToString() + 
					"And SI_NAME = '" + szReportName + "'"; 

				oReports = oInfoStore.Query(szSQL); 
				oReport = oReports[1]; 
			} 
			catch (Exception ex) 
			{ 
				throw ex; 
			} 


			//Listing 9-7
			oPluginInterface = oReport.GetPluginInterface(""); 
			oReportPlugIn = new Report(oPluginInterface); 
				
			if (aParams != null)
			{
				try 
				{ 
					oReportParameters = oReportPlugIn.ReportParameters; 

					iLength = aParams.Length - 1; 

					if (oReportParameters.Count > 0) 
					{ 
						for (int i = 0; i <= iLength; i++) 
						{ 
							oReportParameterSingleValue = oReportParameters[i + 1].CreateSingleValue(); 
							oReportParameterSingleValue.Value = aParams[i]; 
							oReportParameters[i + 1].CurrentValues.Clear(); 
							oReportParameters[i + 1].CurrentValues.Add(oReportParameterSingleValue); 
						} 
					} 
				} 
				catch (Exception ex) 
				{ 
					throw ex;   
				} 
			}

			//Listing 9-8
			try 
			{ 
				//set the report object's format options
				oReportFormatOpts = oReportPlugIn.ReportFormatOptions; 
				oReportFormatOpts.Format = sReportFormat; 

				//Create an interface to the scheduling options for the report.
				oSchedulingInfo = oReport.SchedulingInfo; 

				//run the report right now
				oSchedulingInfo.RightNow = true; 

				//run the report once only
				oSchedulingInfo.Type = CeScheduleType.ceScheduleTypeOnce; 

				//When scheduling to all destinations except the printer, 
				//you must first retrieve the appropriate destination object. 
				//Each destination InfoObject is stored in the APS system 
				//table (CI_SYSTEMOBJECTS) under the Destination Plugins 
				//folder. This folder has an ID of 29.
				szSQL = "Select Top 1* " + 
					"From CI_SYSTEMOBJECTS " + 
					"Where SI_PARENTID = 29 " + 
					"And SI_NAME = 'CrystalEnterprise.DiskUnmanaged'"; 

				oDestinationObjects = oInfoStore.Query(szSQL); 

				oDestinationObject = oDestinationObjects[1];

				//Create the DestinationPlugin object
				oDisk = new DestinationPlugin(oDestinationObject.PluginInterface); 								

				//Create a diskUnmanagedOptions object and its ScheduleOptions 
				//from the Destination plugin
				oDiskOpts = new DiskUnmanagedOptions(oDisk.ScheduleOptions); 
				oDiskOpts.DestinationFiles.Add(szWorkingDirectory + szFileName); 

				//Copy the properties from the Destination Plugin object into 
				//the report's scheduling information. This will cause the file 
				//to be transfered to Disk after it has been run.
				oDestination = oSchedulingInfo.Destination; 
				oDestination.SetFromPlugin(oDisk); 

				oInfoStore.Schedule(oReports); 
			} 
			catch (Exception ex) 
			{ 
				throw ex;   
			} 
			

			szReportID = oReport.Properties["SI_NEW_JOB_ID"].Value.ToString();

			//Listing 9-9
			do 
			{ 				
				szSQL = "Select SI_SCHEDULE_STATUS " + 
					"From CI_INFOOBJECTS " + 
					"Where SI_ID = " + szReportID;

				oScheduledObjects = oInfoStore.Query(szSQL); 
					
				iStatus = oScheduledObjects[1].SchedulingInfo.Status;    
				
				if (iStatus == CeScheduleStatus.ceStatusFailure) 
					break; 
				
				System.Threading.Thread.Sleep(500); 

			} while (iStatus != CeScheduleStatus.ceStatusSuccess); 

			oEnterpriseSession.Dispose(); 
			oInfoStore.Dispose(); 
			oReports.Dispose(); 
			oReport.Dispose(); 
			oReportFormatOpts.Dispose(); 
			oSchedulingInfo.Dispose(); 
			oDestinationObjects.Dispose(); 
			oDestinationObject.Dispose(); 
			oDisk.Dispose(); 
			oDiskOpts.Dispose(); 
			oDestination.Dispose(); 
			oReportParameters.Dispose(); 
			
			if (oReportParameterSingleValue != null)
				oReportParameterSingleValue.Dispose(); 

			oEnterpriseSession = null; 
			oInfoStore = null; 
			oEnterpriseService = null; 
			oReports = null; 
			oReport = null; 
			oReportFormatOpts = null; 
			oSchedulingInfo = null; 
			oDestinationObjects = null; 
			oDestinationObject = null; 
			oDisk = null; 
			oDiskOpts = null; 
			oDestination = null; 
			oReportParameters = null; 
			oReportParameterSingleValue = null; 
		
			//Listing 9-10
			if (sCEResponse == CEResponse.Base64EncodedString) 
				szResult = Base64Encode(szWorkingDirectory + szFileName); 
			else 
				szResult = szFileName; 

			return szResult; 
		}

		//Listing 9-2
		private string Base64Encode(string szFileName) 
		{ 
			System.IO.FileStream oFileStream; 
			int lBytes; 
			string szResult; 
			
			oFileStream = new System.IO.FileStream(szFileName, 
				System.IO.FileMode.Open, System.IO.FileAccess.Read); 
			
			byte[] aData = new byte[oFileStream.Length + 1];

			lBytes = oFileStream.Read(aData, 0, ((int) oFileStream.Length + 1)); 
			oFileStream.Close(); 
			
			szResult = System.Convert.ToBase64String(aData, 0, aData.Length); 
			
			return szResult; 
		} 

		private string GetTempFileName(long lUserID) 
		{ 
			string cResult; 
			
			cResult = DateTime.Now.Month.ToString() + 
				DateTime.Now.Day.ToString() + 
				DateTime.Now.Year.ToString() + 
				DateTime.Now.Hour.ToString() + 
				DateTime.Now.Minute.ToString() + 
				DateTime.Now.Second.ToString() + "_" + lUserID; 

			return cResult; 
		} 

		[WebMethod]
		public string GetExtension(CeReportFormat sReportFormat) 
		{ 
			string szResult = string.Empty; 

			switch ( sReportFormat)
			{
				case CeReportFormat.ceFormatCrystalReport:
					szResult = "rpt";
					break;

				case CeReportFormat.ceFormatExcel:
				case CeReportFormat.ceFormatExcelDataOnly:
					szResult = "xls";
					break;

				case CeReportFormat.ceFormatPDF:
					szResult = "pdf";
					break;

				case CeReportFormat.ceFormatRTF:
					szResult = "rtf";
					break;		
					
				case CeReportFormat.ceFormatTextCharacterSeparated:
				case CeReportFormat.ceFormatTextPaginated:
				case CeReportFormat.ceFormatTextPlain:
				case CeReportFormat.ceFormatTextTabSeparated:
				case CeReportFormat.ceFormatTextTabSeparatedText: 									
					szResult = "txt";
					break;

				case CeReportFormat.ceFormatUserDefined:
					szResult = "udf";
					break;

				case CeReportFormat.ceFormatWord:
					szResult = "doc";
					break;			
			}

			return "." + szResult; 
		}

		#endregion

		#region Custom Properties

		[WebMethod(MessageName="AddPropertyViaLogonID")] 
		public void AddProperty(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication,
			string szReportID)
		{	
			AddProperty(szUserID, szPassword, szSystem, szAuthentication, null, szReportID);
		}

		[WebMethod(MessageName="AddPropertyViaServer")] 
		public void AddProperty(string szServer,
			string szReportID)
		{	
			AddProperty(null, null, null, null, szServer, szReportID);
		}

		//Listing 9-48
		public void AddProperty(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer,
			string szID)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			string szSQL;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			szSQL = "Select SI_ID, MY_CUSTOM_HEADER " +
					"From CI_INFOOBJECTS " + 
					"Where SI_ID = " +  szID;

			oInfoObjects = oInfoStore.Query(szSQL);

			//Can delete like this:
			oInfoObjects[1].Properties.Delete("SI_ID");
			//oInfoObjects[1].Properties.Delete("TEST_MultipleValueProperty");
			

			//If property of this name already exists the value will be updated
			//oInfoObjects[1].Properties.Add("MY_HEADER", "This is a custom header");  

			//Listing 9-49
//			Property oProperty = oInfoObjects[1].Properties.Add("MY_CUSTOM_HEADER", 
//				String.Empty, CePropFlags.cePropFlagBag);
//			oProperty.Properties.Add("MY_LEFT_SIDE", "Seton Software Development, Inc.");
//			oProperty.Properties.Add("MY_RIGHT_SIDE", "Personal and Confidential");

			oInfoStore.Commit(oInfoObjects);
		}

		#endregion

		#region Server

		#region ServerSummary

		//Listing 2-1
		[WebMethod(MessageName="ServerSummaryViaLogonID")] 
		public System.Data.DataSet ServerSummary(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication)
		{	
			return ServerSummary(szUserID, szPassword, szSystem, szAuthentication, null);
		}

		[WebMethod(MessageName="ServerSummaryViaServer")] 
		public System.Data.DataSet ServerSummary(string szServer)
		{	
			return ServerSummary(null, null, null, null, szServer);
		}
	
		private System.Data.DataSet ServerSummary(string szUserID, string szPassword, string szSystem, string szAuthentication, string szServer)
		{			
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				szSQL = "SELECT SI_ID, SI_NAME, SI_DESCRIPTION, " +
						"SI_OWNER, SI_SERVER_ID, SI_SERVER_KIND, " +
						"SI_FRIENDLY_NAME, SI_SERVER_NAME, SI_NTSERVICE_NAME, " +
						"SI_REGISTER_TO_APS, SI_SERVER_DESCRIPTOR " +
						"FROM CI_SYSTEMOBJECTS  " +
						"WHERE SI_KIND = 'Server' " +
						"ORDER BY SI_DESCRIPTION";

				oInfoObjects = oInfoStore.Query(szSQL);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("Name"));
			oDT.Columns.Add(new DataColumn("Description"));
			oDT.Columns.Add(new DataColumn("Owner"));
			oDT.Columns.Add(new DataColumn("ServerID"));
			oDT.Columns.Add(new DataColumn("ServerKind"));
			oDT.Columns.Add(new DataColumn("FriendlyName"));
			oDT.Columns.Add(new DataColumn("ServerName"));
			oDT.Columns.Add(new DataColumn("NTServiceName"));
			oDT.Columns.Add(new DataColumn("RegisterToAPS"));
			oDT.Columns.Add(new DataColumn("ServerDescriptor"));

			foreach (InfoObject oInfoObject in oInfoObjects)
			{
				oDR = oDT.NewRow();
 
				oDR["ID"] = 
					oInfoObject.Properties["SI_ID"].ToString(); 
				oDR["Name"] = 
					oInfoObject.Properties["SI_NAME"].ToString(); 
				oDR["Description"] = 
					oInfoObject.Properties["SI_DESCRIPTION"].ToString();
				oDR["Owner"] = 
					oInfoObject.Properties["SI_OWNER"].ToString();
				oDR["ServerID"] = 
					oInfoObject.Properties["SI_SERVER_ID"].ToString();
				oDR["ServerKind"] = 
					oInfoObject.Properties["SI_SERVER_KIND"].ToString();
				oDR["FriendlyName"] = 
					oInfoObject.Properties["SI_FRIENDLY_NAME"].ToString();
				oDR["ServerName"] = 
					oInfoObject.Properties["SI_SERVER_NAME"].ToString();
				oDR["NTServiceName"] =
					oInfoObject.Properties["SI_NTSERVICE_NAME"].ToString();
				oDR["RegisterToAPS"] = 
					oInfoObject.Properties["SI_REGISTER_TO_APS"].ToString();
				oDR["ServerDescriptor"] = 
					oInfoObject.Properties["SI_SERVER_DESCRIPTOR"].ToString();

				oDT.Rows.Add(oDR);  
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose();
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);  

			return oDS;
		}

		#endregion

		#region ServerInformation

		[WebMethod(MessageName="ServerInformationViaLogonID")] 
		public string ServerInformation(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication,
			string szServerID)
		{	
			return ServerInformation(szUserID, szPassword, szSystem, szAuthentication, null, szServerID);
		}

		[WebMethod(MessageName="ServerInformationsViaServer")] 
		public string ServerInformation(string szServer, string szServerID)
		{	
			return ServerInformation(null, null, null, null, szServer, szServerID);
		}
	
		private string ServerInformation(string szUserID, string szPassword, string szSystem, string szAuthentication, string szServer, string szServerID)
		{	
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			Server oServer = null;
			ServerGeneralMetrics oServerGeneralMetrics;
			CmsAdmin oCmsAdmin = null;
			ReportAppServerAdmin oReportAppServerAdmin = null;
			FileServerAdmin oFileServerAdmin = null;
			EventServerAdmin oEventServerAdmin = null;
			PageServerAdmin oPageServerAdmin = null;
			CacheServerAdmin oCacheServerAdmin = null;
			JobServerAdmin oJobServerAdmin = null;
			XmlDocument oXmlDocument;
			XmlElement oXmlElement;
			XmlElement oXmlMainElement = null;
			XmlElement oXmlSubElement = null;
			string szSQL;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				if (szServerID != "")
				{
					szSQL = "SELECT SI_ID, SI_NAME, SI_SERVER_KIND " +
						"FROM CI_SYSTEMOBJECTS " +
						"WHERE SI_ID = " + szServerID;
				}
				else
				{
					szSQL = "SELECT SI_ID, SI_NAME, SI_SERVER_KIND " +
						"FROM CI_SYSTEMOBJECTS " +
						"WHERE SI_KIND = 'Server'";
				}

				oInfoObjects = oInfoStore.Query(szSQL);

			}
			catch (Exception ex)
			{
				throw ex;
			}

			oXmlDocument = new XmlDocument();

			oXmlElement = oXmlDocument.CreateElement("", "ServerGeneralAdmin", "");
			oXmlDocument.AppendChild(oXmlElement);

			foreach(InfoObject oInfoObject in oInfoObjects)
			{
				oServer = ((Server) oInfoObject);

				oServerGeneralMetrics = oServer.ServerGeneralAdmin;

				oXmlMainElement = oXmlDocument.CreateElement("Server");
				oXmlMainElement.SetAttribute("SI_NAME", oInfoObject.Properties["SI_NAME"].ToString());

				oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "CPU", oServerGeneralMetrics.CPU, null, null);
				oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "CPUCount", oServerGeneralMetrics.CPUCount.ToString(), null, null);
				oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "CurrentTime", oServerGeneralMetrics.CurrentTime.ToString(), null, null);
				oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "StartTime", oServerGeneralMetrics.StartTime.ToString(), null, null);
				oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "DiskSpaceAvailable", oServerGeneralMetrics.DiskSpaceAvailable.ToString(), null, null);
				oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "DiskSpaceTotal", oServerGeneralMetrics.DiskSpaceTotal.ToString(), null, null);
				oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Memory", oServerGeneralMetrics.Memory.ToString(), null, null);
				oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "OperatingSystem", oServerGeneralMetrics.OperatingSystem, null, null);
				oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Version", oServerGeneralMetrics.Version, null, null);


				switch (oServer.ServerKind) // need to pull SI_SERVER_KIND in SQL for this property to work
				{

					//Listing 2-2
					case "aps":
						oCmsAdmin = new CmsAdmin(oServer.ServerAdmin);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "APSDatabaseName", oCmsAdmin.APSDatabaseName, null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "APSDatabaseUserName", oCmsAdmin.APSDatabaseUserName, null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "APSDataSourceName", oCmsAdmin.APSDataSourceName, null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "APSPrivateBuildNumber", oCmsAdmin.APSPrivateBuildNumber.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "APSPrivateBuildNumber", oCmsAdmin.APSPrivateBuildNumber.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "APSProductVersion", oCmsAdmin.APSProductVersion, null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "PendingJobs", oCmsAdmin.PendingJobs.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "RunningJobs", oCmsAdmin.RunningJobs.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "SuccessJobs", oCmsAdmin.SuccessJobs.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "WaitingJobs", oCmsAdmin.WaitingJobs.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "FailedJobs", oCmsAdmin.FailedJobs.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "LicensesConcurrent", oCmsAdmin.LicensesConcurrent.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "LicensesNamedUsers", oCmsAdmin.LicensesNamedUsers.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "LicensesProcessors", oCmsAdmin.LicensesProcessors.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "UserConnectedConcurrent", oCmsAdmin.UserConnectedConcurrent.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "UserConnectedNamedUsers", oCmsAdmin.UserConnectedNamedUsers.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "UserExistingConcurrent", oCmsAdmin.UserExistingConcurrent.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "UserExistingNamedUsers", oCmsAdmin.UserExistingNamedUsers.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "UserTokenConnections", oCmsAdmin.UserTokenConnections.ToString(), null, null);

						if (oCmsAdmin.ClusterMembers.Count != 0)
						{
							oXmlSubElement = oXmlDocument.CreateElement("ClusterMembers");

							foreach (string szClusterMembers in oCmsAdmin.ClusterMembers)
								oXmlSubElement = AddElement(oXmlDocument, oXmlSubElement, "ClusterMember", szClusterMembers, null, null);

							oXmlMainElement.AppendChild(oXmlSubElement);
						}

						break;

					case "rptappserver":
						oReportAppServerAdmin = new ReportAppServerAdmin(oServer.ServerAdmin);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "AgentTimeout", oReportAppServerAdmin.AgentTimeout.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "AutomaticDBDisconnect", oReportAppServerAdmin.AutomaticDBDisconnect.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "CurrentAgentCount", oReportAppServerAdmin.CurrentAgentCount.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "CurrentDocumentCount", oReportAppServerAdmin.CurrentDocumentCount.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "EnableAsyncQuery", oReportAppServerAdmin.EnableAsyncQuery.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "EnablePushDownGroupBy", oReportAppServerAdmin.EnablePushDownGroupBy.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "EnableSelectDistinctRecords", oReportAppServerAdmin.EnableSelectDistinctRecords.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxNumOfRecords", oReportAppServerAdmin.MaxNumOfRecords.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxReportJobs", oReportAppServerAdmin.MaxReportJobs.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MinutesBetweenDBRefresh", oReportAppServerAdmin.MinutesBetweenDBRefresh.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "NumOfBrowsingRecords", oReportAppServerAdmin.NumOfBrowsingRecords.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "RowsetBatchSize", oReportAppServerAdmin.RowsetBatchSize.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "TotalAgentCount", oReportAppServerAdmin.TotalAgentCount.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "TotalDocumentCount", oReportAppServerAdmin.TotalDocumentCount.ToString(), null, null);
						//oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "UseInprocAgent", oReportAppServerAdmin.UseInprocAgent.ToString(), null, null);
						break;

					case "fileserver":
						oFileServerAdmin = new FileServerAdmin(oServer.ServerAdmin);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "AvailableDiskPercent", oFileServerAdmin.AvailableDiskPercent.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "AvailableDiskSpace", oFileServerAdmin.AvailableDiskSpace.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "TotalDiskSpace" , oFileServerAdmin.TotalDiskSpace.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "BytesSent", oFileServerAdmin.BytesSent.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "BytesWritten", oFileServerAdmin.BytesWritten.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "ClientConnections", oFileServerAdmin.ClientConnections.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "DiskSpaceLeft", oFileServerAdmin.DiskSpaceLeft.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Hostname", oFileServerAdmin.Hostname.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxIdleTime", oFileServerAdmin.MaxIdleTime.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "RootDirectory", oFileServerAdmin.RootDirectory, null, null); 					
						
						//Listing 2-6
						if (oFileServerAdmin.ListActiveFiles.Count > 0)
						{
							oXmlSubElement = oXmlDocument.CreateElement("ActiveFiles");

							foreach(FRSAdminFile oFRSAdminFile in oFileServerAdmin.ListActiveFiles)
							{
								oXmlSubElement = AddElement(oXmlDocument, oXmlSubElement, "Filename", oFRSAdminFile.Filename.ToString(), null, null);
								oXmlSubElement = AddElement(oXmlDocument, oXmlSubElement, "Readers", oFRSAdminFile.Readers.ToString(), null, null);
								oXmlSubElement = AddElement(oXmlDocument, oXmlSubElement, "Writers", oFRSAdminFile.Writers.ToString(), null, null);
							}

							oXmlMainElement.AppendChild(oXmlSubElement);
						}

						break;

					case "eventserver":
						oEventServerAdmin = new EventServerAdmin(oServer.ServerAdmin);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Events", oEventServerAdmin.Events.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "FilePollTime", oEventServerAdmin.FilePollTime.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Hostname", oEventServerAdmin.Hostname, null, null); 

						//Listing 2-7
						if (oEventServerAdmin.ListFileMonitored.Count > 0)
						{
							oXmlSubElement = oXmlDocument.CreateElement("MonitoredFiles");

							foreach (EventServerAdminFile oEventServerAdminFile in oEventServerAdmin.ListFileMonitored)
								oXmlSubElement = AddElement(oXmlDocument, oXmlSubElement, "Filename", oEventServerAdminFile.Filename.ToString(), "LastNotifiedTime", oEventServerAdminFile.LastNotifiedTime.ToString());

							oXmlMainElement.AppendChild(oXmlSubElement);
						}
						
						break;

					case "pageserver":
						oPageServerAdmin = new PageServerAdmin(oServer.ServerAdmin);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "BytesTransferred", oPageServerAdmin.BytesTransferred.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Connections", oPageServerAdmin.Connections.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Directory", oPageServerAdmin.Directory, null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxIdleTime", oPageServerAdmin.MaxIdleTime.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxIdleTimeUpdate", oPageServerAdmin.MaxIdleTimeUpdate.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxThreads", oPageServerAdmin.MaxThreads.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Threads", oPageServerAdmin.Threads.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "QueuedRequests", oPageServerAdmin.QueuedRequests.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "TotalRequests", oPageServerAdmin.TotalRequests.ToString(), null, null); 
						break;

					case "jobserver":
						oJobServerAdmin = new JobServerAdmin(oServer.ServerAdmin);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "CurrentJobs", oJobServerAdmin.CurrentJobs.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "DLLName", oJobServerAdmin.DLLName, null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "FailedCreated", oJobServerAdmin.FailedCreated.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxJobs" , oJobServerAdmin.MaxJobs.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "ObjectTypeName", oJobServerAdmin.ObjectTypeName, null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "ProcType", oJobServerAdmin.ProcType.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "TempDir", oJobServerAdmin.TempDir, null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "TotalJobs", oJobServerAdmin.TotalJobs.ToString(), null, null); 

						//Listing 2-11
						if (oJobServerAdmin.Destinations.Count > 0)
						{
							oXmlSubElement = oXmlDocument.CreateElement("SupportedDestination");

							foreach(JobServerDestination oJobServerDestination in oJobServerAdmin.Destinations)
							oXmlSubElement = AddElement(oXmlDocument, oXmlSubElement, "Name", oJobServerDestination.Name.ToString(), "Enabled", oJobServerDestination.Enabled.ToString());

							oXmlMainElement.AppendChild(oXmlSubElement);
						}

						break;

					case "cacheserver":
						oCacheServerAdmin = new CacheServerAdmin(oServer.ServerAdmin);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "BytesTransferred", oCacheServerAdmin.BytesTransferred.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "CacheSize", oCacheServerAdmin.CacheSize.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "CacheSizeUpdate" , oCacheServerAdmin.CacheSizeUpdate.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Connections", oCacheServerAdmin.Connections.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Directory", oCacheServerAdmin.Directory, null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "DriveSpaceUsed", oCacheServerAdmin.DriveSpaceUsed.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "HitRate", oCacheServerAdmin.HitRate.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxIdleTime", oCacheServerAdmin.MaxIdleTime.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxIdleTimeUpdate", oCacheServerAdmin.MaxIdleTimeUpdate.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "MaxThreads", oCacheServerAdmin.MaxThreads.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "QueuedRequests", oCacheServerAdmin.QueuedRequests.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Refresh", oCacheServerAdmin.Refresh.ToString(), null, null);
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "RefreshAlwaysHitsDb", oCacheServerAdmin.RefreshAlwaysHitsDb.ToString(), null, null); 
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "Threads", oCacheServerAdmin.Threads.ToString(), null, null);  
						oXmlMainElement = AddElement(oXmlDocument, oXmlMainElement, "TotalRequests", oCacheServerAdmin.TotalRequests.ToString(), null, null);  
						
						//Listing 2-13
						if (oCacheServerAdmin.PageServerConnection.Count > 0)
						{
							oXmlSubElement = oXmlDocument.CreateElement("PageServerConnections");

							foreach(PageServerConnection oPageServerConnection in oCacheServerAdmin.PageServerConnection)
								oXmlSubElement = AddElement(oXmlDocument, oXmlSubElement, "ServerName", oPageServerConnection.ServerName.ToString(), "Connections", oPageServerConnection.Connections.ToString());
							
							oXmlMainElement.AppendChild(oXmlSubElement);
						}

						break;
						
				}

				oXmlElement.AppendChild(oXmlMainElement);
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose();
			oEnterpriseService = null;

			return oXmlDocument.OuterXml;
		}

		#endregion

		#region CreateServerGroup

		//Listing 2-15
		[WebMethod(MessageName="CreateServerGroupViaLogonID")] 
		public string CreateServerGroup(string szUserID, string szPassword, string szSystem, string szAuthentication, string szServerGroupName)
		{	
			return CreateServerGroup(szUserID, szPassword, szSystem, szAuthentication, null, szServerGroupName);
		}

		[WebMethod(MessageName="AddServerGroupViaServer")] 
		public string CreateServerGroup(string szServer, string szServerGroupName)
		{	
			return CreateServerGroup(null, null, null, null, szServer, szServerGroupName);
		}
	
		private string CreateServerGroup(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			string szServerGroupName)
		{	
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;			
			PluginManager oPluginManager = null;
			PluginInfo oPluginInfo = null;
			ServerGroup oServerGroup = null;
			string szResult;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			oInfoObjects = oInfoStore.NewInfoObjectCollection();

			oPluginManager = oInfoStore.PluginManager;
			oPluginInfo = oPluginManager.GetPluginInfo("ServerGroup");
			oInfoObject = oInfoObjects.Add(oPluginInfo);
			oServerGroup = ((ServerGroup) oInfoObject);

			oServerGroup.Title = szServerGroupName;

			try
			{
				oInfoStore.Commit(oInfoObjects);
			}

			catch (Exception ex)
			{
				throw ex;
			}

			szResult = oServerGroup.ID.ToString();

			oEnterpriseSession.Logoff();

			oPluginManager.Dispose();
			oPluginInfo.Dispose(); 
			oServerGroup.Dispose(); 
			oInfoStore.Dispose();
			oInfoObject.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			return szResult;			
		}

		#endregion

		#region AddServerToGroup

		//Listing 2-16
		[WebMethod(MessageName="AddServerToGroupViaLogonID")] 
		public void AddServerToGroup(string szUserID, string szPassword, string szSystem, string szAuthentication, int iServerGroupID, string szServerName)
		{	
			AddServerToGroup(szUserID, szPassword, szSystem, szAuthentication, null, iServerGroupID, szServerName);
		}

		[WebMethod(MessageName="AddServerToGroupViaServer")] 
		public void AddServerToGroup(string szServer, int iServerGroupID, string szServerName)
		{	
			AddServerToGroup(null, null, null, null, szServer, iServerGroupID, szServerName);
		}
	
		private void AddServerToGroup(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			int iServerGroupID,
			string szServerName)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObject oInfoObject = null;
			InfoObjects oInfoObjects = null;
			ServerGroup oServerGroup = null;
			string szSQL = string.Empty;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService); 
			
			try
			{
				szSQL = "SELECT SI_ID " + 
					"FROM CI_SYSTEMOBJECTS " + 
					"WHERE SI_ID = " + iServerGroupID.ToString();

				oInfoObjects = oInfoStore.Query(szSQL); 
				oInfoObject = oInfoObjects[1]; 
			}
			catch(Exception ex)
			{
				throw ex;
			}

			oServerGroup = ((ServerGroup) oInfoObject);

			oServerGroup.Servers.Add(szServerName);

			oInfoStore.Commit(oInfoObjects);

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObject.Dispose();
			oInfoObjects.Dispose();
			oServerGroup.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

		}

		#endregion

		#region GetServersInGroup

		//Listing 2-17
		[WebMethod(MessageName="GetServersInGroupViaLogonID")] 
		public System.Data.DataSet GetServersInGroup(string szUserID, string szPassword, string szSystem, string szAuthentication, string szServerGroupID)
		{	
			return GetServersInGroup(szUserID, szPassword, szSystem, szAuthentication, null, szServerGroupID);
		}

		[WebMethod(MessageName="GetServersInGroupViaServer")] 
		public System.Data.DataSet GetServersInGroup(string szServer, string szServerGroupID)
		{	
			return GetServersInGroup(null, null, null, null, szServer, szServerGroupID);
		}

		private System.Data.DataSet GetServersInGroup(string szUserID, string szPassword, string szSystem, string szAuthentication, string szServer, string szServerGroupID)
		{			
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			Property oProperty = null;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;
			int iCnt;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Extract a server group object
			try
			{
				szSQL = "SELECT SI_GROUP_MEMBERS " +
					"FROM CI_SYSTEMOBJECTS " +
					"WHERE SI_ID = " + szServerGroupID;

				oInfoObjects = oInfoStore.Query(szSQL);
			}
			catch (Exception ex)
			{
				throw ex;
			}

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("Name"));

			if (HasMember(oInfoObjects[1].Properties, "SI_GROUP_MEMBERS"))
			{
				//Set a property bag reference so the code's not so long
				oProperty = oInfoObjects[1].Properties["SI_GROUP_MEMBERS"];

				//How many members does the group have?
				iCnt = ((int) oProperty.Properties["SI_TOTAL"].Value);

				//The names start with the second property
				for (int x = 2; x <= iCnt + 1; x++)
				{
					oDR = oDT.NewRow();

					//Assign the server's information to the DataTable
					oDR["Name"] = oProperty.Properties[x].Value; 

					oDT.Rows.Add(oDR);  
				}
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);  

			return oDS;
		}

		#endregion

		#endregion

		#region LogonFunctions

		//Listing 5-9
		#region LoggedOnUserInformation

		[WebMethod(MessageName="LoggedOnUserInformationViaLogonID")] 
		public System.Data.DataSet LoggedOnUserInformation(string szUserID, string szPassword, string szSystem, string szAuthentication)
		{	
			return LoggedOnUserInformation(szUserID, szPassword, szSystem, szAuthentication, null);
		}

		[WebMethod(MessageName="LoggedOnUserInformationViaServer")] 
		public System.Data.DataSet LoggedOnUserInformation(string szServer)
		{	
			return LoggedOnUserInformation(null, null, null, null, szServer);
		}

		private System.Data.DataSet LoggedOnUserInformation(string szUserID, string szPassword, string szSystem, string szAuthentication, string szServer)
		{
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			InfoStore oInfoStore = null;
			InfoObjects oInfoObjects = null;
			CrystalDecisions.Enterprise.Desktop.Connection oConnection;
			System.Data.DataSet oDS;
			DataTable oDT;
			DataRow oDR;
			string szSQL;

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			try
			{
				szSQL = "SELECT SI_ID, SI_NAME, SI_AUTHEN_METHOD, " +
						"SI_LAST_ACCESS, SI_USERID, SI_LOGON_ALIAS " +
						"FROM CI_SYSTEMOBJECTS " +
						"WHERE SI_KIND = 'Connection'";

				oInfoObjects = oInfoStore.Query(szSQL);

			}
			catch (Exception ex)
			{
				throw ex;
			}

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("ID"));
			oDT.Columns.Add(new DataColumn("Name"));
			oDT.Columns.Add(new DataColumn("AuthenticationMethod"));
			oDT.Columns.Add(new DataColumn("LastAccess"));
			oDT.Columns.Add(new DataColumn("UserID"));
			oDT.Columns.Add(new DataColumn("LogonAlias"));

			foreach (InfoObject oInfoObject in oInfoObjects)
			{
				oConnection = ((CrystalDecisions.Enterprise.Desktop.Connection) oInfoObject);

				oDR = oDT.NewRow();
 
				oDR["ID"] = oConnection.ID;
				oDR["Name"] = oConnection.Title;
				oDR["AuthenticationMethod"] = oConnection.AuthenticationMethod; 
				oDR["LastAccess"] = oConnection.LastAccess; 
				oDR["UserID"] = oConnection.UserID; 
				oDR["LogonAlias"] = oConnection.UserAlias; 

				oDT.Rows.Add(oDR);  
			}

			oEnterpriseSession.Logoff(); 

			oInfoStore.Dispose();
			oInfoObjects.Dispose();
			oEnterpriseSession.Dispose(); 
			oEnterpriseService = null;

			oDS = new System.Data.DataSet();

			oDS.Tables.Add(oDT);  

			return oDS;

		}

		//Listing 5-6
		private EnterpriseSession ConnectTrusted()
		{
			SessionMgr oSessionMgr = null;
			TrustedPrincipal oTrustedPrincipal = null; 
			EnterpriseSession oEnterpriseSession = null;

			oSessionMgr = new SessionMgr();
			oTrustedPrincipal = 
				oSessionMgr.CreateTrustedPrincipal("Administrator", 
				"SETON-NOTEBOOK:6400");
			oEnterpriseSession = 
				oSessionMgr.LogonTrustedPrincipal(oTrustedPrincipal);

			return oEnterpriseSession;
		}

		//Listing 5-2
		private EnterpriseSession GetIdentity(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer)
		{
			EnterpriseSession oEnterpriseSession = null;
			SessionMgr oSessionMgr = null;
			
			//Instantiate new SessionMgr object
			oSessionMgr = new SessionMgr();
			
			//If server code - Dev, QA, Prod, etc - was used obtain 
			//connection information from XML file
			if (szServer != null && szServer.Length > 0)
				GetLoginInfo(szServer, 
					ref szUserID, 
					ref szPassword, 
					ref szSystem, 
					ref szAuthentication);

			//Use your decryption technology to decrypt password
			//szPassword = DecryptData(szPassword);

			//Connect to BO XI
			oEnterpriseSession = oSessionMgr.Logon(szUserID, szPassword, 
				szSystem, szAuthentication);

			oSessionMgr.Dispose(); 

			return oEnterpriseSession;

		}

		//Listing 5-4
		private string GetToken(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer)
		{
			EnterpriseSession oEnterpriseSession = null;
			SessionMgr oSessionMgr = null;
			string szToken;
			
			//Instantiate new SessionMgr object
			oSessionMgr = new SessionMgr();
			
			//If server code - Dev, QA, Prod, etc - was used obtain 
			//connection information from XML file
			if (szServer != null && szServer.Length > 0)
				GetLoginInfo(szServer, 
							 ref szUserID, 
							 ref szPassword, 
							 ref szSystem, 
							 ref szAuthentication);

			//Use your decryption technology to decrypt password
			//szPassword = DecryptData(szPassword);

			//Connect to BO XI
			oEnterpriseSession = oSessionMgr.Logon(szUserID, szPassword, 
				szSystem, szAuthentication);

			//szToken = oEnterpriseSession.LogonTokenMgr.DefaultToken; 

			szToken = oEnterpriseSession.LogonTokenMgr.
				CreateWCATokenEx(Environment.MachineName, 10, 100);  

			oSessionMgr.Dispose();

			return szToken;

		}

		//Listing 5-5
		private EnterpriseSession GetIdentityWithToken(string szToken)
		{
			EnterpriseSession oEnterpriseSession = null;
			SessionMgr oSessionMgr = null;
			
			//Instantiate new SessionMgr object
			oSessionMgr = new SessionMgr();			

			//Connect to BO XI
			oEnterpriseSession = oSessionMgr.LogonWithToken(szToken); 

			oSessionMgr.Dispose(); 

			return oEnterpriseSession;
		}

		private void GetLoginInfo(string szServer,
									ref string szUserID,
									ref string szPassword,
									ref string szAPS,
									ref string szAuthentication)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load(Server.MapPath("settings.xml"));

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/UserID");
			szUserID = oXmlNode.InnerText;

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/Password");
			szPassword = oXmlNode.InnerText;

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/APS");
			szAPS = oXmlNode.InnerText;

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/Authentication");
			szAuthentication = oXmlNode.InnerText;			

			oXmlDocument = null;
			oXmlNode = null;
		}

		private string GetCEWorkingDirectory(string szServer)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			string szResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load(Server.MapPath("settings.xml"));

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/WorkingDirectory");
			szResult = oXmlNode.InnerText;

			if (szResult.Substring(szResult.Length - 1, 1) != @"\")
				szResult = szResult + @"\";
  
			oXmlDocument = null;
			oXmlNode = null;

			return szResult;
		}

		private string GetDefaultWorkingDirectory()
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			string szResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load(Server.MapPath("settings.xml"));

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/WorkingDirectory");
			szResult = oXmlNode.InnerText;

			//Add backslash at end if doesn't already exist
			if (szResult.Substring(szResult.Length - 1, 1) != @"\")
				szResult = szResult + @"\";
  
			oXmlDocument = null;
			oXmlNode = null;

			return szResult;
		}


		//Listing 5-7
		[WebMethod] 
		public string SystemInfoProperty(string szServer)
		{
			EnterpriseSession oEnterpriseSession = null;
			System.Text.StringBuilder oStringBuilder;
			string szUserID = string.Empty;
			string szPassword = string.Empty; 
			string szSystem = string.Empty;
			string szAuthentication = string.Empty;

			GetLoginInfo(szServer, 
				ref szUserID, 
				ref szPassword, 
				ref szSystem, 
				ref szAuthentication);

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, szAuthentication, szServer);	
		
			oStringBuilder = new System.Text.StringBuilder();

			foreach(SystemInfoProperty oSystemInfoProperty in 
				oEnterpriseSession.SystemInfoProperties)
				oStringBuilder.AppendFormat("{0} = {1}\n", 
					oSystemInfoProperty.Name, oSystemInfoProperty.Value);

			return oStringBuilder.ToString();
		}

		#endregion

		#endregion

		#region Utility

		//Listing 5-12
		[WebMethod(MessageName="ConvertToUTCViaLogonID")] 
		public string ConvertToUTC(string szUserID, string szPassword, string szSystem, string szAuthentication, DateTime dDateTime)
		{	
			return ConvertToUTC(szUserID, szPassword, szSystem, szAuthentication, null, dDateTime);
		}

		[WebMethod(MessageName="ConvertToUTCViaServer")] 
		public string ConvertToUTC(string szServer, DateTime dDateTime)
		{	
			return ConvertToUTC(null, null, null, null, szServer, dDateTime);
		}

		public string ConvertToUTC(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer, 
			DateTime dDateTime)
		{
			CrystalDecisions.Enterprise.Utils.UTCConverter oUTCConverter;
			EnterpriseSession oEnterpriseSession = null;
			string szResult; 

			oEnterpriseSession = GetIdentity(szUserID, szPassword, szSystem, 
				szAuthentication, szServer);	

			oUTCConverter = new CrystalDecisions.Enterprise.Utils.UTCConverter();

			szResult = oUTCConverter.ConvertToUTC(dDateTime, oEnterpriseSession.TimeZone);

			return szResult;
		}

		#endregion



	}
}

