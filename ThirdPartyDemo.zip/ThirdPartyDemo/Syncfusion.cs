using System;
using System.Data; 
using Syncfusion.ExcelRW;

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for Syncfusion.
	/// </summary>
	public class Syncfusion
	{
		public void RunExcelDemo()
		{
			//Listing 12-1
			DataTable oDT;
			IWorkbook oWorkBook;
			IWorksheet oWS;
			int sRow = 1;

			//Create a workbook
			oWorkBook = ExcelUtils.CreateWorkbook(1);

			//Reference the first worksheet
			oWS = oWorkBook.Worksheets[0];

			//Set orientation and paper size
			oWS.PageSetup.Orientation = ExcelPageOrientation.Portrait;
			oWS.PageSetup.PaperSize = ExcelPaperSize.PaperLetter;

			//Set margins
			oWS.PageSetup.LeftMargin = 0.25;
			oWS.PageSetup.RightMargin = 0.25;
			oWS.PageSetup.TopMargin = 1.25;
			oWS.PageSetup.BottomMargin = 1.0;

			//Set the first row to print at the top of every page
			oWS.PageSetup.PrintTitleRows = "$A$1:$IV$1";

			//Set header and footer text
			oWS.PageSetup.LeftFooter = "Page &P of &N\n&D &T";
			oWS.PageSetup.CenterHeader = "Sample Report";

			//Set column widths
			oWS.SetColumnWidth(1, 20);
			oWS.SetColumnWidth(2, 10);

			//Listing 12-2
			//Set column headers
			oWS.Range[sRow, 1].Text = "Product";
			oWS.Range[sRow, 2].Text = "Sales";

			//Display headers in bold, centered, with a yellow background
			oWS.Range[sRow, 1, sRow, 2].CellStyle.FillBackground = 
				ExcelKnownColors.Yellow;
			oWS.Range[sRow, 1, sRow, 2].CellStyle.HorizontalAlignment = 
				ExcelHAlign.HAlignCenter;
			oWS.Range[sRow, 1, sRow, 2].CellStyle.Font.Bold = true;
			sRow++;

			//Get sample data, move through the results, and write data to cells
			oDT = GetData();

			foreach(DataRow oDR in oDT.Rows)
			{
				oWS.Range[sRow, 1].Text = oDR["Product"].ToString();
				oWS.Range[sRow, 2].Value = oDR["Sales"].ToString();

				sRow++;
			}

			sRow++;

			//Display total line via formula in bold
			oWS.Range[sRow, 1].Text = "Grand Total";
			oWS.Range[sRow, 2].Formula = "SUM(B2:B" + (sRow - 1).ToString() + ")";  
			oWS.Range[sRow, 1, sRow, 2].CellStyle.Font.Bold = true;

			//Format Sales column
			oWS.Range[2, 2, sRow, 2].NumberFormat = "0.00";

			oWorkBook.SaveAs(@"c:\temp\sample.xls");

			oWorkBook.Close();

			oDT.Dispose();

		}

		private DataTable GetData()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("Product"));
			oDT.Columns.Add(new DataColumn("Sales"));

			for (int x=1; x<=100; x++)
			{
				oDR = oDT.NewRow();

				oDR["Product"] = "Product" + x.ToString();
				oDR["Sales"] = 100 + x;

				oDT.Rows.Add(oDR);  
 
			}	

			return oDT;

		}
	}
}
