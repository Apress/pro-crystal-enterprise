using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for ThirdParty.
	/// </summary>
	public class frmThirdParty : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button cmdSyncFusion;
		private System.Windows.Forms.Button cmdSoftArtisansExcel;
		private System.Windows.Forms.Button cmdSoftArtisansWord;
		private System.Windows.Forms.Label label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmThirdParty()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		static void Main() 
		{
			Application.Run(new frmThirdParty());
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdSyncFusion = new System.Windows.Forms.Button();
			this.cmdSoftArtisansExcel = new System.Windows.Forms.Button();
			this.cmdSoftArtisansWord = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// cmdSyncFusion
			// 
			this.cmdSyncFusion.Location = new System.Drawing.Point(8, 80);
			this.cmdSyncFusion.Name = "cmdSyncFusion";
			this.cmdSyncFusion.Size = new System.Drawing.Size(216, 24);
			this.cmdSyncFusion.TabIndex = 58;
			this.cmdSyncFusion.Text = "SyncFusion";
			this.cmdSyncFusion.Click += new System.EventHandler(this.cmdSyncFusion_Click);
			// 
			// cmdSoftArtisansExcel
			// 
			this.cmdSoftArtisansExcel.Location = new System.Drawing.Point(8, 112);
			this.cmdSoftArtisansExcel.Name = "cmdSoftArtisansExcel";
			this.cmdSoftArtisansExcel.Size = new System.Drawing.Size(216, 24);
			this.cmdSoftArtisansExcel.TabIndex = 59;
			this.cmdSoftArtisansExcel.Text = "SoftArtisans OfficeWriter for Excel";
			this.cmdSoftArtisansExcel.Click += new System.EventHandler(this.cmdSoftArtisans_Click);
			// 
			// cmdSoftArtisansWord
			// 
			this.cmdSoftArtisansWord.Location = new System.Drawing.Point(8, 144);
			this.cmdSoftArtisansWord.Name = "cmdSoftArtisansWord";
			this.cmdSoftArtisansWord.Size = new System.Drawing.Size(216, 24);
			this.cmdSoftArtisansWord.TabIndex = 60;
			this.cmdSoftArtisansWord.Text = "SoftArtisans OfficeWriter for Word";
			this.cmdSoftArtisansWord.Click += new System.EventHandler(this.cmdSoftArtisansWord_Click);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(216, 64);
			this.label1.TabIndex = 61;
			this.label1.Text = "In order to run this demo you will need the demo version of full installation ver" +
				"sions of the SyncFusion and SoftArtisans products";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmThirdParty
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(232, 182);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.cmdSoftArtisansWord);
			this.Controls.Add(this.cmdSoftArtisansExcel);
			this.Controls.Add(this.cmdSyncFusion);
			this.Name = "frmThirdParty";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Third Party";
			this.Load += new System.EventHandler(this.frmThirdParty_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmThirdParty_Load(object sender, System.EventArgs e)
		{

		}


		private void cmdSyncFusion_Click(object sender, System.EventArgs e)
		{
			Syncfusion oSyncfusion;

			oSyncfusion = new Syncfusion();

			oSyncfusion.RunExcelDemo(); 

		}

		private void cmdSoftArtisans_Click(object sender, System.EventArgs e)
		{
			SoftArtisansExcelWriter oSoftArtisansExcelWriter;

			oSoftArtisansExcelWriter = new SoftArtisansExcelWriter();

			oSoftArtisansExcelWriter.RunDemo(); 
		}

		private void cmdSoftArtisansWord_Click(object sender, System.EventArgs e)
		{
			SoftArtisansWordWriter oSoftArtisansWordWriter;

			oSoftArtisansWordWriter = new SoftArtisansWordWriter();

			oSoftArtisansWordWriter.RunDemo(); 
		}
	}
}
