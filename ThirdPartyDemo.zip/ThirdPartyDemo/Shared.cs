using System;
using System.Windows.Forms;  
using System.Data; 

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for Shared.
	/// </summary>
	public class Shared
	{

		public static DataTable GetData()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("Product"));
			oDT.Columns.Add(new DataColumn("Sales"));

			for (int x=1; x<=100; x++)
			{
				oDR = oDT.NewRow();

				oDR["Product"] = "Product" + x.ToString();
				oDR["Sales"] = 100 + x;

				oDT.Rows.Add(oDR);  
 
			}	

			return oDT;

		}
	}
}
