using System;
using System.Data;
using SoftArtisans.OfficeWriter.WordWriter; 

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for SoftArtisansWordWriter.
	/// </summary>
	public class SoftArtisansWordWriter
	{
		//Listing 12-7
		public void RunDemo()
		{
			WordApplication oWordApplication;
			Document oDocument;
			Table oTable;
			TableCell oTableCell;
			Font oTotalFont;
			DataTable oDT;
			int sRow = 0;
			int iTotal = 0;

			oWordApplication = new WordApplication(); 

			oDocument = oWordApplication.Create();

			oDocument.InsertTextBefore("This is the payment report\n", true); 

			oDT = GetData();

			oTable = oDocument.InsertTableAfter(oDT.Rows.Count + 1, 2);   

			foreach(DataRow oDR in oDT.Rows)
			{
				oTableCell = oTable[sRow, 0];
				oTableCell.InsertTextAfter(oDR["Product"].ToString(), true);

				oTableCell = oTable[sRow, 1];
				oTableCell.InsertTextAfter(oDR["Sales"].ToString(), true);

				iTotal += int.Parse(oDR["Sales"].ToString());

				sRow++;
			}

			oTotalFont = oDocument.CreateFont(); 
			oTotalFont.Bold = true;

			oTableCell = oTable[sRow, 0];
			oTableCell.InsertTextAfter("Grand Total", oTotalFont);

			oTableCell = oTable[sRow, 1];
			oTableCell.InsertTextAfter(iTotal.ToString(), oTotalFont);

			oWordApplication.Save(oDocument, @"c:\temp\myreport.doc"); 

		}

		private DataTable GetData()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("Product"));
			oDT.Columns.Add(new DataColumn("Sales"));

			for (int x=1; x<=100; x++)
			{
				oDR = oDT.NewRow();

				oDR["Product"] = "Product" + x.ToString();
				oDR["Sales"] = 100 + x;

				oDT.Rows.Add(oDR);  
 
			}	

			return oDT;

		}

	}
}
