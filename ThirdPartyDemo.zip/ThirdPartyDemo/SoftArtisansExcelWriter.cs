using System;
using System.Data;
using SoftArtisans.OfficeWriter.ExcelWriter;

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for SoftArtisans.
	/// </summary>
	public class SoftArtisansExcelWriter
	{
		public void RunDemo()
		{
			//Listing 12-5
			ExcelApplication oExcelApplication;
			Workbook oWB;
			Worksheet oWS;
			GlobalStyle oGlobalStyle;
			Area oArea;
			DataTable oDT;
			int sRow = 0;

			//Create a workbook
			oExcelApplication = new ExcelApplication();
			oWB = oExcelApplication.Create();

			//Reference the first worksheet
			oWS = oWB.Worksheets[0];

			//Set orientation and paper size
			oWS.PageSetup.Orientation = PageSetup.PageOrientation.Portrait;
			oWS.PageSetup.PaperSize = PageSetup.PagePaperSize.Letter;

			//Set margins
			oWS.PageSetup.LeftMargin = 0.25;
			oWS.PageSetup.RightMargin = 0.25;
			oWS.PageSetup.TopMargin = 1.25;
			oWS.PageSetup.BottomMargin = 1.0;
			oWS.PageSetup.Zoom = 100;

			//Set the first row to print at the top of every page
			oWS.PageSetup.SetPrintTitleRows(0, 2); 

			//Set header and footer text
			oWS.PageSetup.LeftFooter = "Page &P of &N\n&D &T";
			oWS.PageSetup.CenterHeader = "Sample Report";

			//Set column widths
			oWS.GetColumnProperties(0).Width = 100; 
			oWS.GetColumnProperties(1).Width = 50;

			//Listing 12-6
			//Set column headers
			oWS.Cells[sRow, 0].Value = "Product";
			oWS.Cells[sRow, 1].Value = "Sales";

			//Display headers in bold, centered, with a yellow background
			oWS.Cells[sRow, 0].Style.BackgroundColor = Color.SystemColor.Yellow;
			oWS.Cells[sRow, 0].Style.HorizontalAlignment = Style.HAlign.Center;
			oWS.Cells[sRow, 0].Style.Font.Bold = true;

			oWS.Cells[sRow, 1].Style.BackgroundColor = Color.SystemColor.Yellow;
			oWS.Cells[sRow, 1].Style.HorizontalAlignment = Style.HAlign.Center;
			oWS.Cells[sRow, 1].Style.Font.Bold = true;
			sRow++;

			//Get sample data, move through the results, and write data to cells
			oDT = GetData();

			foreach(DataRow oDR in oDT.Rows)
			{
				oWS.Cells[sRow, 0].Value = oDR["Product"].ToString();
				oWS.Cells[sRow, 1].Value = int.Parse(oDR["Sales"].ToString());

				sRow++;
			}

			sRow++;

			//Display total line via formula in bold
			oWS.Cells[sRow, 0].Value = "Grand Total";
			oWS.Cells[sRow, 1].Formula = "=SUM(B2:B" + (sRow - 1).ToString() + ")";  
			oWS.Cells[sRow, 0].Style.Font.Bold = true;
			oWS.Cells[sRow, 1].Style.Font.Bold = true;

			//Format Sales column
			oGlobalStyle = oWB.CreateStyle();
			oGlobalStyle.NumberFormat = "0.00";

			oArea = oWS.CreateArea(1, 1, sRow, 1); 
			oArea.SetStyle(oGlobalStyle); 

			oExcelApplication.Save(oWB, @"c:\temp\sample.xls");

			oDT.Dispose();

		}


		private DataTable GetData()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("Product"));
			oDT.Columns.Add(new DataColumn("Sales"));

			for (int x=1; x<=100; x++)
			{
				oDR = oDT.NewRow();

				oDR["Product"] = "Product" + x.ToString();
				oDR["Sales"] = 100 + x;

				oDT.Rows.Add(oDR);  
 
			}	

			return oDT;

		}
	}
}
