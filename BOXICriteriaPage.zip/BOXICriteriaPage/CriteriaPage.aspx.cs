using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace BOXIDemo
{
	public enum Criteria
	{
		Departments = 0,
		Employee = 1,
		LastName = 2,
		FirstName = 3,
		BirthDate = 4,
		TradingDates = 5,
		Department = 6,
		PrintSummary = 7
	}	

	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		private System.ComponentModel.IContainer components;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.Button cmdGetData;

		private void Page_Load(object sender, System.EventArgs e)
		{

			DataTable oDT;

			if (!Page.IsPostBack)
			{ 			
				oDT = GetDepartments();
				ShowListBox(Criteria.Department, oDT, "DictionaryID", 
				"Description", 10, 20, 200, 180, "Departments");

				oDT = GetEmployees();
				ShowComboBox(Criteria.Employee, oDT, "DictionaryID", "Description", 250, 20, 200, 180, "Employees");	

				ShowTextBox(Criteria.LastName, 10, 270, 250, 20, "Last Name:");	

				cmdGetData.Attributes.Add("onclick", "return GetData()");  
			}

		}


		#region Common
		
		//Listing 9-29
		private Label AddDynamicLabel(Criteria iIndex, 
			int iLeft, 
			int iTop, 
			string szCaption)
		{
			Label oLabel;
			
			oLabel = new Label();

			oLabel.Style["position"] = "absolute";
			oLabel.Style["left"] = iLeft.ToString() + "px";
			oLabel.Style["top"] = iTop.ToString() + "px";
			oLabel.Text = szCaption;

			Panel1.Controls.Add(oLabel);

			return oLabel;
		}

		public static void LoadListBox(System.Web.UI.WebControls.ListBox oListBox,
			DataTable oDT,
			string szID,
			string szDescription,
			bool bSelectAll)
		{
			oListBox.Items.Clear();
			int x = 0;

			foreach (DataRow oDR in oDT.Rows)
			{
				oListBox.Items.Add(new ListItem(oDR[szDescription].ToString(), oDR[szID].ToString()));

				if (bSelectAll)
				{
					oListBox.Items[x].Selected = true; 
					x++;
				}
			}

		}


		public static void LoadComboBox(System.Web.UI.WebControls.DropDownList oComboBox,
			DataTable oDT,
			string szID,
			string szDescription)
		{
			oComboBox.Items.Clear();

			foreach (DataRow oDR in oDT.Rows)
				oComboBox.Items.Add(new ListItem(oDR[szDescription].ToString(), oDR[szID].ToString()));

		}

		#endregion

		#region ListBox

		//Listing 9-28
		private void ShowListBox(Criteria iIndex, 
			DataTable oDT, 
			string szID, 
			string szDescription, 
			int iLeft, 
			int iTop, 
			int iWidth, 
			int iHeight,
			string szCaption)
		{
			ListBoxManager oListBoxManager;

			oListBoxManager = new ListBoxManager();			

			oListBoxManager.Index = iIndex;
			oListBoxManager.LabelControl =  
				AddDynamicLabel(iIndex, iLeft, iTop, szCaption);

			oListBoxManager.ListBoxControl = 
				AddDynamicListBox(iIndex, iLeft, iTop + 20, iWidth, iHeight);
			
			oListBoxManager.ButtonControl = 
				AddDynamicListBoxButton(iIndex, iLeft, 
				iTop + iHeight + 20, iWidth, 23, szCaption);

			LoadListBox(oListBoxManager.ListBoxControl, oDT, 
				"DictionaryID", "Description", false);

		}

		//Listing 9-30
		private System.Web.UI.WebControls.ListBox AddDynamicListBox(Criteria iIndex, 
			int iLeft, 
			int iTop, 
			int iWidth, 
			int iHeight)
		{
			System.Web.UI.WebControls.ListBox oListBox;
			
			oListBox = new System.Web.UI.WebControls.ListBox();

			oListBox.ID = "ListBox" + ((int) iIndex);
			oListBox.Style["position"] = "absolute";
			oListBox.Style["left"] = iLeft.ToString() + "px";
			oListBox.Style["top"] = iTop.ToString() + "px";
			oListBox.Style["height"] = iHeight.ToString() + "px";
			oListBox.Style["width"] = iWidth.ToString() + "px";
			oListBox.BorderStyle = BorderStyle.Solid;
			oListBox.SelectionMode = ListSelectionMode.Multiple; 

			Panel1.Controls.Add(oListBox);

			return oListBox;
		}

		//Listing 9-31
		private Button AddDynamicListBoxButton(Criteria iIndex, 
			int iLeft, 
			int iTop, 
			int iWidth, 
			int iHeight, 
			string szCaption)
		{
			Button oButton;

			oButton = new Button();

			oButton.Style["position"] = "absolute";
			oButton.Style["left"] = iLeft.ToString() + "px";
			oButton.Style["top"] = iTop.ToString() + "px";
			oButton.Style["width"] = iWidth.ToString() + "px";
			oButton.Text = "Clear Selected " + szCaption;

			oButton.Attributes.Add("onclick", 
				"return DeselectAll('ListBox" + ((int) iIndex) + "')");

			Panel1.Controls.Add(oButton);

			return oButton;
		}

		#endregion

		#region ComboBox

		private void ShowComboBox(Criteria iIndex, DataTable oDT, string szID, string szDescription, int iLeft, int iTop, int iWidth, int iHeight, string szCaption)
		{
			ComboBoxManager oComboBoxManager;

			oComboBoxManager = new ComboBoxManager();			
		
			oComboBoxManager.Index = iIndex;
			oComboBoxManager.LabelControl =  AddDynamicLabel(iIndex, iLeft, iTop, szCaption);
			oComboBoxManager.ComboBoxControl = AddDynamicComboBox(iIndex, iLeft + 100, iTop, iWidth, iHeight);

			LoadComboBox(oComboBoxManager.ComboBoxControl, oDT, "DictionaryID", "Description");

		}

		private System.Web.UI.WebControls.DropDownList AddDynamicComboBox(Criteria iIndex, int iLeft, int iTop, int iWidth, int iHeight)
		{
			System.Web.UI.WebControls.DropDownList oComboBox;

			oComboBox = new System.Web.UI.WebControls.DropDownList();

			oComboBox.ID = "ComboBox" + + ((int) iIndex);
			oComboBox.Style["position"] = "absolute";
			oComboBox.Style["left"] = iLeft.ToString() + "px";
			oComboBox.Style["top"] = iTop.ToString() + "px";
			oComboBox.Style["height"] = iHeight.ToString() + "px";
			oComboBox.Style["width"] = iWidth.ToString() + "px";

			Panel1.Controls.Add(oComboBox);

			return oComboBox;
		}

		#endregion

		#region TextBox

		private void ShowTextBox(Criteria iIndex, int iLeft, int iTop, int iWidth, int iHeight, string szCaption)
		{
			TextBoxManager oTextBoxManager;

			oTextBoxManager = new TextBoxManager();			
		
			oTextBoxManager.Index = iIndex;
			oTextBoxManager.LabelControl =  AddDynamicLabel(iIndex, iLeft, iTop, szCaption);
			oTextBoxManager.TextBoxControl = AddDynamicTextBox(iIndex, iLeft + 100, iTop, iWidth, iHeight);

		}

		private System.Web.UI.WebControls.TextBox AddDynamicTextBox(Criteria iIndex, int iLeft, int iTop, int iWidth, int iHeight)
		{
			System.Web.UI.WebControls.TextBox oTextBox;

			oTextBox = new System.Web.UI.WebControls.TextBox();

			oTextBox.ID = "TextBox" + + ((int) iIndex);
			oTextBox.Style["position"] = "absolute";
			oTextBox.Style["left"] = iLeft.ToString() + "px";
			oTextBox.Style["top"] = iTop.ToString() + "px";
			oTextBox.Style["height"] = iHeight.ToString() + "px";
			oTextBox.Style["width"] = iWidth.ToString() + "px";

			Panel1.Controls.Add(oTextBox);

			return oTextBox;
		}

		#endregion

		#region SampleData

		private DataTable GetDepartments()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("DictionaryID"));   
			oDT.Columns.Add(new DataColumn("Description"));
			
			oDR = oDT.NewRow(); 
  
			oDR["DictionaryID"] = 51;
			oDR["Description"] = "Department A";
			
			oDT.Rows.Add(oDR);

			oDR = oDT.NewRow(); 

			oDR["DictionaryID"] = 52;
			oDR["Description"] = "Department B";

			oDT.Rows.Add(oDR); 

			oDR = oDT.NewRow(); 

			oDR["DictionaryID"] = 53;
			oDR["Description"] = "Department C";

			oDT.Rows.Add(oDR); 

			oDR = oDT.NewRow(); 

			oDR["DictionaryID"] = 54;
			oDR["Description"] = "Department D";

			oDT.Rows.Add(oDR); 

			oDR = oDT.NewRow(); 

			oDR["DictionaryID"] = 55;
			oDR["Description"] = "Department E";

			oDT.Rows.Add(oDR); 

			return oDT;
		}

		private DataTable GetEmployees()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("DictionaryID"));   
			oDT.Columns.Add(new DataColumn("Description"));
			
			oDR = oDT.NewRow(); 
  
			oDR["DictionaryID"] = 1;
			oDR["Description"] = "Flintstone, Fred";

			oDT.Rows.Add(oDR);

			oDR = oDT.NewRow(); 

			oDR["DictionaryID"] = 2;
			oDR["Description"] = "Bunny, Bugs";

			oDT.Rows.Add(oDR); 

			return oDT;
		}

		#endregion



		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	}

	//Listing 9-27
	class ControlManager
	{
		private Criteria iIndex;
		private Label oLabelControl;

		public Criteria Index
		{
			get { return iIndex; }
			set { iIndex = value; }
		}

		public Label LabelControl
		{
			get { return oLabelControl; }
			set { oLabelControl = value; }
		}
	}


	class ListBoxManager : ControlManager
	{
		private System.Web.UI.WebControls.ListBox oListBoxControl;
		private Button oButtonControl;

		public System.Web.UI.WebControls.ListBox ListBoxControl
		{
			get { return oListBoxControl; }
			set { oListBoxControl = value; }
		}

		public Button ButtonControl
		{
			get { return oButtonControl; }
			set { oButtonControl = value; }
		}
	}


	class ComboBoxManager : ControlManager
	{
		private System.Web.UI.WebControls.DropDownList oComboBoxControl;

		public System.Web.UI.WebControls.DropDownList ComboBoxControl
		{
			get { return oComboBoxControl; }
			set { oComboBoxControl = value; }
		}
	}

	class TextBoxManager : ControlManager
	{
		private System.Web.UI.WebControls.TextBox oTextBoxControl;

		public System.Web.UI.WebControls.TextBox TextBoxControl
		{
			get { return oTextBoxControl; }
			set { oTextBoxControl = value; }
		}
	}
}

