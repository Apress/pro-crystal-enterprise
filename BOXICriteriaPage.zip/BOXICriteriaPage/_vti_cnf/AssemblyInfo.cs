vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Oct 2006 00:40:30 -0000
vti_extenderversion:SR|4.0.2.8912
