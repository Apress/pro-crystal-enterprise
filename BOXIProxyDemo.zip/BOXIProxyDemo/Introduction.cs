using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml; 

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for Introduction.
	/// </summary>
	public class frmIntroduction : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button cmdUTCTime;
		private System.Windows.Forms.Button cmdLoadReport;
		private System.Windows.Forms.Button cmdDeleteFolder;
		private System.Windows.Forms.Button cmdCreateFolder;
		private System.Windows.Forms.Button cmdGetReportHistory;
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.Button cmdReports;
		private System.Windows.Forms.ListBox lstReports;
		private System.Windows.Forms.ListBox lstApplications;
		private System.Windows.Forms.Button cmdGetApplications;
		private System.Windows.Forms.Button cmdLoadProgram;
		private System.Windows.Forms.Button cmdSystemInfoProperty;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmIntroduction()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdUTCTime = new System.Windows.Forms.Button();
			this.cmdLoadReport = new System.Windows.Forms.Button();
			this.cmdDeleteFolder = new System.Windows.Forms.Button();
			this.cmdCreateFolder = new System.Windows.Forms.Button();
			this.cmdGetReportHistory = new System.Windows.Forms.Button();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.cmdReports = new System.Windows.Forms.Button();
			this.lstReports = new System.Windows.Forms.ListBox();
			this.lstApplications = new System.Windows.Forms.ListBox();
			this.cmdGetApplications = new System.Windows.Forms.Button();
			this.cmdLoadProgram = new System.Windows.Forms.Button();
			this.cmdSystemInfoProperty = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// cmdUTCTime
			// 
			this.cmdUTCTime.Location = new System.Drawing.Point(624, 136);
			this.cmdUTCTime.Name = "cmdUTCTime";
			this.cmdUTCTime.Size = new System.Drawing.Size(136, 24);
			this.cmdUTCTime.TabIndex = 36;
			this.cmdUTCTime.Text = "UTC Time";
			this.cmdUTCTime.Click += new System.EventHandler(this.cmdUTCTime_Click);
			// 
			// cmdLoadReport
			// 
			this.cmdLoadReport.Location = new System.Drawing.Point(624, 72);
			this.cmdLoadReport.Name = "cmdLoadReport";
			this.cmdLoadReport.Size = new System.Drawing.Size(136, 24);
			this.cmdLoadReport.TabIndex = 35;
			this.cmdLoadReport.Text = "Load Report";
			this.cmdLoadReport.Click += new System.EventHandler(this.cmdLoadReport_Click);
			// 
			// cmdDeleteFolder
			// 
			this.cmdDeleteFolder.Location = new System.Drawing.Point(624, 40);
			this.cmdDeleteFolder.Name = "cmdDeleteFolder";
			this.cmdDeleteFolder.Size = new System.Drawing.Size(136, 24);
			this.cmdDeleteFolder.TabIndex = 34;
			this.cmdDeleteFolder.Text = "Delete Folder";
			this.cmdDeleteFolder.Click += new System.EventHandler(this.cmdDeleteFolder_Click);
			// 
			// cmdCreateFolder
			// 
			this.cmdCreateFolder.Location = new System.Drawing.Point(624, 8);
			this.cmdCreateFolder.Name = "cmdCreateFolder";
			this.cmdCreateFolder.Size = new System.Drawing.Size(136, 24);
			this.cmdCreateFolder.TabIndex = 33;
			this.cmdCreateFolder.Text = "Create Folder";
			this.cmdCreateFolder.Click += new System.EventHandler(this.cmdCreateFolder_Click);
			// 
			// cmdGetReportHistory
			// 
			this.cmdGetReportHistory.Location = new System.Drawing.Point(8, 472);
			this.cmdGetReportHistory.Name = "cmdGetReportHistory";
			this.cmdGetReportHistory.Size = new System.Drawing.Size(752, 24);
			this.cmdGetReportHistory.TabIndex = 42;
			this.cmdGetReportHistory.Text = "Get Report History";
			this.cmdGetReportHistory.Click += new System.EventHandler(this.cmdGetReportHistory_Click);
			// 
			// dataGrid1
			// 
			this.dataGrid1.AlternatingBackColor = System.Drawing.Color.LightCyan;
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(8, 208);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(752, 256);
			this.dataGrid1.TabIndex = 41;
			// 
			// cmdReports
			// 
			this.cmdReports.Location = new System.Drawing.Point(200, 152);
			this.cmdReports.Name = "cmdReports";
			this.cmdReports.Size = new System.Drawing.Size(184, 24);
			this.cmdReports.TabIndex = 40;
			this.cmdReports.Text = "Get Reports";
			this.cmdReports.Click += new System.EventHandler(this.cmdReports_Click);
			// 
			// lstReports
			// 
			this.lstReports.Location = new System.Drawing.Point(200, 8);
			this.lstReports.Name = "lstReports";
			this.lstReports.Size = new System.Drawing.Size(184, 134);
			this.lstReports.TabIndex = 39;
			// 
			// lstApplications
			// 
			this.lstApplications.Location = new System.Drawing.Point(8, 8);
			this.lstApplications.Name = "lstApplications";
			this.lstApplications.Size = new System.Drawing.Size(184, 134);
			this.lstApplications.TabIndex = 38;
			// 
			// cmdGetApplications
			// 
			this.cmdGetApplications.Location = new System.Drawing.Point(8, 152);
			this.cmdGetApplications.Name = "cmdGetApplications";
			this.cmdGetApplications.Size = new System.Drawing.Size(184, 24);
			this.cmdGetApplications.TabIndex = 37;
			this.cmdGetApplications.Text = "Get Applications";
			this.cmdGetApplications.Click += new System.EventHandler(this.cmdGetApplications_Click);
			// 
			// cmdLoadProgram
			// 
			this.cmdLoadProgram.Location = new System.Drawing.Point(624, 104);
			this.cmdLoadProgram.Name = "cmdLoadProgram";
			this.cmdLoadProgram.Size = new System.Drawing.Size(136, 24);
			this.cmdLoadProgram.TabIndex = 43;
			this.cmdLoadProgram.Text = "Load Program";
			this.cmdLoadProgram.Click += new System.EventHandler(this.cmdLoadProgram_Click);
			// 
			// cmdSystemInfoProperty
			// 
			this.cmdSystemInfoProperty.Location = new System.Drawing.Point(624, 168);
			this.cmdSystemInfoProperty.Name = "cmdSystemInfoProperty";
			this.cmdSystemInfoProperty.Size = new System.Drawing.Size(136, 24);
			this.cmdSystemInfoProperty.TabIndex = 44;
			this.cmdSystemInfoProperty.Text = "System Info Property";
			this.cmdSystemInfoProperty.Click += new System.EventHandler(this.cmdSystemInfoProperty_Click);
			// 
			// frmIntroduction
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(768, 502);
			this.Controls.Add(this.cmdSystemInfoProperty);
			this.Controls.Add(this.cmdLoadProgram);
			this.Controls.Add(this.cmdGetReportHistory);
			this.Controls.Add(this.dataGrid1);
			this.Controls.Add(this.cmdReports);
			this.Controls.Add(this.lstReports);
			this.Controls.Add(this.lstApplications);
			this.Controls.Add(this.cmdGetApplications);
			this.Controls.Add(this.cmdUTCTime);
			this.Controls.Add(this.cmdLoadReport);
			this.Controls.Add(this.cmdDeleteFolder);
			this.Controls.Add(this.cmdCreateFolder);
			this.Name = "frmIntroduction";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Introduction";
			this.Load += new System.EventHandler(this.frmIntroduction_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void frmIntroduction_Load(object sender, System.EventArgs e)
		{

		}

		private void cmdReports_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataSet oDS;
			string szReport;
			ListItem oListItem;

			oListItem = ((ListItem) lstApplications.SelectedItem);  

			szReport = oListItem.Value;

			oBOXIWebService = new localhost.BOXIWebService();

			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;     

			//oDS = oBOXIWebService.GetReports("administrator", "snyc11d10041", "snyc11d10041", szReport);
			oDS = oBOXIWebService.GetReports("Dev", szReport);

			oBOXIWebService = null;

			Shared.LoadListBox(lstReports, oDS.Tables[0], "ID", "Name"); 				
		}

		private void cmdGetReportHistory_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService; 
			DataSet oDS;
			string szParentID;
			string szParentName;
			string szData;
			ListItem oListItem;

			oListItem = ((ListItem) lstApplications.SelectedItem);  

			szParentID = oListItem.Value;
			szParentName = oListItem.Text;

			oBOXIWebService = new localhost.BOXIWebService();

			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;     

			oDS = oBOXIWebService.GetReportHistory("Dev", szParentID);
	
//			szData = oBOXIWebService.GetReportTree("Dev", 
//				szParentID, 
//				szParentName, 
//				0, 
//				localhost.CEOptions.Both, 
//				true, 
//				true, 
//				true, 
//				true, 
//				true, 
//				true);
//
//			oBOXIWebService = null;
//
//			XmlDocument oXmlDocument;
//
//			oXmlDocument = new XmlDocument();
//
//			oXmlDocument.LoadXml(szData);
// 
//			oXmlDocument.Save(@"c:\temp\ce.xml"); 	

			dataGrid1.PreferredRowHeight = 35; 

			dataGrid1.DataSource = oDS.Tables[0];

		}

		private void cmdGetApplications_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataSet oDS;

			oBOXIWebService = new localhost.BOXIWebService();

			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;


			oDS = oBOXIWebService.GetApplications("Dev");

			oBOXIWebService = null;

			Shared.LoadListBox(lstApplications, oDS.Tables[0], "ID", "Name");
		
		}

		private void cmdCreateFolder_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			string szNewFolderID = oBOXIWebService.CreateFolder("Dev", "My New Test Folder", 0); 		
		}

		private void cmdDeleteFolder_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			string szFolder;
			ListItem oListItem;

			oListItem = ((ListItem) lstApplications.SelectedItem);  

			szFolder = oListItem.Value;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.DeleteFolder("Dev", int.Parse(szFolder)); 			
		}

		private void cmdLoadReport_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			string szReportID = oBOXIWebService.LoadReport("Dev", 1014, @"c:\temp\MailingLabels.rpt"); 	
		}

		private void cmdUTCTime_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DateTime dDateFrom;
			DateTime dDateTo;
			string szDateFrom;
			string szDateTo;
			string szSQL;

			dDateFrom = new DateTime(2006, 12, 1, 0, 0, 0);
			dDateTo = new DateTime(2006, 12, 1, 23, 59, 59);

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			szDateFrom = oBOXIWebService.ConvertToUTC("Dev", dDateFrom); 
			szDateTo = oBOXIWebService.ConvertToUTC("Dev", dDateTo); 

			szSQL = "SELECT SI_ID, SI_CREATION_TIME " +
				"FROM CI_INFOOBJECTS " +
				"WHERE SI_CREATION_TIME >= '" + szDateFrom + "' " +
				"AND SI_CREATION_TIME <= '" + szDateTo + "'";

			MessageBox.Show(szSQL); 

		}

		private void cmdLoadProgram_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			string szProgramID = oBOXIWebService.LoadProgram("Dev", 
															1014, 
															"Sample Application",
															@"C:\Inetpub\wwwroot\AppManager\AppManagerWinforms\bin\AppManager.exe", 
															@"C:\Inetpub\wwwroot\AppManager\AppManagerWinforms\bin\settings.xml",
															"Abc, 123", 
															"myuser", 
															"mypass"); 			
		}

		private void cmdSystemInfoProperty_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			string szSystemInfoProperty = oBOXIWebService.SystemInfoProperty("Dev"); 

			MessageBox.Show(szSystemInfoProperty); 
		}

	}
}
