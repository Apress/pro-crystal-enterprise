using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data; 
using System.Xml;

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for Enterprise.
	/// </summary>
	public class frmEnterprise : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button cmdAddProperty;
		private System.Windows.Forms.Button cmdCriteriaScreens;
		private System.Windows.Forms.Button cmdCEXMLSearch;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cmbFormat;
		private System.Windows.Forms.Button cmdOnDemandReport;
		private System.Windows.Forms.Button cmdBuildMenu;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem mnuFile;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem mnuDictionary;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmEnterprise()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdAddProperty = new System.Windows.Forms.Button();
			this.cmdCriteriaScreens = new System.Windows.Forms.Button();
			this.cmdCEXMLSearch = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.cmbFormat = new System.Windows.Forms.ComboBox();
			this.cmdOnDemandReport = new System.Windows.Forms.Button();
			this.cmdBuildMenu = new System.Windows.Forms.Button();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.mnuDictionary = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// cmdAddProperty
			// 
			this.cmdAddProperty.Location = new System.Drawing.Point(8, 56);
			this.cmdAddProperty.Name = "cmdAddProperty";
			this.cmdAddProperty.Size = new System.Drawing.Size(136, 24);
			this.cmdAddProperty.TabIndex = 47;
			this.cmdAddProperty.Text = "Add Property";
			this.cmdAddProperty.Click += new System.EventHandler(this.cmdAddProperty_Click);
			// 
			// cmdCriteriaScreens
			// 
			this.cmdCriteriaScreens.Location = new System.Drawing.Point(8, 120);
			this.cmdCriteriaScreens.Name = "cmdCriteriaScreens";
			this.cmdCriteriaScreens.Size = new System.Drawing.Size(136, 24);
			this.cmdCriteriaScreens.TabIndex = 46;
			this.cmdCriteriaScreens.Text = "Criteria Screens";
			this.cmdCriteriaScreens.Click += new System.EventHandler(this.cmdCriteriaScreens_Click);
			// 
			// cmdCEXMLSearch
			// 
			this.cmdCEXMLSearch.Location = new System.Drawing.Point(8, 88);
			this.cmdCEXMLSearch.Name = "cmdCEXMLSearch";
			this.cmdCEXMLSearch.Size = new System.Drawing.Size(136, 23);
			this.cmdCEXMLSearch.TabIndex = 45;
			this.cmdCEXMLSearch.Text = "CE XML Search";
			this.cmdCEXMLSearch.Click += new System.EventHandler(this.cmdCEXMLSearch_Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(176, 80);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(64, 20);
			this.label2.TabIndex = 44;
			this.label2.Text = "Format:";
			// 
			// cmbFormat
			// 
			this.cmbFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbFormat.Location = new System.Drawing.Point(240, 80);
			this.cmbFormat.Name = "cmbFormat";
			this.cmbFormat.Size = new System.Drawing.Size(136, 21);
			this.cmbFormat.TabIndex = 43;
			// 
			// cmdOnDemandReport
			// 
			this.cmdOnDemandReport.Location = new System.Drawing.Point(176, 104);
			this.cmdOnDemandReport.Name = "cmdOnDemandReport";
			this.cmdOnDemandReport.Size = new System.Drawing.Size(208, 24);
			this.cmdOnDemandReport.TabIndex = 40;
			this.cmdOnDemandReport.Text = "On Demand Report";
			this.cmdOnDemandReport.Click += new System.EventHandler(this.cmdOnDemandReport_Click);
			// 
			// cmdBuildMenu
			// 
			this.cmdBuildMenu.Location = new System.Drawing.Point(8, 8);
			this.cmdBuildMenu.Name = "cmdBuildMenu";
			this.cmdBuildMenu.Size = new System.Drawing.Size(136, 24);
			this.cmdBuildMenu.TabIndex = 48;
			this.cmdBuildMenu.Text = "Build Menu";
			this.cmdBuildMenu.Click += new System.EventHandler(this.cmdBuildMenu_Click);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuFile,
																					  this.mnuDictionary});
			// 
			// mnuFile
			// 
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.menuItem3,
																					this.menuItem4});
			this.mnuFile.Text = "File";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 0;
			this.menuItem3.Text = "Screen 1";
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 1;
			this.menuItem4.Text = "Screen 2";
			// 
			// mnuDictionary
			// 
			this.mnuDictionary.Index = 1;
			this.mnuDictionary.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						  this.menuItem5,
																						  this.menuItem6});
			this.mnuDictionary.Text = "Dictionary";
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 0;
			this.menuItem5.Text = "Dictionary 1";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 1;
			this.menuItem6.Text = "Dictionary 2";
			// 
			// frmEnterprise
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(400, 153);
			this.Controls.Add(this.cmdBuildMenu);
			this.Controls.Add(this.cmdAddProperty);
			this.Controls.Add(this.cmdCriteriaScreens);
			this.Controls.Add(this.cmdCEXMLSearch);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cmbFormat);
			this.Controls.Add(this.cmdOnDemandReport);
			this.Menu = this.mainMenu1;
			this.Name = "frmEnterprise";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Enterprise";
			this.Load += new System.EventHandler(this.frmEnterprise_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmEnterprise_Load(object sender, System.EventArgs e)
		{
			Shared.LoadFormats(cmbFormat);

		}

		private void cmdOnDemandReport_Click(object sender, System.EventArgs e)
		{
			//Listing 9-1	
			localhost.BOXIWebService oBOXIWebService;
			localhost.CeReportFormat CeReportFormat;
			localhost.CEResponse CEResponse;
			ListItem oListItem;
			string[] aParameters = new string[2];
			string szReport;
			string szFileName;
			int iUserID;

			this.Cursor = Cursors.WaitCursor; 


			//Set report parameter. One parameter for each array element in
			//the same ordinal position they are passed into the stored procedure
			aParameters[0] = "USA";
			aParameters[1] = "2";

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			//Format of report
			oListItem = ((ListItem) cmbFormat.SelectedItem);

			CeReportFormat = ((localhost.CeReportFormat) Int32.Parse(oListItem.Value)); 

			//What do we want back
			CEResponse = localhost.CEResponse.Base64EncodedString; 

			//Local disk file where report will be created
			szFileName = @"c:\temp\myreport" + 
				oBOXIWebService.GetExtension(CeReportFormat);

			//Some unique id for the currently logged in user
			iUserID = 0;

			oBOXIWebService.Timeout = 10000000;

			szReport = oBOXIWebService.RunReportOnDemand("Dev", 
				"Human Resources", 
				"Employee", 
				CeReportFormat, 
				0,
				aParameters,
				CEResponse);

			//Decode the string to a disk file
			Base64Decode(szReport, szFileName);

			this.Cursor = Cursors.Default;

			//Open the file based on the application assigned to its extension
			System.Diagnostics.Process.Start(szFileName);    

		}

		//Listing 9-3
		public static void Base64Decode(string szData, string szFileName)
		{
			byte[] aData;
			System.IO.FileStream oFileStream; 

			aData = System.Convert.FromBase64String(szData);

			oFileStream = new System.IO.FileStream(szFileName, 
				System.IO.FileMode.Create, System.IO.FileAccess.Write);
			oFileStream.Write(aData, 0, aData.Length - 1);
			oFileStream.Close();
		}

		private void cmdAddProperty_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			string szString = string.Empty;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			//			for (int x=1; x<=10000; x++)
			//				szString = szString + "1234567890\n";

			oBOXIWebService.AddProperty("Dev", "5920");
		}

		private void cmdBuildMenu_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService; 
			DataSet oDS;
			string szParentID;
			string szParentName;
			string szData;
			ListItem oListItem;

			//			oListItem = ((ListItem) lstApplications.SelectedItem);  
			//
			//			szParentID = oListItem.Value;
			//			szParentName = oListItem.Text;
			//
			//			oBOXIWebService = new localhost.BOXIWebService();
			//
			//			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;   

			//			szData = oBOXIWebService.GetReportTree("Dev", 
			//				szParentID, 
			//				szParentName, 
			//				0, 
			//				localhost.CEOptions.No, 
			//				false,
			//				false,
			//				false, 
			//				false, 
			//				false,
			//				false);

			XmlDocument oXmlDocument;

			oXmlDocument = new XmlDocument();

			//oXmlDocument.LoadXml(szData);

			oXmlDocument.Load(@"C:\DOCS\ProgrammingBOXI\BOXIProxyDemo\CE.xml");

			LoadMenus(oXmlDocument);

		}

		//Listing 9-45
		private void LoadMenus(XmlDocument oXmlDocument)
		{
			MenuItem oMenuItem;
			XmlNodeList oXmlNodeList;

			//We're not interested in the top-most node
			//so get the child nodes of that immediately
			oXmlNodeList = oXmlDocument.ChildNodes.Item(0).ChildNodes;

			//Create a main menu entry labeled Reports. All other
			//report menu entries will fall under this one
			oMenuItem = new MenuItem(); 
			oMenuItem.Text = "Reports";

			//begin loading the child menus
			LoadChildMenus(oXmlNodeList, oMenuItem);

			this.Menu.MenuItems.Add(oMenuItem);  
		}

		//Listing 9-46
		private void LoadChildMenus(XmlNodeList oXmlNodeList, MenuItem oOwnerMenuItem)
		{
			MenuItem oMenuItem = null;
			string szDescription;

			//Iterate through the nodes
			foreach (XmlNode oXmlNode in oXmlNodeList)
			{
				//Extract the name of the folder or report...
				szDescription = oXmlNode.Attributes.Item(0).Value;

				//...and add it to the menu with a default event handler
				oMenuItem = new MenuItem();
				oMenuItem.Text = szDescription;
				oMenuItem.Click += new System.EventHandler(this.oMainMenu_Click);

				//If we're dealing with a folder entry see if the are 
				//any child nodes and continue the recursion. Reports
				//won't have child entries
				if (oXmlNode.LocalName == "Folder")
				{
					oXmlNodeList = oXmlNode.ChildNodes; 
		        
					if (oXmlNodeList.Count != 0)
						LoadChildMenus(oXmlNodeList, oMenuItem);
				}

				//Add the menu item to the main menu
				oOwnerMenuItem.MenuItems.Add(oMenuItem); 
			}
		}

		//Listing 9-47
		private void oMainMenu_Click(object sender, System.EventArgs e)
		{
			MenuItem oMenuItem;

			oMenuItem = ((MenuItem) sender);

			MessageBox.Show(oMenuItem.Text);
		}

		//Listing 9-42
		private void cmdCEXMLSearch_Click(object sender, System.EventArgs e)
		{
			XmlDocument oXmlDocument;
			XmlNodeList oNodes;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load(@"c:\ganz\ce.xml"); 

			//Get everything under the folder node named 'Human Resources Reports'
			oNodes = oXmlDocument.
				SelectNodes("/MyReports//Folder[@SI_NAME='Human Resources Reports']/*");

			//Get everything under the report node named 'Hiring Report'
			oNodes = oXmlDocument.
				SelectNodes("/MyReports/Folder/Report[@SI_NAME='Hiring Report']/*");

			//Get the report nodes where the SI_OWNERID = 12
			oNodes = oXmlDocument.
				SelectNodes("/MyReports/Folder/Report[SI_OWNERID=12]");

			//Get the report nodes where the first prompt has a value of 'G320'
			oNodes = oXmlDocument.
				SelectNodes("/MyReports/Folder/Report/SI_PROMPTS[SI_VALUE1='G320']");

			//Get the SI_ID element where the 
			oNodes = oXmlDocument.
				SelectNodes("/MyReports/Folder[SI_OWNERID=12]/SI_ID");

			//Get all the folder nodes
			oNodes = oXmlDocument.
				SelectNodes("/MyReports/Folder");

			//get the first folder node
			oNodes = oXmlDocument.
				SelectNodes("/MyReports/Folder[1]");

		}

		private void cmdCriteriaScreens_Click(object sender, System.EventArgs e)
		{
			frmReportCriteria oReportCriteria;

			oReportCriteria = new frmReportCriteria();
			oReportCriteria.ReportName = "Personnel Report";
			oReportCriteria.Show(); 
		}

	}
}
