using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data; 

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for Scheduling.
	/// </summary>
	public class frmScheduling : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button cmdAssignEvent;
		private System.Windows.Forms.Button cmdReportFormats;
		private System.Windows.Forms.Button cmdDestinationDisk;
		private System.Windows.Forms.Button cmdDestinationSMTP;
		private System.Windows.Forms.Button cmdDestinationFTP;
		private System.Windows.Forms.Button cmdCreateAlerts;
		private System.Windows.Forms.Button cmdCreateCalendar;
		private System.Windows.Forms.Button cmdNotifications;
		private System.Windows.Forms.Button cmdTestDataAccess;
		private System.Windows.Forms.Button cmdCreateEvent;
		private System.Windows.Forms.Button cmdGetCategories;
		private System.Windows.Forms.Button cmdCreateCategory;
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.Button cmdMultipleFormats;
		private System.Windows.Forms.Button cmdScheduleDateRange;
		private System.Windows.Forms.Button cmdRetrieveSchedule;
		private System.Windows.Forms.Button cmdScheduleReport;
		private System.Windows.Forms.ComboBox cmbServer;
		private System.Windows.Forms.Button cmdRunNow;
		private System.Windows.Forms.Button cmdGetParameters;
		private System.Windows.Forms.Button cmdSetParameters;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmScheduling()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdAssignEvent = new System.Windows.Forms.Button();
			this.cmdReportFormats = new System.Windows.Forms.Button();
			this.cmdDestinationDisk = new System.Windows.Forms.Button();
			this.cmdDestinationSMTP = new System.Windows.Forms.Button();
			this.cmdDestinationFTP = new System.Windows.Forms.Button();
			this.cmdCreateAlerts = new System.Windows.Forms.Button();
			this.cmdCreateCalendar = new System.Windows.Forms.Button();
			this.cmdNotifications = new System.Windows.Forms.Button();
			this.cmdTestDataAccess = new System.Windows.Forms.Button();
			this.cmdCreateEvent = new System.Windows.Forms.Button();
			this.cmdGetCategories = new System.Windows.Forms.Button();
			this.cmdCreateCategory = new System.Windows.Forms.Button();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.cmdMultipleFormats = new System.Windows.Forms.Button();
			this.cmdScheduleDateRange = new System.Windows.Forms.Button();
			this.cmdRetrieveSchedule = new System.Windows.Forms.Button();
			this.cmdScheduleReport = new System.Windows.Forms.Button();
			this.cmbServer = new System.Windows.Forms.ComboBox();
			this.cmdRunNow = new System.Windows.Forms.Button();
			this.cmdGetParameters = new System.Windows.Forms.Button();
			this.cmdSetParameters = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// cmdAssignEvent
			// 
			this.cmdAssignEvent.Location = new System.Drawing.Point(8, 136);
			this.cmdAssignEvent.Name = "cmdAssignEvent";
			this.cmdAssignEvent.Size = new System.Drawing.Size(136, 24);
			this.cmdAssignEvent.TabIndex = 55;
			this.cmdAssignEvent.Text = "Assign Event";
			this.cmdAssignEvent.Click += new System.EventHandler(this.cmdAssignEvent_Click);
			// 
			// cmdReportFormats
			// 
			this.cmdReportFormats.Location = new System.Drawing.Point(8, 72);
			this.cmdReportFormats.Name = "cmdReportFormats";
			this.cmdReportFormats.Size = new System.Drawing.Size(136, 24);
			this.cmdReportFormats.TabIndex = 54;
			this.cmdReportFormats.Text = "Report Formats";
			this.cmdReportFormats.Click += new System.EventHandler(this.cmdReportFormats_Click);
			// 
			// cmdDestinationDisk
			// 
			this.cmdDestinationDisk.Location = new System.Drawing.Point(168, 136);
			this.cmdDestinationDisk.Name = "cmdDestinationDisk";
			this.cmdDestinationDisk.Size = new System.Drawing.Size(136, 24);
			this.cmdDestinationDisk.TabIndex = 53;
			this.cmdDestinationDisk.Text = "Destination Disk";
			this.cmdDestinationDisk.Click += new System.EventHandler(this.cmdDestinationDisk_Click);
			// 
			// cmdDestinationSMTP
			// 
			this.cmdDestinationSMTP.Location = new System.Drawing.Point(168, 104);
			this.cmdDestinationSMTP.Name = "cmdDestinationSMTP";
			this.cmdDestinationSMTP.Size = new System.Drawing.Size(136, 24);
			this.cmdDestinationSMTP.TabIndex = 52;
			this.cmdDestinationSMTP.Text = "Destination SMTP";
			this.cmdDestinationSMTP.Click += new System.EventHandler(this.cmdDestinationSMTP_Click);
			// 
			// cmdDestinationFTP
			// 
			this.cmdDestinationFTP.Location = new System.Drawing.Point(168, 72);
			this.cmdDestinationFTP.Name = "cmdDestinationFTP";
			this.cmdDestinationFTP.Size = new System.Drawing.Size(136, 24);
			this.cmdDestinationFTP.TabIndex = 51;
			this.cmdDestinationFTP.Text = "Destination FTP";
			this.cmdDestinationFTP.Click += new System.EventHandler(this.cmdDestinationFTP_Click);
			// 
			// cmdCreateAlerts
			// 
			this.cmdCreateAlerts.Location = new System.Drawing.Point(8, 40);
			this.cmdCreateAlerts.Name = "cmdCreateAlerts";
			this.cmdCreateAlerts.Size = new System.Drawing.Size(136, 24);
			this.cmdCreateAlerts.TabIndex = 50;
			this.cmdCreateAlerts.Text = "Create Alerts";
			this.cmdCreateAlerts.Click += new System.EventHandler(this.cmdCreateAlerts_Click);
			// 
			// cmdCreateCalendar
			// 
			this.cmdCreateCalendar.Location = new System.Drawing.Point(8, 8);
			this.cmdCreateCalendar.Name = "cmdCreateCalendar";
			this.cmdCreateCalendar.Size = new System.Drawing.Size(136, 24);
			this.cmdCreateCalendar.TabIndex = 49;
			this.cmdCreateCalendar.Text = "Create Calendar";
			this.cmdCreateCalendar.Click += new System.EventHandler(this.cmdCreateCalendar_Click);
			// 
			// cmdNotifications
			// 
			this.cmdNotifications.Location = new System.Drawing.Point(8, 200);
			this.cmdNotifications.Name = "cmdNotifications";
			this.cmdNotifications.Size = new System.Drawing.Size(136, 24);
			this.cmdNotifications.TabIndex = 48;
			this.cmdNotifications.Text = "Notifications";
			this.cmdNotifications.Click += new System.EventHandler(this.cmdNotifications_Click);
			// 
			// cmdTestDataAccess
			// 
			this.cmdTestDataAccess.Location = new System.Drawing.Point(8, 104);
			this.cmdTestDataAccess.Name = "cmdTestDataAccess";
			this.cmdTestDataAccess.Size = new System.Drawing.Size(136, 24);
			this.cmdTestDataAccess.TabIndex = 56;
			this.cmdTestDataAccess.Text = "Test Data Access";
			this.cmdTestDataAccess.Click += new System.EventHandler(this.cmdTestDataAccess_Click);
			// 
			// cmdCreateEvent
			// 
			this.cmdCreateEvent.Location = new System.Drawing.Point(8, 168);
			this.cmdCreateEvent.Name = "cmdCreateEvent";
			this.cmdCreateEvent.Size = new System.Drawing.Size(136, 24);
			this.cmdCreateEvent.TabIndex = 57;
			this.cmdCreateEvent.Text = "Create Event";
			this.cmdCreateEvent.Click += new System.EventHandler(this.cmdCreateEvent_Click);
			// 
			// cmdGetCategories
			// 
			this.cmdGetCategories.Location = new System.Drawing.Point(168, 168);
			this.cmdGetCategories.Name = "cmdGetCategories";
			this.cmdGetCategories.Size = new System.Drawing.Size(136, 24);
			this.cmdGetCategories.TabIndex = 59;
			this.cmdGetCategories.Text = "Get Categories";
			this.cmdGetCategories.Click += new System.EventHandler(this.cmdGetCategories_Click);
			// 
			// cmdCreateCategory
			// 
			this.cmdCreateCategory.Location = new System.Drawing.Point(168, 200);
			this.cmdCreateCategory.Name = "cmdCreateCategory";
			this.cmdCreateCategory.Size = new System.Drawing.Size(136, 24);
			this.cmdCreateCategory.TabIndex = 58;
			this.cmdCreateCategory.Text = "Create Category";
			this.cmdCreateCategory.Click += new System.EventHandler(this.cmdCreateCategory_Click);
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(320, 8);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(576, 368);
			this.dataGrid1.TabIndex = 60;
			// 
			// cmdMultipleFormats
			// 
			this.cmdMultipleFormats.Location = new System.Drawing.Point(8, 232);
			this.cmdMultipleFormats.Name = "cmdMultipleFormats";
			this.cmdMultipleFormats.Size = new System.Drawing.Size(136, 24);
			this.cmdMultipleFormats.TabIndex = 61;
			this.cmdMultipleFormats.Text = "Multiple Formats";
			this.cmdMultipleFormats.Click += new System.EventHandler(this.cmdMultipleFormats_Click);
			// 
			// cmdScheduleDateRange
			// 
			this.cmdScheduleDateRange.Location = new System.Drawing.Point(168, 8);
			this.cmdScheduleDateRange.Name = "cmdScheduleDateRange";
			this.cmdScheduleDateRange.Size = new System.Drawing.Size(136, 24);
			this.cmdScheduleDateRange.TabIndex = 62;
			this.cmdScheduleDateRange.Text = "Schedule Date Range";
			this.cmdScheduleDateRange.Click += new System.EventHandler(this.cmdScheduleDateRange_Click);
			// 
			// cmdRetrieveSchedule
			// 
			this.cmdRetrieveSchedule.Location = new System.Drawing.Point(168, 40);
			this.cmdRetrieveSchedule.Name = "cmdRetrieveSchedule";
			this.cmdRetrieveSchedule.Size = new System.Drawing.Size(136, 24);
			this.cmdRetrieveSchedule.TabIndex = 63;
			this.cmdRetrieveSchedule.Text = "Retrieve Schedule";
			this.cmdRetrieveSchedule.Click += new System.EventHandler(this.cmdRetrieveSchedule_Click);
			// 
			// cmdScheduleReport
			// 
			this.cmdScheduleReport.Location = new System.Drawing.Point(8, 352);
			this.cmdScheduleReport.Name = "cmdScheduleReport";
			this.cmdScheduleReport.Size = new System.Drawing.Size(128, 24);
			this.cmdScheduleReport.TabIndex = 66;
			this.cmdScheduleReport.Text = "Schedule Report";
			this.cmdScheduleReport.Click += new System.EventHandler(this.cmdScheduleReport_Click);
			// 
			// cmbServer
			// 
			this.cmbServer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbServer.Location = new System.Drawing.Point(8, 288);
			this.cmbServer.Name = "cmbServer";
			this.cmbServer.Size = new System.Drawing.Size(128, 21);
			this.cmbServer.TabIndex = 65;
			// 
			// cmdRunNow
			// 
			this.cmdRunNow.Location = new System.Drawing.Point(8, 312);
			this.cmdRunNow.Name = "cmdRunNow";
			this.cmdRunNow.Size = new System.Drawing.Size(128, 32);
			this.cmdRunNow.TabIndex = 64;
			this.cmdRunNow.Text = "Scheduled Reports - Run Now";
			this.cmdRunNow.Click += new System.EventHandler(this.cmdRunNow_Click);
			// 
			// cmdGetParameters
			// 
			this.cmdGetParameters.Location = new System.Drawing.Point(168, 288);
			this.cmdGetParameters.Name = "cmdGetParameters";
			this.cmdGetParameters.Size = new System.Drawing.Size(136, 24);
			this.cmdGetParameters.TabIndex = 67;
			this.cmdGetParameters.Text = "Get Parameters";
			this.cmdGetParameters.Click += new System.EventHandler(this.cmdGetParameters_Click);
			// 
			// cmdSetParameters
			// 
			this.cmdSetParameters.Location = new System.Drawing.Point(168, 320);
			this.cmdSetParameters.Name = "cmdSetParameters";
			this.cmdSetParameters.Size = new System.Drawing.Size(136, 24);
			this.cmdSetParameters.TabIndex = 68;
			this.cmdSetParameters.Text = "Set Parameters";
			this.cmdSetParameters.Click += new System.EventHandler(this.cmdSetParameters_Click);
			// 
			// frmScheduling
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(904, 382);
			this.Controls.Add(this.cmdSetParameters);
			this.Controls.Add(this.cmdGetParameters);
			this.Controls.Add(this.cmdScheduleReport);
			this.Controls.Add(this.cmbServer);
			this.Controls.Add(this.cmdRunNow);
			this.Controls.Add(this.cmdRetrieveSchedule);
			this.Controls.Add(this.cmdScheduleDateRange);
			this.Controls.Add(this.cmdMultipleFormats);
			this.Controls.Add(this.dataGrid1);
			this.Controls.Add(this.cmdGetCategories);
			this.Controls.Add(this.cmdCreateCategory);
			this.Controls.Add(this.cmdCreateEvent);
			this.Controls.Add(this.cmdTestDataAccess);
			this.Controls.Add(this.cmdAssignEvent);
			this.Controls.Add(this.cmdReportFormats);
			this.Controls.Add(this.cmdDestinationDisk);
			this.Controls.Add(this.cmdDestinationSMTP);
			this.Controls.Add(this.cmdDestinationFTP);
			this.Controls.Add(this.cmdCreateAlerts);
			this.Controls.Add(this.cmdCreateCalendar);
			this.Controls.Add(this.cmdNotifications);
			this.Name = "frmScheduling";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Scheduling";
			this.Load += new System.EventHandler(this.frmScheduling_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void cmdRunNow_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			string szFolderName = "Human Resources";
			string szReportName = "Employee Report";

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;
 
			oBOXIWebService.RunNow("Dev", szFolderName, szReportName);
		
		}

		private void cmdScheduleReport_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			string szFolderName = "Human Resources";
			string szReportName = "Employee Report";

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.ScheduleReport("Dev", szFolderName, szReportName);
		
		}

		private void cmdCreateAlerts_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.SetAlert("Dev", "3498");
		}

		private void cmdDestinationFTP_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.DestinationFtp("Dev", "4411");
		}

		private void cmdDestinationSMTP_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.DestinationSmtp("Dev", "4411");		
		}

		private void cmdDestinationDisk_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.DestinationDisk("Dev", "4411");			
		}

		private void cmdReportFormats_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.SetFormats("Dev", "1266");	
		}

		private void cmdCreateCalendar_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			try
			{
				oBOXIWebService.CreateCalendar("Dev", "Every Business Day");		
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);  
			}
		}

		private void cmdTestDataAccess_Click(object sender, System.EventArgs e)
		{
			DataAccess.DataAccess oDataAccess;
			DataTable oDT;

			oDataAccess = new DataAccess.DataAccess();

			//oDT = oDataAccess.GetEmployeesSQLServer("USA", 2); 

			oDT = oDataAccess.GetEmployeesOracle("CLERK");
   
		}

		private void cmdAssignEvent_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.AssignEvents("Dev", "1266", 1619); 	
		}

		private void cmdNotifications_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.SetNotifications("Dev", "3498");
	
		}

		private void cmdCreateEvent_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.CreateEvents("Dev"); 
		}

		private void cmdCreateCategory_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.CreatePersonalCategory("Dev", "MyPersonalCategory", 1043);
		}

		private void cmdGetCategories_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataTable oDT;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oDT = oBOXIWebService.GetCategories("Dev", "2159").Tables[0]; 

			dataGrid1.DataSource = oDT;		
		}

		private void cmdMultipleFormats_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.ExportMultipleFormats("Dev", "1266");	
		}

		//Listing 5-27
		private void cmdScheduleDateRange_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;
			

			string szServer = "Dev";
			string szReportID = "808";
			System.DateTime dTime = System.DateTime.Parse("1:00:00 PM");
			System.DateTime dStartDate = System.DateTime.Parse("6/1/2006");
			System.DateTime dEndDate = System.DateTime.Parse("12/31/2010");
			string szDays = "135";

			oBOXIWebService.SaveSchedule(szServer, szReportID, dTime, dStartDate, dEndDate, szDays);	
		}

		private void cmdRetrieveSchedule_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataTable oDT;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oDT = oBOXIWebService.GetSchedule("Dev", "1266").Tables[0]; 

			dataGrid1.DataSource = oDT;	
		}

		private void frmScheduling_Load(object sender, System.EventArgs e)
		{
			Shared.LoadServers(cmbServer);
		}

		private void cmdGetParameters_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataTable oDT;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oDT = oBOXIWebService.ExtractingPrompts("Dev", "808").Tables[0]; 

			dataGrid1.DataSource = oDT;	
		}

		private void cmdSetParameters_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.SavingPromptSettings("Dev", "808", "@Country", "GER"); 		
		}

	}
}
