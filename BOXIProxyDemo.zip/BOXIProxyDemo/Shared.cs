using System;
using System.Windows.Forms;  
using System.Data; 

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for Shared.
	/// </summary>
	public class Shared
	{

		public static DataTable GetData()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("Product"));
			oDT.Columns.Add(new DataColumn("Sales"));

			for (int x=1; x<=100; x++)
			{
				oDR = oDT.NewRow();

				oDR["Product"] = "Product" + x.ToString();
				oDR["Sales"] = 100 + x;

				oDT.Rows.Add(oDR);  
 
			}	

			return oDT;

		}

		public static void LoadListBox(ListBox oListBox, DataTable oDT, string szID, string szDescription)
		{
			oListBox.ValueMember = "Value";
			oListBox.DisplayMember = "Text";
			
			oListBox.Items.Clear();

			foreach (DataRow oDR in oDT.Rows)
				oListBox.Items.Add(new ListItem(oDR[szID].ToString(), oDR[szDescription].ToString()));	
		}

		public static void LoadServers(ComboBox oCombo)
		{
			oCombo.Items.Clear(); 

			oCombo.Items.Add("Dev");  
			oCombo.Items.Add("QA");
			oCombo.Items.Add("UAT");
			oCombo.Items.Add("PROD");

			oCombo.SelectedIndex = 0;
		}

		public static void LoadFormats(ComboBox oCombo)
		{
			string szData = string.Empty;

			szData = ((int) localhost.CeReportFormat.ceFormatExcel).ToString();
			
			oCombo.ValueMember = "Value";
			oCombo.DisplayMember = "Text";

			oCombo.Items.Clear(); 

			oCombo.Items.Add(new ListItem(((int) localhost.CeReportFormat.ceFormatExcel).ToString(), "Excel"));
			oCombo.Items.Add(new ListItem(((int) localhost.CeReportFormat.ceFormatPDF).ToString(), "PDF")); 
			oCombo.Items.Add(new ListItem(((int) localhost.CeReportFormat.ceFormatWord).ToString(), "Word")); 
			oCombo.Items.Add(new ListItem(((int) localhost.CeReportFormat.ceFormatTextCharacterSeparated).ToString(), "Text")); 

			oCombo.SelectedIndex = 0;

		}
	}

	public class ListItem
	{
		string mValue;
		string mText;
		string mOtherText;

		public ListItem(string szValue, string szText)
		{
			mValue = szValue;
			mText = szText;
		}

		public ListItem(string szValue, string szText, string szOtherText)
		{
			mValue = szValue;
			mText = szText;
			mOtherText = szOtherText;
		}

		public new string ToString()
		{
			return mText;
		}

		public string GetText()
		{
			return mText;
		}

		public string Value
		{
			get
			{
				return mValue;
			}
		}

		public string Text
		{
			get
			{
				return mText;
			}
		}

		public string OtherText
		{
			get
			{
				return mOtherText;
			}
		}

	}
}
