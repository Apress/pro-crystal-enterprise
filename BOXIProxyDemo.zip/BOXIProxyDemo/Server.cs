using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml; 
 
namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for Server.
	/// </summary>
	public class frmServer : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button cmdServerInformation;
		private System.Windows.Forms.Button cmdServerSummary;
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.Button cmdCreateServerGroup;
		private System.Windows.Forms.Button cmdAddServerToGroup;
		private System.Windows.Forms.Button cmdGetServersInGroup;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmServer()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdServerInformation = new System.Windows.Forms.Button();
			this.cmdServerSummary = new System.Windows.Forms.Button();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.cmdCreateServerGroup = new System.Windows.Forms.Button();
			this.cmdAddServerToGroup = new System.Windows.Forms.Button();
			this.cmdGetServersInGroup = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// cmdServerInformation
			// 
			this.cmdServerInformation.Location = new System.Drawing.Point(8, 40);
			this.cmdServerInformation.Name = "cmdServerInformation";
			this.cmdServerInformation.Size = new System.Drawing.Size(136, 24);
			this.cmdServerInformation.TabIndex = 60;
			this.cmdServerInformation.Text = "Server Information";
			this.cmdServerInformation.Click += new System.EventHandler(this.cmdServerInformation_Click);
			// 
			// cmdServerSummary
			// 
			this.cmdServerSummary.Location = new System.Drawing.Point(8, 8);
			this.cmdServerSummary.Name = "cmdServerSummary";
			this.cmdServerSummary.Size = new System.Drawing.Size(136, 24);
			this.cmdServerSummary.TabIndex = 59;
			this.cmdServerSummary.Text = "Server Summary";
			this.cmdServerSummary.Click += new System.EventHandler(this.cmdServerSummary_Click);
			// 
			// dataGrid1
			// 
			this.dataGrid1.AlternatingBackColor = System.Drawing.Color.Cyan;
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(8, 104);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(872, 368);
			this.dataGrid1.TabIndex = 62;
			// 
			// cmdCreateServerGroup
			// 
			this.cmdCreateServerGroup.Location = new System.Drawing.Point(200, 8);
			this.cmdCreateServerGroup.Name = "cmdCreateServerGroup";
			this.cmdCreateServerGroup.Size = new System.Drawing.Size(136, 24);
			this.cmdCreateServerGroup.TabIndex = 63;
			this.cmdCreateServerGroup.Text = "Create Server Group";
			this.cmdCreateServerGroup.Click += new System.EventHandler(this.cmdCreateServerGroup_Click);
			// 
			// cmdAddServerToGroup
			// 
			this.cmdAddServerToGroup.Location = new System.Drawing.Point(200, 40);
			this.cmdAddServerToGroup.Name = "cmdAddServerToGroup";
			this.cmdAddServerToGroup.Size = new System.Drawing.Size(136, 24);
			this.cmdAddServerToGroup.TabIndex = 64;
			this.cmdAddServerToGroup.Text = "Add Server To Group";
			this.cmdAddServerToGroup.Click += new System.EventHandler(this.cmdAddServerToGroup_Click);
			// 
			// cmdGetServersInGroup
			// 
			this.cmdGetServersInGroup.Location = new System.Drawing.Point(200, 72);
			this.cmdGetServersInGroup.Name = "cmdGetServersInGroup";
			this.cmdGetServersInGroup.Size = new System.Drawing.Size(136, 24);
			this.cmdGetServersInGroup.TabIndex = 65;
			this.cmdGetServersInGroup.Text = "Get Servers in Group";
			this.cmdGetServersInGroup.Click += new System.EventHandler(this.cmdGetServersInGroup_Click);
			// 
			// frmServer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(888, 478);
			this.Controls.Add(this.cmdGetServersInGroup);
			this.Controls.Add(this.cmdAddServerToGroup);
			this.Controls.Add(this.cmdCreateServerGroup);
			this.Controls.Add(this.dataGrid1);
			this.Controls.Add(this.cmdServerInformation);
			this.Controls.Add(this.cmdServerSummary);
			this.Name = "frmServer";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Server";
			this.Load += new System.EventHandler(this.frmServer_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void frmServer_Load(object sender, System.EventArgs e)
		{
		
		}


		private void cmdServerSummary_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataTable oDT;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oDT = oBOXIWebService.ServerSummary("Dev").Tables[0]; 

			dataGrid1.DataSource = oDT;
		}

		private void cmdServerInformation_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			XmlDocument oXmlDocument;
			string szData;

			this.Cursor = Cursors.WaitCursor; 

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			szData = oBOXIWebService.ServerInformation("Dev", "");

			oXmlDocument = new XmlDocument();
			oXmlDocument.LoadXml(szData);
			oXmlDocument.Save(Application.StartupPath + @"\CEServerInformation.xml"); 

			this.Cursor = Cursors.Default; 

			System.Diagnostics.Process.Start(Application.StartupPath + @"\CEServerInformation.xml");
		}


		private void cmdCreateServerGroup_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.CreateServerGroup("Dev", "Finance Reports Group");		
		}

		private void cmdAddServerToGroup_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.AddServerToGroup("Dev", 9592, "seton-notebook.pageserver.pageserver");	
		}

		private void cmdGetServersInGroup_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataTable oDT;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oDT = oBOXIWebService.GetServersInGroup("Dev", "9592").Tables[0];

			dataGrid1.DataSource = oDT;
		}

	}
}
