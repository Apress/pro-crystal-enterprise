using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using CrystalDecisions.Enterprise; 
using CrystalDecisions.CrystalReports; 
using CrystalDecisions.ReportAppServer.ClientDoc;
using CrystalDecisions.ReportAppServer.Controllers;
using CrystalDecisions.ReportAppServer.DataDefModel;
using CrystalDecisions.ReportAppServer.CommonObjectModel;
using CrystalDecisions.ReportAppServer.ObjectFactory;
using CrystalDecisions.ReportAppServer.ReportDefModel;
using CrystalDecisions.CrystalReports.TemplateEngine;

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for RAS.
	/// </summary>
	public class frmRAS : System.Windows.Forms.Form
	{
		private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
		private System.Windows.Forms.Button cmdRunReport;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmRAS()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			this.cmdRunReport = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// crystalReportViewer1
			// 
			this.crystalReportViewer1.ActiveViewIndex = -1;
			this.crystalReportViewer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.crystalReportViewer1.Location = new System.Drawing.Point(8, 8);
			this.crystalReportViewer1.Name = "crystalReportViewer1";
			this.crystalReportViewer1.Size = new System.Drawing.Size(1136, 648);
			this.crystalReportViewer1.TabIndex = 0;
			// 
			// cmdRunReport
			// 
			this.cmdRunReport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.cmdRunReport.Location = new System.Drawing.Point(1160, 8);
			this.cmdRunReport.Name = "cmdRunReport";
			this.cmdRunReport.Size = new System.Drawing.Size(56, 32);
			this.cmdRunReport.TabIndex = 1;
			this.cmdRunReport.Text = "Run Report";
			this.cmdRunReport.Click += new System.EventHandler(this.cmdRunReport_Click);
			// 
			// frmRAS
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1224, 662);
			this.Controls.Add(this.cmdRunReport);
			this.Controls.Add(this.crystalReportViewer1);
			this.Name = "frmRAS";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "RAS";
			this.Load += new System.EventHandler(this.frmRAS_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void cmdRunReport_Click(object sender, System.EventArgs e)
		{
			SessionMgr oSessionMgr;
			EnterpriseSession oEnterpriseSession;
			EnterpriseService oEnterpriseService;
			ReportAppFactory oReportAppFactory;
			ReportClientDocument oReportClientDocument;
			Section oSection;
			FontColor oCompanyHeaderFieldFont;
			FontColor oOrderHeaderTextFont;
			FontColor oOrderHeaderFieldFont;
			FontColor oDetailHeaderTextFont;
			FontColor oDetailHeaderFieldFont;
			object oTarget;


			//Listing 8-1
			oSessionMgr = new SessionMgr();
			oEnterpriseSession = oSessionMgr.Logon("Administrator", "Ovaltine", "SETON-NOTEBOOK:6400", "secEnterprise");
			oEnterpriseService = oEnterpriseSession.GetService("","RASReportFactory");
			oReportAppFactory = ((ReportAppFactory) oEnterpriseService.Interface);
			oReportClientDocument = oReportAppFactory.NewDocument(); 
 
			//Listing 8-23
			oCompanyHeaderFieldFont = CreateFont("Arial", 10, true, true, false, false, Color.Black);
			oOrderHeaderTextFont = CreateFont("Arial", 10, true, false, false, false, Color.Black);
			oOrderHeaderFieldFont = CreateFont("Arial", 10, false, false, false, false, Color.Black);
			oDetailHeaderTextFont = CreateFont("Arial", 10, false, true, false, false, Color.Black);
			oDetailHeaderFieldFont = CreateFont("Arial", 10, false, false, false, false, Color.Black);

			AddTable(oReportClientDocument, "(local)", "NorthWind", "SQLOLEDB", "crdb_ado.dll", 
				"OLE DB (ADO)", "sa", "Ovaltine", "spc_SalesOrders;1");

			AddGroup(oReportClientDocument, "spc_SalesOrders;1", "CompanyName");

			oSection = oReportClientDocument.ReportDefinition.PageHeaderArea.Sections[0]; 

			AddTextField(oReportClientDocument, oSection, "Page:", oOrderHeaderTextFont, CrAlignmentEnum.crAlignmentLeft, 6000, 0, 900, 250);
			AddSpecialField(oReportClientDocument, oSection, CrSpecialFieldTypeEnum.crSpecialFieldTypePageNumber, 7000, 0, 500, 250);

			oSection = oReportClientDocument.ReportDefinition.PageHeaderArea.Sections[0]; 

			AddLine(oReportClientDocument, oSection, Color.DarkSeaGreen, CrLineStyleEnum.crLineStyleSingle, 3, 10, 720, 720, 8000);

			
			//AddBox(oReportClientDocument, oSection, Color.Black, Color.Yellow, CrLineStyleEnum.crLineStyleSingle, 3, 9000, 720, 9500, 1100);


			oSection = oReportClientDocument.ReportDefinition.get_GroupHeaderArea(0).Sections[0]; 

			AddField(oReportClientDocument, oSection, oCompanyHeaderFieldFont, CrAlignmentEnum.crAlignmentLeft, "spc_SalesOrders;1", "CompanyName", 0, 0, 2880, 250);
			AddField(oReportClientDocument, oSection, oCompanyHeaderFieldFont, CrAlignmentEnum.crAlignmentLeft, "spc_SalesOrders;1", "City", 0, 275, 2880, 250);
			AddField(oReportClientDocument, oSection, oCompanyHeaderFieldFont, CrAlignmentEnum.crAlignmentLeft, "spc_SalesOrders;1", "Country", 3000, 275, 2880, 250);


			AddGroup(oReportClientDocument, "spc_SalesOrders;1", "OrderID");

			oSection = oReportClientDocument.ReportDefinition.get_GroupHeaderArea(1).Sections[0]; 
			
			AddTextField(oReportClientDocument, oSection, "Order #:", oOrderHeaderTextFont, CrAlignmentEnum.crAlignmentLeft, 0, 40, 770, 250);
			AddField(oReportClientDocument, oSection, oOrderHeaderFieldFont, CrAlignmentEnum.crAlignmentLeft, "spc_SalesOrders;1", "OrderID", 800, 40, 1000, 250);

			AddTextField(oReportClientDocument, oSection, "Order Date:", oOrderHeaderTextFont, CrAlignmentEnum.crAlignmentLeft, 2400, 40, 1440, 250);
			AddField(oReportClientDocument, oSection, oOrderHeaderFieldFont, CrAlignmentEnum.crAlignmentLeft, "spc_SalesOrders;1", "OrderDate", 4000, 40, 1200, 250);

			AddTextField(oReportClientDocument, oSection, "Products", oDetailHeaderTextFont, CrAlignmentEnum.crAlignmentLeft, 0, 300, 2880, 250);
			AddTextField(oReportClientDocument, oSection, "Unit Price", oDetailHeaderTextFont, CrAlignmentEnum.crAlignmentRight, 3000, 325, 1440, 250);
			AddTextField(oReportClientDocument, oSection, "Quantity", oDetailHeaderTextFont, CrAlignmentEnum.crAlignmentRight, 4500, 325, 1440, 250);
			AddTextField(oReportClientDocument, oSection, "Extended Price", oDetailHeaderTextFont, CrAlignmentEnum.crAlignmentRight, 6000, 325, 1440, 250);
			 
			oSection = oReportClientDocument.ReportDefinition.DetailArea.Sections[0];

			AddField(oReportClientDocument, oSection, oDetailHeaderFieldFont, CrAlignmentEnum.crAlignmentLeft, "spc_SalesOrders;1", "ProductName", 0, 0, 2880, 250);
			AddField(oReportClientDocument, oSection, oDetailHeaderFieldFont, CrAlignmentEnum.crAlignmentRight, "spc_SalesOrders;1", "UnitPrice", 3000, 0, 1440, 250);
			AddField(oReportClientDocument, oSection, oDetailHeaderFieldFont, CrAlignmentEnum.crAlignmentRight, "spc_SalesOrders;1", "Quantity", 4500, 0, 1440, 250);

			AddFormula(oReportClientDocument, "ExtendedPrice", "{spc_SalesOrders;1.Quantity} * {spc_SalesOrders;1.UnitPrice}");					
			AddFormulaField(oReportClientDocument, oSection, "ExtendedPriceSum", "ExtendedPrice", CrFieldValueTypeEnum.crFieldValueTypeNumberField, 6000, 0, 1440, 250);

	
			oSection = oReportClientDocument.ReportDefinition.get_GroupFooterArea(0).Sections[0];  

			SetSectionSettings(oReportClientDocument, oSection, Color.LightBlue, true, false, false, false, false, false, false, false);

			AddSummaryField(oReportClientDocument, oSection, string.Empty, "ExtendedPrice", CrSummaryOperationEnum.crSummaryOperationSum, 6000, 0, 1440, 250);


			//Listing 8-11
			ReportObjectController oReportObjectController;
			ReportObject oFieldReportObject = null;
			ReportObjects oReportObjects;
			FieldObject oFieldObject;
			FieldObject oFieldObjectTemp;
			string szFormula;

			oReportObjectController = oReportClientDocument.
				ReportDefController.ReportObjectController;

			oReportObjects = oReportObjectController.GetAllReportObjects();

			foreach (ReportObject oReportObject in oReportObjects)
			{
				string szName = oReportObject.Name;
				if (szName == "UnitPrice1")
				{
					oFieldReportObject = oReportObject;
					break;
				}
			}

			oFieldObject = ((FieldObject) oFieldReportObject);
			oFieldObjectTemp = ((FieldObject) oFieldObject.Clone(true)); 

			szFormula = "if {spc_SalesOrders;1.UnitPrice} > 30 then crGreen";

			oFieldObjectTemp.FontColor.
				ConditionFormulas[CrFontColorConditionFormulaTypeEnum.
				crFontColorConditionFormulaTypeColor].Text = szFormula;

			oReportObjectController.Modify(oFieldObject, oFieldObjectTemp); 





			
			PrintOptions oPrintOptions;

			oPrintOptions = oReportClientDocument.PrintOutputController.GetPrintOptions();



			//Listings 8-34 and 8-35
			SortController oSortController;
				
			oSortController = oReportClientDocument.DataDefController.SortController;

			oSortController.ModifySortDirection(0, 
				CrSortDirectionEnum.crSortDirectionAscendingOrder);

			oSortController.ModifySortDirection(1, 
				CrSortDirectionEnum.crSortDirectionDescendingOrder);




			//Listing 8-37
			DataDefinition oDataDefinition;

			oDataDefinition = 
				oReportClientDocument.DataDefController.DataDefinition;

			oSection = 
				oReportClientDocument.ReportDefinition.ReportFooterArea.Sections[0];  

			AddChart(oReportClientDocument, oSection, 
				oDataDefinition.Groups[0].ConditionField, 
				oDataDefinition.SummaryFields[0], 
				CrChartStyleTypeEnum.crChartStyleTypeBar, 
				"Sales Report", "(by Customer)", 
				"This footnote is cool, isn't it?", 5000, 100);


			crystalReportViewer1.ReportSource = oReportClientDocument;

			//Listing 8-45
//			object oFolderID;
//
//			oFolderID = 1233;
//
//			oReportClientDocument.SaveAs("Orders Report", ref oFolderID, 0);
//  
//			oTarget = @"c:\temp";

			//Listing 8-43
			//oReportClientDocument.SaveAs("myreport.rpt", ref oTarget, ((int) CdReportClientDocumentSaveAsOptionsEnum.cdReportClientDocumentSaveAsOverwriteExisting));
		}


		//Listing 8-2
		private void AddTable(ReportClientDocument oReportClientDocument,
			string szDataSource, 
			string szInitialCatalog, 
			string szProvider,
			string szDatabaseDLL,
			string szDatabaseType,
			string szUserName,
			string szPassword,
			string szTableName)
		{
			PropertyBag oLogonPropertyBag;
			PropertyBag oPropertyBag;
			ConnectionInfo oConnectionInfo;
			Table oTable;

			oLogonPropertyBag = new PropertyBagClass();
			oLogonPropertyBag["Data Source"] = szDataSource;
			oLogonPropertyBag["Initial Catalog"] = szInitialCatalog;
			oLogonPropertyBag["Provider"] = szProvider;

			oPropertyBag = new PropertyBagClass();
			oPropertyBag["Database DLL"] = szDatabaseDLL;
			oPropertyBag["QE_DatabaseType"] = szDatabaseType;
			oPropertyBag["QE_LogonProperties"] = oLogonPropertyBag;
			oPropertyBag["QE_SQLDB"] = "True";

			//Listing 8-3
			//oPropertyBag = new PropertyBagClass();
			//oPropertyBag["Database DLL"] = "crdb_odbc.dll";
			//oPropertyBag["QE_DatabaseType"] = "ODBC (RDO)";
			//oPropertyBag["QE_SQLDB"] = true;
			//oPropertyBag["Server Name"] = "NorthWind";
			//oConnectionInfo = new ConnectionInfoClass();
			//oConnectionInfo.Attributes = oPropertyBag;
			//oConnectionInfo.Kind = CrConnectionInfoKindEnum.crConnectionInfoKindSQL;
	
			oConnectionInfo = new ConnectionInfoClass();
			oConnectionInfo.Attributes = oPropertyBag;
			oConnectionInfo.UserName = szUserName;
			oConnectionInfo.Password = szPassword;
			oConnectionInfo.Kind = CrConnectionInfoKindEnum.crConnectionInfoKindCRQE;

			oTable = new CrystalDecisions.ReportAppServer.DataDefModel.TableClass();
			oTable.Name = szTableName;
			oTable.ConnectionInfo = oConnectionInfo;

			oReportClientDocument.DatabaseController.AddTable(oTable, null); 
		}

		//Listing 8-10
		private void AddFormula(ReportClientDocument oReportClientDocument, 
			string szName, 
			string szFormula)
		{
			FormulaField oFormulaField;

			oFormulaField = new FormulaField();

			oFormulaField.Name = szName;
			oFormulaField.Text = szFormula;			
			oFormulaField.Syntax = CrFormulaSyntaxEnum.crFormulaSyntaxCrystal;
			oFormulaField.Type = CrFieldValueTypeEnum.crFieldValueTypeStringField;

			oReportClientDocument.DataDefController.
				FormulaFieldController.Add(oFormulaField);
		}

		//Listing 8-12
		private void AddField(ReportClientDocument oReportClientDocument, 
			Section oSection, 
			FontColor oFontColor,
			CrAlignmentEnum sAlignmentEnum,
			string szTableName, 
			string szFieldName, 
			int iLeft,
			int iTop,
			int iWidth,
			int iHeight)
		{
			Table oTable;
			ISCRTable oISCRTable;
			FieldObject oFieldObject;			
			Field oField;

			//Find the table or stored procedure in the table collection based on the name
			oISCRTable = oReportClientDocument.Database.Tables.FindTableByAlias(szTableName);

			//Extract the table or stored procedure and cast it to a Table object
			oTable = ((Table) oISCRTable);

			//Cast this field reference to a Field object
			oField = ((Field) oTable.DataFields.FindField(szFieldName, 
				CrFieldDisplayNameTypeEnum.crFieldDisplayNameName, 
				CrystalDecisions.ReportAppServer.DataDefModel.CeLocale.ceLocaleUserDefault));
 
			//Instantiate a FieldObjectClass and set the properties 
			//and display the data and position on the page.
			oFieldObject = new FieldObjectClass();
			oFieldObject.Kind = CrReportObjectKindEnum.crReportObjectKindField;
			oFieldObject.FieldValueType = oField.Type;
			oFieldObject.DataSource = oField.FormulaForm;
			oFieldObject.Left = iLeft;
			oFieldObject.Top = iTop;
			oFieldObject.Width = iWidth;
			oFieldObject.Height = iHeight;
			oFieldObject.FontColor = oFontColor;
			oFieldObject.Format.HorizontalAlignment = sAlignmentEnum;

			if (szFieldName == "OrderID")
			{
				//Listing 8-18
				FieldFormat oFieldFormat;

				oFieldFormat = new FieldFormatClass();

				oFieldFormat.CommonFormat.EnableSystemDefault = false; 

				oFieldFormat.NumericFormat.ThousandsSeparator = false;
				oFieldFormat.NumericFormat.RoundingFormat = 0;
				oFieldFormat.NumericFormat.NDecimalPlaces = 0;

				oFieldObject.FieldFormat = oFieldFormat;	
			

				//Listing 8-26
				Border oBorder;

				oBorder = new BorderClass();
 
				oBorder.BorderColor = 
					uint.Parse(ColorTranslator.ToWin32(Color.DarkRed).ToString());
				oBorder.BackgroundColor = 
					uint.Parse(ColorTranslator.ToWin32(Color.LightGreen).ToString());
				oBorder.BottomLineStyle = CrLineStyleEnum.crLineStyleDashed; 
				oBorder.LeftLineStyle = CrLineStyleEnum.crLineStyleDotted;
				oBorder.RightLineStyle = CrLineStyleEnum.crLineStyleNoLine;
				oBorder.TopLineStyle = CrLineStyleEnum.crLineStyleSingle;

				oFieldObject.Border = oBorder;				
			}

			//Listing 8-20
			if (szFieldName == "OrderDate")
			{
				FieldFormat oFieldFormat;

				oFieldFormat = new FieldFormatClass();

				oFieldFormat.CommonFormat.EnableSystemDefault = false; 

				oFieldFormat.DateTimeFormat.DateTimeOrder = 
					CrDateTimeOrderEnum.crDateTimeOrderDateOnly; 
				oFieldFormat.DateFormat.DateOrder = 
					CrDateOrderEnum.crDateOrderMonthDayYear;
				oFieldFormat.DateFormat.DateFirstSeparator = "/";
				oFieldFormat.DateFormat.DateSecondSeparator = "/";
				oFieldFormat.DateFormat.MonthFormat = 
					CrMonthFormatEnum.crMonthFormatLeadingZeroNumericMonth;
				oFieldFormat.DateFormat.DayFormat = 
					CrDayFormatEnum.crDayFormatLeadingZeroNumericDay;
				oFieldFormat.DateFormat.YearFormat = 
					CrYearFormatEnum.crYearFormatLongYear; 

				oFieldObject.FieldFormat = oFieldFormat;	
			}

			//Listing 8-19
			if (szFieldName == "UnitPrice")
			{
				FieldFormat oFieldFormat;

				oFieldFormat = new FieldFormatClass();

				oFieldFormat.CommonFormat.EnableSystemDefault = false; 

				oFieldFormat.NumericFormat.OneCurrencySymbolPerPage = true;
				oFieldFormat.NumericFormat.CurrencySymbolFormat = 
					CrCurrencySymbolTypeEnum.crCurrencySymbolTypeFixedSymbol;
				oFieldFormat.NumericFormat.CurrencyPosition = 
					CrCurrencyPositionFormatEnum.
					crCurrencyPositionFormatLeadingCurrencyInsideNegative;
				oFieldFormat.NumericFormat.CurrencySymbol = "�";
				oFieldFormat.NumericFormat.NDecimalPlaces = 2;
				oFieldFormat.NumericFormat.DecimalSymbol = ".";		

				oFieldObject.FieldFormat = oFieldFormat;				
			}


			//Listing 8-21
			if (szFieldName == "CustomerName")
			{
				FieldFormat oFieldFormat;

				oFieldFormat = new FieldFormatClass();

				oFieldFormat.StringFormat.TextFormat = 
					CrTextFormatEnum.crTextFormatStandardText;
				oFieldFormat.StringFormat.EnableWordWrap = true;
				oFieldFormat.StringFormat.MaxNumberOfLines = 2;
			}

			//Add the group to the report
			oReportClientDocument.ReportDefController.ReportObjectController.Add(oFieldObject, oSection, 0);
		}


		//Listing 8-13
		private void AddTextField(ReportClientDocument oReportClientDocument, 
			Section oSection, 
			string szText, 
			FontColor oFontColor,
			CrAlignmentEnum sAlignmentEnum,
			int iLeft,
			int iTop,
			int iWidth,
			int iHeight)
		{
			TextObject oTextObject;
			Paragraphs oParagraphs;
			Paragraph oParagraph;
			ParagraphElements oParagraphElements;
			ParagraphTextElement oParagraphTextElement;

			//Instantiate the necessary objects
			oTextObject = new TextObject();
			oParagraphs = new Paragraphs();
			oParagraph = new Paragraph();
			oParagraphElements = new ParagraphElements();
			oParagraphTextElement = new ParagraphTextElement();

			//Set the displayed text to the ParagraphTextElement object
			oParagraphTextElement.Text = szText;
			oParagraphTextElement.Kind = 
				CrParagraphElementKindEnum.crParagraphElementKindText;

			//Add the ParagraphTextElement to the ParagraphTextElements collection
			oParagraphElements.Add(oParagraphTextElement);

			//set the ParagraphTextElements collection to the ParagraphElements 
			//property of the Paragraph object and set the text alignment
			oParagraph.ParagraphElements = oParagraphElements;
			oParagraph.Alignment = sAlignmentEnum; 

			//Add the Paragraph object to the Paragraphs collection
			oParagraphs.Add(oParagraph);

			//Set up the TextObject by assigning the Paragraphs collection object to
			//its Paragraphs property. Also, set the size and position.
			oTextObject.Kind = CrReportObjectKindEnum.crReportObjectKindText;
			oTextObject.Paragraphs = oParagraphs;			
			oTextObject.Left = iLeft;
			oTextObject.Top = iTop;
			oTextObject.Width = iWidth;
			oTextObject.Height = iHeight;
			oTextObject.FontColor = oFontColor;

			//Finally, add the TextObject to the report
			oReportClientDocument.ReportDefController.
				ReportObjectController.Add(oTextObject, oSection, -1);
		}


		//Listing 8-14
		private void AddSpecialField(ReportClientDocument oReportClientDocument, 
			Section oSection,
			CrSpecialFieldTypeEnum sSpecialFieldTypeEnum,  
			int iLeft,
			int iTop,
			int iWidth,
			int iHeight)
		{
			SpecialField oSpecialField;
			FieldObject oFieldObject;

			//Instantiate a SpecialField object
			oSpecialField = new SpecialField();

			//...and use the enumerator to indicate the type of special field
			oSpecialField.SpecialType = sSpecialFieldTypeEnum;

			//Ultimately you'll be displaying a field type 
			//that references the SpecialField object.
			oFieldObject = new FieldObject();

			oFieldObject.Kind = CrReportObjectKindEnum.crReportObjectKindText;
			oFieldObject.FieldValueType = oSpecialField.Type;
			oFieldObject.DataSource = oSpecialField.FormulaForm; 
			oFieldObject.Left = iLeft;
			oFieldObject.Top = iTop;
			oFieldObject.Width = iWidth;
			oFieldObject.Height = iHeight;

			//Finally, add the FieldObject to the report
			oReportClientDocument.ReportDefController.
				ReportObjectController.Add(oFieldObject, oSection, -1);
		}

		//Listing 8-16
		public void AddSummaryField(ReportClientDocument oReportClientDocument, 
			Section oSection,
			string szTableName, 
			string szFieldName,
			CrSummaryOperationEnum sSummaryOperationEnum,
			int iLeft,
			int iTop,
			int iWidth,
			int iHeight)
		{
			SummaryField oSummaryField;
			Table oTable;
			ISCRTable oISCRTable;
			FieldObject oFieldObject;			
			Field oField;
			ISCRField oISCRField;

			//if you pass a table prefix then you are summarizing a data field (like unit price)
			//otherwise assume you are summarizing a formula (like unit price * quantity)
			if (szTableName != string.Empty)
			{
				oISCRTable = oReportClientDocument.Database.Tables.FindTableByAlias(szTableName);
				oTable = ((Table) oISCRTable);

				oISCRField = oTable.DataFields.FindField(szFieldName, 
					CrFieldDisplayNameTypeEnum.crFieldDisplayNameName, 
					CrystalDecisions.ReportAppServer.DataDefModel.CeLocale.ceLocaleUserDefault);
				oField = ((Field) oISCRField);
			}
			else
			{
				oISCRField = oReportClientDocument.DataDefinition.FormulaFields.FindField(szFieldName, 
					CrFieldDisplayNameTypeEnum.crFieldDisplayNameName, 
					CrystalDecisions.ReportAppServer.DataDefModel.CeLocale.ceLocaleUserDefault);

				oField = ((Field) oISCRField);
			}

			oSummaryField = new SummaryFieldClass();
			oSummaryField.Group = oReportClientDocument.DataDefinition.Groups[0];  
			oSummaryField.SummarizedField = oField;
			oSummaryField.Operation = sSummaryOperationEnum;
			oSummaryField.Type = oField.Type;

			oFieldObject = new FieldObjectClass();
			oFieldObject.Kind = CrReportObjectKindEnum.crReportObjectKindField;
			oFieldObject.FieldValueType = oSummaryField.Type;
			oFieldObject.DataSource = oSummaryField.FormulaForm;
			oFieldObject.Left = iLeft;
			oFieldObject.Top = iTop;
			oFieldObject.Width = iWidth;
			oFieldObject.Height = iHeight;

			oReportClientDocument.ReportDefController.
				ReportObjectController.Add(oFieldObject, oSection, 1);   
		}


		//Listing 8-15
		private void AddFormulaField(ReportClientDocument oReportClientDocument, 
			Section oSection, 
			string szName,
			string szFieldName,
			CrFieldValueTypeEnum sFieldValueTypeEnum,
			int iLeft,
			int iTop,
			int iWidth,
			int iHeight)
		{
			FormulaField oFormulaField;
			Fields oFields;
			ISCRField oISCRField;
			FieldObject oFieldObject;

			oFormulaField = new FormulaFieldClass();

			oFields = oReportClientDocument.DataDefinition.FormulaFields;

			oISCRField = oFields.FindField(szFieldName, 
				CrFieldDisplayNameTypeEnum.crFieldDisplayNameName, 
				CrystalDecisions.ReportAppServer.DataDefModel.CeLocale.ceLocaleUserDefault);

			oFormulaField = ((FormulaField) oISCRField);
			oFormulaField.Type = sFieldValueTypeEnum;

			oFieldObject = new FieldObjectClass();
			oFieldObject.Kind = CrReportObjectKindEnum.crReportObjectKindField;
			oFieldObject.FieldValueType = oFormulaField.Type;
			oFieldObject.DataSource = oFormulaField.FormulaForm;
			oFieldObject.Left = iLeft;
			oFieldObject.Top = iTop;
			oFieldObject.Width = iWidth;
			oFieldObject.Height = iHeight;
			oFieldObject.Name = szName;

			oReportClientDocument.ReportDefController.
				ReportObjectController.Add(oFieldObject, oSection, 1);  
		}



		//Listing 8-5
		public void AddGroup(ReportClientDocument oReportClientDocument, 
			string szTableName, 
			string szFieldName)
		{
			Group oGroup;
			Table oTable;
			ISCRTable oISCRTable;
			Field oField;

			oGroup = new GroupClass(); 

			//Find the table or stored procedure in the table collection based on the name
			oISCRTable = oReportClientDocument.Database.Tables.FindTableByAlias(szTableName);

			//Extract the table or stored procedure and cast it to a Table object
			oTable = ((Table) oISCRTable);

			//Cast this field reference to a Field object
			oField = ((Field) oTable.DataFields.FindField(szFieldName, 
				CrFieldDisplayNameTypeEnum.crFieldDisplayNameName, 
				CrystalDecisions.ReportAppServer.DataDefModel.CeLocale.ceLocaleUserDefault));

			//Set the Field object as the group condition
			oGroup.ConditionField = oField;

			//Add the group to the report
			oReportClientDocument.DataDefController.GroupController.Add(-1, oGroup);  
		}


		public void AddFormulaGroup(ReportClientDocument oReportClientDocument, string szFormula)
		{
			Group oGroup;
			FormulaField oFormulaField;
			Fields oFields;
			int iIndex;

			oGroup = new GroupClass(); 

			oFormulaField = new FormulaFieldClass();

			oFields = oReportClientDocument.DataDefinition.FormulaFields;

			iIndex = oFields.Find(szFormula, CrFieldDisplayNameTypeEnum.crFieldDisplayNameName, CrystalDecisions.ReportAppServer.DataDefModel.CeLocale.ceLocaleUserDefault);

			oFormulaField = ((FormulaField) oFields[iIndex]);

			oGroup.ConditionField = oFormulaField;

			oReportClientDocument.DataDefController.GroupController.Add(-1, oGroup);
		}

		//Listing 8-38
		private void AddChart(ReportClientDocument oReportClientDocument,
			Section oSection,
			ISCRField oConditionField,
			ISCRField oDataField,
			CrChartStyleTypeEnum sChartStyleTypeEnum,
			string szTitle,
			string szSubTitle,
			string szFootnote,
			int iHeight,
			int iTop)
		{
			ChartDefinition oChartDefinition;
			ChartObject oChartObject;

			//Define a ChartDefinition class to hold the condition (x axis)
			//and data fields (y axis) for the chart.
			oChartDefinition = new ChartDefinitionClass();
			oChartDefinition.ChartType = CrChartTypeEnum.crChartTypeGroup;
			oChartDefinition.ConditionFields.Add(oConditionField);
			oChartDefinition.DataFields.Add(oDataField);

			//Instantiate the chart object and assign the data definitions established
			//in the ChartDefinition class. Indicate the type of chart to display.
			oChartObject = new ChartObjectClass();
			oChartObject.ChartDefinition = oChartDefinition;
			oChartObject.ChartStyle.Type = sChartStyleTypeEnum;
			oChartObject.ChartStyle.TextOptions.Title = szTitle;
			oChartObject.ChartStyle.TextOptions.Subtitle = szSubTitle;
			oChartObject.ChartStyle.TextOptions.Footnote = szFootnote; 
			oChartObject.Height = iHeight;
			oChartObject.Width = oSection.Width;
			oChartObject.Top = iTop;

			//Add the chart object to the desired section of the report. 
			//In this case the report footer.
			oReportClientDocument.ReportDefController.
				ReportObjectController.Add(oChartObject, oSection, 0);
		}

		//Listing 8-4
		public void AddTableLink(ReportClientDocument oReportClientDocument, 
			string szSourceField, 
			string szTargetField, 
			string szSourceTable, 
			string szTargetTable)
		{
			TableLink oTableLink;

			oTableLink = new TableLinkClass();

			oTableLink.JoinType = CrTableJoinTypeEnum.crTableJoinTypeEqualJoin;

			oTableLink.SourceFieldNames.Add(szSourceField);  
			oTableLink.TargetFieldNames.Add(szTargetField);

			oTableLink.SourceTableAlias = szSourceTable; 
			oTableLink.TargetTableAlias = szTargetTable;

			oReportClientDocument.DatabaseController.AddTableLink(oTableLink);  
		}

		//Listing 8-8
		private void SetSectionSettings(ReportClientDocument oReportClientDocument, 
			Section oSection,
			Color oBackgroundColor,
			bool bEnableKeepTogether,
			bool bEnableNewPageAfter,
			bool bEnableNewPageBefore, 
			bool bEnablePrintAtBottomOfPage,
			bool bEnableResetPageNumberAfter,
			bool bEnableSuppress,
			bool bEnableSuppressIfBlank,
			bool bEnableUnderlaySection)
		{
			SectionFormat oSectionFormat;
			ReportSectionController oReportSectionController;

			oSectionFormat = new SectionFormat();
			oSectionFormat.EnableKeepTogether = bEnableKeepTogether;
			oSectionFormat.EnableNewPageAfter = bEnableNewPageAfter;
			oSectionFormat.EnableNewPageBefore = bEnableNewPageBefore;
			oSectionFormat.EnablePrintAtBottomOfPage = bEnablePrintAtBottomOfPage;
			oSectionFormat.EnableResetPageNumberAfter = bEnableResetPageNumberAfter;
			oSectionFormat.EnableSuppress = bEnableSuppress;
			oSectionFormat.EnableSuppressIfBlank = bEnableSuppressIfBlank;
			oSectionFormat.EnableUnderlaySection = bEnableUnderlaySection;
			oSectionFormat.BackgroundColor = 
				uint.Parse(ColorTranslator.ToWin32(oBackgroundColor).ToString());

			oReportSectionController = 
				oReportClientDocument.ReportDefController.ReportSectionController;

			oReportSectionController.SetProperty(oSection, 
				CrReportSectionPropertyEnum.crReportSectionPropertyFormat, oSectionFormat);
		}


		//Listing 8-24
		public void AddLine(ReportClientDocument oReportClientDocument, 
			Section oSection,
			Color oLineColor,
			CrLineStyleEnum sLineStyleEnum,
			int iLineThickness, 
			int iLeft,
			int iTop,
			int iBottom,
			int iRight)

		{
			LineObject oLineObject;

			oLineObject = new LineObject();

			oLineObject.Top = iTop;
			oLineObject.Bottom = iBottom; 

			oLineObject.Left = iLeft;
			oLineObject.Right = iRight;
			oLineObject.LineThickness = iLineThickness;
			oLineObject.LineStyle = sLineStyleEnum;
			oLineObject.EndSectionName = oSection.Name;
			oLineObject.LineColor = 
				uint.Parse(ColorTranslator.ToWin32(oLineColor).ToString());

			oReportClientDocument.ReportDefController.
				ReportObjectController.Add(oLineObject, oSection, -1);

		}

		//Listing 8-25
		public void AddBox(ReportClientDocument oReportClientDocument, 
			Section oSection,
			Color oLineColor,
			Color oFillColor,
			CrLineStyleEnum sLineStyleEnum,
			int iLineThickness, 
			int iLeft,
			int iTop,
			int iRight,
			int iBottom)

		{
			BoxObject oBoxObject;

			oBoxObject = new BoxObject();

			oBoxObject.Top = iTop;
			oBoxObject.Bottom = iBottom;
			oBoxObject.Left = iLeft;
			oBoxObject.Right = iRight;
			oBoxObject.LineThickness = iLineThickness;
			oBoxObject.LineStyle = sLineStyleEnum;
			oBoxObject.EndSectionName = oSection.Name;
			oBoxObject.LineColor = 
				uint.Parse(ColorTranslator.ToWin32(oLineColor).ToString());
			oBoxObject.FillColor = 
				uint.Parse(ColorTranslator.ToWin32(oFillColor).ToString());

			oReportClientDocument.ReportDefController.
				ReportObjectController.Add(oBoxObject, oSection, -1);

		}


		//Listing 8-22
		public FontColor CreateFont(string szFontName, 
			decimal iSize, 
			bool bBold, 
			bool bItalic,
			bool bStrikethrough,
			bool bUnderline,
			Color oColor)
		{
			CrystalDecisions.ReportAppServer.ReportDefModel.Font oFont;
			FontColor oFontColor;

			oFont = new FontClass();
			oFont.Name = szFontName;
			oFont.Size = iSize;
			oFont.Bold = bBold;
			oFont.Italic = bItalic;
			oFont.Strikethrough = bStrikethrough;
			oFont.Underline = bUnderline;

			oFontColor = new FontColor();
			oFontColor.Font = oFont;
			oFontColor.Color = uint.Parse(ColorTranslator.ToWin32(oColor).ToString());  

			return oFontColor;
		}

		private DataTable GetData()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("Product"));
			oDT.Columns.Add(new DataColumn("Sales"));

			for (int x=1; x<=100; x++)
			{
				oDR = oDT.NewRow();

				oDR["Product"] = "Product" + x.ToString();
				oDR["Sales"] = 100 + x;

				oDT.Rows.Add(oDR);  
 
			}	

			return oDT;

		}

		private void frmRAS_Load(object sender, System.EventArgs e)
		{
		
		}
	}
}