using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace BOXIProxyDemo
{

	public enum Criteria
	{
		Departments = 0,
		Employee = 1,
		LastName = 2,
		FirstName = 3,
		BirthDate = 4,
		TradingDates = 5,
		Department = 6,
		PrintSummary = 7
	}	

	/// <summary>
	/// Summary description for ReportCriteria.
	/// </summary>
	public class frmReportCriteria : System.Windows.Forms.Form
	{

		ArrayList aControlList = new ArrayList();
																																																																																													 int sReportCode;
		string szReportName;

		public string ReportName
		{
			get { return szReportName; }
			set { szReportName = value; }
		}		

		private System.Windows.Forms.Button cmdGetCriteria;	

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmReportCriteria()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdGetCriteria = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// cmdGetCriteria
			// 
			this.cmdGetCriteria.Location = new System.Drawing.Point(248, 480);
			this.cmdGetCriteria.Name = "cmdGetCriteria";
			this.cmdGetCriteria.TabIndex = 0;
			this.cmdGetCriteria.Text = "Get Criteria";
			this.cmdGetCriteria.Click += new System.EventHandler(this.cmdGetCriteria_Click);
			// 
			// frmReportCriteria
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(584, 510);
			this.Controls.Add(this.cmdGetCriteria);
			this.Name = "frmReportCriteria";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "ReportCriteria";
			this.Load += new System.EventHandler(this.ReportCriteria_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void ReportCriteria_Load(object sender, System.EventArgs e)
		{
			DataTable oDT;

			this.Text = szReportName;
			
			oDT = GetDepartments();
			ShowListBox(Criteria.Departments, oDT, "DictionaryID", "Description", 10, 20, 200, 180, "Departments");

			oDT = GetEmployees();
			ShowListBox(Criteria.Employee, oDT, "DictionaryID", "Description", 230, 20, 200, 180, "Employees");

			ShowTextBox(Criteria.LastName, 20, 300, 450, 25, "Last Name:");
			ShowTextBox(Criteria.FirstName, 20, 330, 450, 25, "First Name:");

			ShowDate(Criteria.BirthDate, 20, 360, 25, "Birth Date:");

			ShowDateRange(Criteria.TradingDates, 20, 390, 25, "Trading Date:");

			oDT = GetDepartments();
			ShowComboBox(Criteria.Department, oDT, "DictionaryID", 
				"Description", 20, 420, 125, 25, "Department:");
		
			ShowCheckBox(Criteria.PrintSummary, 20, 450, 125, 25, "Print Summary");

		}

		private void ComboBox_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			
			ComboBoxManager oComboBoxManager = null;
			ListBoxManager oListBoxManager = null;
			ComboBox oComboBox;
			ListBox oListBox;
			DataTable oDT;
			ListItem oListItem;
			string szData = string.Empty;

			//Walk through each control set
			foreach(object oSourceItem in aControlList)
			{ 
				//If we find a combo box let's see if 
				//its really the one we want
				if (oSourceItem is ComboBoxManager)
				{
					//Cast to a ComboBoxManager
					oComboBoxManager = ((ComboBoxManager) oSourceItem);

					//Is it the combo box collection we want?
					if (oComboBoxManager.Index == Criteria.Department) 
					{
						//If so, extract the combo box control
						oComboBox = ((ComboBox) oComboBoxManager.ComboBoxControl);

						//Get the ListItem object...
						oListItem = ((ListItem) oComboBox.SelectedItem);

						//...and retrieve the unique key for the department
						szData = oListItem.Value; 

						//Loop through the control set again
						foreach(object oTargetItem in aControlList)
						{ 
							//If this is a list box collection
							if (oTargetItem is ListBoxManager)
							{
								//Cast to a ListBoxManager
								oListBoxManager = ((ListBoxManager) oTargetItem);

								//Is it the list box collection we want?
								if (oListBoxManager.Index == Criteria.Employee) 
								{
									//If so, extract the list box control and populate 
									//with the employees belonging to the selected department
									oListBox = ((ListBox) oListBoxManager.ListBoxControl);

									oDT = GetDeptEmployees(szData);

									LoadCheckedListBox(oListBoxManager.ListBoxControl, oDT, 
										"DictionaryID", "Description", false);

									break;
								}
							}
						}

						break;
					}
				}

			}
		
		}

		private DataTable GetEmployees()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("DictionaryID"));   
			oDT.Columns.Add(new DataColumn("Description"));
			
			oDR = oDT.NewRow(); 
  
			oDR["DictionaryID"] = 1;
			oDR["Description"] = "Flintstone, Fred";

			oDT.Rows.Add(oDR);

			oDR = oDT.NewRow(); 

			oDR["DictionaryID"] = 2;
			oDR["Description"] = "Bunny, Bugs";

			oDT.Rows.Add(oDR); 

			return oDT;
		}

		private DataTable GetDepartments()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("DictionaryID"));   
			oDT.Columns.Add(new DataColumn("Description"));
			
			oDR = oDT.NewRow(); 
  
			oDR["DictionaryID"] = 1;
			oDR["Description"] = "Department A";
			
			oDT.Rows.Add(oDR);

			oDR = oDT.NewRow(); 

			oDR["DictionaryID"] = 2;
			oDR["Description"] = "Department B";

			oDT.Rows.Add(oDR); 

			return oDT;
		}

		private DataTable GetDeptEmployees(string szDeptID)
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("DictionaryID"));   
			oDT.Columns.Add(new DataColumn("Description"));
			

			if (szDeptID == "1")
			{
				oDR = oDT.NewRow(); 

				oDR["DictionaryID"] = 1;
				oDR["Description"] = "Flintstone, Fred";

				oDT.Rows.Add(oDR);

				oDR = oDT.NewRow(); 

				oDR["DictionaryID"] = 2;
				oDR["Description"] = "Rubble, Barney";

				oDT.Rows.Add(oDR); 
			}
			else
			{
				oDR = oDT.NewRow(); 

				oDR["DictionaryID"] = 3;
				oDR["Description"] = "Jetson, George";

				oDT.Rows.Add(oDR);

				oDR = oDT.NewRow(); 

				oDR["DictionaryID"] = 4;
				oDR["Description"] = "Bunny, Bugs";

				oDT.Rows.Add(oDR); 
			}

			return oDT;
		}

		//Listing 9-15
		private void ShowListBox(Criteria iIndex, 
			DataTable oDT, 
			string szID, 
			string szDescription, 
			int iLeft, 
			int iTop, 
			int iWidth, 
			int iHeight, 
			string szCaption)
		{
			ListBoxManager oListBoxManager;

			oListBoxManager = new ListBoxManager();

			oListBoxManager.Index = iIndex;
			oListBoxManager.LabelControl =  AddDynamicLabel(iIndex, iLeft, iTop, szCaption);

			iTop = oListBoxManager.LabelControl.Top + 
				oListBoxManager.LabelControl.Height + 5;

			oListBoxManager.ListBoxControl = 
				AddDynamicListBox(iIndex, iLeft, iTop, iWidth, iHeight);

			iTop = oListBoxManager.ListBoxControl.Top + 
				oListBoxManager.ListBoxControl.Height + 5;
			
			oListBoxManager.ButtonControl = 
				AddDynamicListBoxButton(iIndex, iLeft, iTop, iWidth, 23, szCaption);

			LoadCheckedListBox(oListBoxManager.ListBoxControl, 
				oDT, "DictionaryID", "Description", false);

			aControlList.Add(oListBoxManager);
		}

		//Listing 9-16
		private Label AddDynamicLabel(Criteria iIndex, 
			int iLeft, 
			int iTop, 
			string szCaption)
		{
			Label oLabel;
			
			oLabel = new Label();

			oLabel.AutoSize = true;
			oLabel.Name = "Label" + iIndex.ToString();
			oLabel.Location = new Point(iLeft, iTop);
			oLabel.Text = szCaption;

			this.Controls.Add(oLabel);

			return oLabel;
		}

		//Listing 9-17
		private CheckedListBox AddDynamicListBox(Criteria iIndex, 
			int iLeft, 
			int iTop, 
			int iWidth, 
			int iHeight)
		{
			CheckedListBox oCheckedListBox;

			oCheckedListBox = new CheckedListBox();

			oCheckedListBox.Name = "ListBox" + iIndex.ToString();
			oCheckedListBox.Size = new Size(iWidth, iHeight);
			oCheckedListBox.Location = new Point(iLeft, iTop);

			this.Controls.Add(oCheckedListBox);

			return oCheckedListBox;
		}

		//Listing 9-18
		private Button AddDynamicListBoxButton(Criteria iIndex, 
			int iLeft, 
			int iTop, 
			int iWidth, 
			int iHeight, 
			string szCaption)
		{
			Button oButton;

			oButton = new Button();

			oButton.Name = "ListBoxButton" + iIndex.ToString();
			oButton.Size = new Size(iWidth, iHeight);
			oButton.Location = new Point(iLeft, iTop);
			oButton.Text = "Clear Selected " + szCaption;

			oButton.Click += new System.EventHandler(this.Button_Click);

			this.Controls.Add(oButton);

			return oButton;
		}

		//Listing 9-19
		private void Button_Click(object sender, System.EventArgs e)
		{		
			ListBoxManager oListBoxManager = null;
			CheckedListBox oListbox;
			int iIndex;

			foreach(object oItem in aControlList)
			{ 
				if (oItem is ListBoxManager)
				{
					oListBoxManager = ((ListBoxManager) oItem);

					if (oListBoxManager.ButtonControl == sender)
						break;
				}

			}

			oListbox = oListBoxManager.ListBoxControl; 

			for(iIndex = 0; iIndex <= oListbox.Items.Count - 1; iIndex++)
				oListbox.SetItemChecked(iIndex, false);				

		}	

		private void ShowTextBox(Criteria iIndex, int iLeft, int iTop, int iWidth, int iHeight, string szCaption)
		{
			TextBoxManager oTextBoxManager;

			oTextBoxManager = new TextBoxManager();
			
			oTextBoxManager.Index = iIndex;
			oTextBoxManager.LabelControl = AddDynamicLabel(iIndex, iLeft, iTop, szCaption);
			oTextBoxManager.TextBoxControl = AddDynamicTextBox(iIndex, oTextBoxManager.LabelControl.Left + oTextBoxManager.LabelControl.Width + 5, iTop, iWidth, iHeight);

			aControlList.Add(oTextBoxManager);
		}

		private TextBox AddDynamicTextBox(Criteria iIndex, int iLeft, int iTop, int iWidth, int iHeight)
		{
			TextBox oTextBox;

			oTextBox = new TextBox();

			oTextBox.Name = "TextBox" + iIndex.ToString();
			oTextBox.Size = new Size(iWidth, iHeight);
			oTextBox.Location = new Point(iLeft, iTop);

			this.Controls.Add(oTextBox);

			return oTextBox;
		}

		private void ShowDate(Criteria iIndex, int iLeft, int iTop, int iHeight, string szCaption)
		{
			DateManager oDateManager;

			oDateManager = new DateManager();
				
			oDateManager.Index = iIndex;
			oDateManager.LabelControl = AddDynamicLabel(iIndex, iLeft, iTop, szCaption);
			oDateManager.DateControl = AddDynamicDate(iIndex, oDateManager.LabelControl.Left + oDateManager.LabelControl.Width + 5, iTop, iHeight);

			aControlList.Add(oDateManager);
		}


		private DateTimePicker AddDynamicDate(Criteria iIndex, int iLeft, int iTop, int iHeight)
		{
			DateTimePicker oDateTimePicker;

			oDateTimePicker = new DateTimePicker();

			oDateTimePicker.Name = "Date" + iIndex.ToString();
			oDateTimePicker.Size = new Size(90, iHeight);
			oDateTimePicker.Location = new Point(iLeft, iTop);
			oDateTimePicker.Format = DateTimePickerFormat.Custom;
			oDateTimePicker.CustomFormat = "MM/dd/yyyy";
			oDateTimePicker.Text = DateTime.Now.Date.ToString();  

			this.Controls.Add(oDateTimePicker);

			return oDateTimePicker;

		}

		private void ShowDateRange(Criteria iIndex, int iLeft, int iTop, int iHeight, string szCaption)
		{
			DateRangeManager oDateRangeManager;

			oDateRangeManager = new DateRangeManager();
				
			oDateRangeManager.Index = iIndex;
			oDateRangeManager.LabelControl = AddDynamicLabel(iIndex, iLeft, iTop, szCaption);
			oDateRangeManager.DateFromControl = AddDynamicDate(iIndex, oDateRangeManager.LabelControl.Left + oDateRangeManager.LabelControl.Width + 5, iTop, iHeight);
			oDateRangeManager.DateToControl = AddDynamicDate(iIndex, oDateRangeManager.DateFromControl.Left + oDateRangeManager.DateFromControl.Width + 5, iTop, iHeight);
	
			aControlList.Add(oDateRangeManager);
		}

		private DateTimePicker AddDynamicDate(int iIndex, int iLeft, int iTop, int iHeight)
		{
			DateTimePicker oDateTimePicker;

			oDateTimePicker = new DateTimePicker();

			oDateTimePicker.Name = "DateFrom" + iIndex.ToString();
			oDateTimePicker.Size = new Size(90, iHeight);
			oDateTimePicker.Location = new Point(iLeft, iTop);
			oDateTimePicker.Format = DateTimePickerFormat.Custom;
			oDateTimePicker.CustomFormat = "MM/dd/yyyy";
			oDateTimePicker.Text = DateTime.Now.ToString();  

			this.Controls.Add(oDateTimePicker);

			return oDateTimePicker;

		}

		private void ShowComboBox(Criteria iIndex, 
			DataTable oDT, 
			string szID, 
			string szDescription, 
			int iLeft, 
			int iTop, 
			int iWidth, 
			int iHeight, 
			string szCaption)
		{
			ComboBoxManager oComboBoxManager;

			oComboBoxManager = new ComboBoxManager();
				
			oComboBoxManager.Index = iIndex;
			
			oComboBoxManager.LabelControl = 
				AddDynamicLabel(iIndex, iLeft, iTop, szCaption);

			iLeft = oComboBoxManager.LabelControl.Left + 
					oComboBoxManager.LabelControl.Width + 5;

			oComboBoxManager.ComboBoxControl = 
				AddDynamicComboBox(iIndex, iLeft, iTop, iWidth, iHeight);

			LoadCombo(oDT, oComboBoxManager.ComboBoxControl, szID, szDescription, true);

			aControlList.Add(oComboBoxManager);
		}

		private ComboBox AddDynamicComboBox(Criteria iIndex, int iLeft, int iTop, int iWidth, int iHeight)
		{
			ComboBox oComboBox;

			oComboBox = new ComboBox();

			oComboBox.Name = "ComboBox " + iIndex.ToString();
			oComboBox.Size = new Size(iWidth, iHeight);
			oComboBox.Location = new Point(iLeft, iTop);

			oComboBox.SelectedIndexChanged += new System.EventHandler(this.ComboBox_SelectedIndexChanged);

			this.Controls.Add(oComboBox);

			return oComboBox;
		}


		private void ShowCheckBox(Criteria iIndex, int iLeft, int iTop, int iWidth, int iHeight, string szCaption)
		{
			CheckBoxManager oCheckBoxManager;

			oCheckBoxManager = new CheckBoxManager();
				
			oCheckBoxManager.Index = iIndex;
			oCheckBoxManager.CheckBoxControl = AddDynamicCheckBox(iIndex, iLeft, iTop, iWidth, iHeight, szCaption);

			aControlList.Add(oCheckBoxManager);
		}

		private CheckBox AddDynamicCheckBox(Criteria iIndex, int iLeft, int iTop, int iWidth, int iHeight, string szCaption)
		{
			CheckBox oCheckBox;

			oCheckBox = new CheckBox();

			oCheckBox.Name = "CheckBox " + iIndex.ToString();
			oCheckBox.Text = szCaption;
			oCheckBox.Size = new Size(iWidth, iHeight);
			oCheckBox.Location = new Point(iLeft, iTop);

			this.Controls.Add(oCheckBox);

			return oCheckBox;
		}

		//Listing 4-2
		private string MakeDateParameter(DateTime dDate)
		{
			string szResult;

			szResult = "DateTime(" + dDate.Year.ToString() + "," + 
 									dDate.Month.ToString() + "," + 
									dDate.Day.ToString() + 
									",0,0,0)";

			return szResult;

		}

		public static void LoadCheckedListBox(CheckedListBox oCheckedListBox,
			DataTable oDT,
			string szID,
			string szDescription,
			bool bSelectAll)
		{

			oCheckedListBox.DisplayMember = "Text";
			oCheckedListBox.ValueMember = "Value";
			oCheckedListBox.Items.Clear();

			foreach (DataRow oDR in oDT.Rows)
			{
				oCheckedListBox.Items.Add(new ListItem(oDR[szID].ToString(), oDR[szDescription].ToString()));

				if (bSelectAll)
					oCheckedListBox.SetItemChecked(oCheckedListBox.Items.Count - 1, true);
			}

		}

		public static void LoadCombo(DataTable oDT,
			ComboBox oCombo, 
			string szID, 
			string szDescription, 
			bool bAddBlank)
		{
			oCombo.DisplayMember = "Text";
			oCombo.ValueMember = "Value";
			oCombo.Items.Clear();
			oCombo.DropDownStyle = ComboBoxStyle.DropDownList; 
			
			if (bAddBlank)
				oCombo.Items.Add(new ListItem("-1", String.Empty));

			foreach (DataRow oDR in oDT.Rows)
				oCombo.Items.Add(new ListItem(oDR[szID].ToString(), oDR[szDescription].ToString()));

		}

		//Listing 9-41
		public static string ParseIt(CheckedListBox oList, 
			bool bQuotes, int sCol, bool bCheckedOnly)
		{
			string szResult = String.Empty;
			string szQuotes = String.Empty;
			string szData = String.Empty;
			System.Text.StringBuilder oResult = new System.Text.StringBuilder();

			//use quotes or not
			szQuotes = (bQuotes) ? "'" : String.Empty;

			//count all or just the checked items
			IList oListItems = (bCheckedOnly) ? 
				(IList)oList.CheckedItems : (IList)oList.Items;

			foreach (object oItem in oListItems)
			{
				ListItem oCheckBoxItem = oItem as ListItem;

				if (oCheckBoxItem != null)
				{
					//depending on the column selected, extract the requested property
					switch (sCol)
					{
						case 0:
							szData = oCheckBoxItem.Value;
							break;

						case 1:
							szData = oCheckBoxItem.Text;
							break;

						case 2:
							szData = oCheckBoxItem.OtherText;
							break;
					}

					if (oResult.Length > 0)
						oResult.Append(",");

					oResult.AppendFormat("{0}{1}{2}", szQuotes, szData, szQuotes);
				}
			}
		    
			szResult = (oResult.Length == 0) ? oResult.ToString() : 
				string.Format("({0})", oResult.ToString());

			return szResult;
		}

		//Listing 9-20
		private string GetCriteria(Criteria iIndex)
		{
			ListBoxManager oListBoxManager = null;
			TextBoxManager oTextBoxManager = null;
			DateManager oDateManager = null;
			DateRangeManager oDateRangeManager = null;
			ComboBoxManager oComboBoxManager = null;
			CheckBoxManager oCheckBoxManager = null;
			CheckedListBox oListBox = null;			
			TextBox oTextBox = null;
			DateTimePicker oDateTimePicker = null;
			ComboBox oComboBox = null;
			CheckBox oCheckBox = null;
			ListItem oListItem = null;
			string szData = string.Empty;

			foreach(object oItem in aControlList)
			{ 
				if (oItem is ListBoxManager)
				{
					oListBoxManager = ((ListBoxManager) oItem);

					if (oListBoxManager.Index == iIndex)
					{
						oListBoxManager = ((ListBoxManager) oItem);

						oListBox = ((CheckedListBox) oListBoxManager.ListBoxControl);

						szData = ParseIt(oListBox, false, 0, true);
						break;
					}
				}

				if (oItem is TextBoxManager)
				{
					oTextBoxManager = ((TextBoxManager) oItem);

					if (oTextBoxManager.Index == iIndex)
					{
						oTextBoxManager = ((TextBoxManager) oItem);

						oTextBox = ((TextBox) oTextBoxManager.TextBoxControl);

						szData = oTextBox.Text;
						break;
					}
				}

				if (oItem is DateManager)
				{
					oDateManager = ((DateManager) oItem);

					if (oDateManager.Index == iIndex)
					{
						oDateManager = ((DateManager) oItem);

						oDateTimePicker = ((DateTimePicker) oDateManager.DateControl);

						szData = oDateTimePicker.Text; 
						break;
					}
				}

				if (oItem is DateRangeManager)
				{
					oDateRangeManager = ((DateRangeManager) oItem);

					if (oDateRangeManager.Index == iIndex)
					{
						oDateRangeManager = ((DateRangeManager) oItem);

						oDateTimePicker = ((DateTimePicker) oDateRangeManager.DateFromControl);

						szData = oDateTimePicker.Text; 

						oDateTimePicker = ((DateTimePicker) oDateRangeManager.DateToControl);

						szData = szData + ";" + oDateTimePicker.Text; 
						break;
					}
				}

				if (oItem is ComboBoxManager)
				{
					oComboBoxManager = ((ComboBoxManager) oItem);

					if (oComboBoxManager.Index == iIndex)
					{
						oComboBoxManager = ((ComboBoxManager) oItem);

						oComboBox = ((ComboBox) oComboBoxManager.ComboBoxControl);

						oListItem = ((ListItem) oComboBox.SelectedItem);

						szData = oListItem.Value; 
						break;
					}
				}

				if (oItem is CheckBoxManager)
				{
					oCheckBoxManager = ((CheckBoxManager) oItem);

					if (oCheckBoxManager.Index == iIndex)
					{
						oCheckBoxManager = ((CheckBoxManager) oItem);

						oCheckBox = ((CheckBox) oCheckBoxManager.CheckBoxControl);

						szData = oCheckBox.Checked.ToString(); 
						break;
					}
				}
			}	

			return szData;

		}

		private void cmdGetCriteria_Click(object sender, System.EventArgs e)
		{
			string szCriteria;

			string szDepartments = GetCriteria(Criteria.Departments); 
			string szEmployees = GetCriteria(Criteria.Employee);
			string szLastName = GetCriteria(Criteria.LastName);
			string szFirstName = GetCriteria(Criteria.FirstName);	
			string szBirthDate = GetCriteria(Criteria.BirthDate);
			string szTradingDates = GetCriteria(Criteria.TradingDates);
			string szDepartment = GetCriteria(Criteria.Department);
			string szPrintSummary = GetCriteria(Criteria.PrintSummary);

			szCriteria = "Departments = " + szDepartments + "\n" +
						"Employee = " + szEmployees + "\n" +
						"Last Name = " + szLastName + "\n" +
						"First Name = " + szFirstName + "\n" +
						"Birth Date = " + szBirthDate + "\n" +
						"Trading Dates = " + szTradingDates + "\n" +
						"Department = " + szDepartment + "\n" +
						"Print Summary = " + szPrintSummary;

			MessageBox.Show(szCriteria); 
		}


}

	//Listing 9-14
	class ControlManager
	{
		private Criteria iIndex;
		private Label oLabelControl;

		public Criteria Index
		{
			get { return iIndex; }
			set { iIndex = value; }
		}

		public Label LabelControl
		{
			get { return oLabelControl; }
			set { oLabelControl = value; }
		}

	}

	class ListBoxManager : ControlManager
	{
		private CheckedListBox oListBoxControl;
		private Button oButtonControl;

		public CheckedListBox ListBoxControl
		{
			get { return oListBoxControl; }
			set { oListBoxControl = value; }
		}

		public Button ButtonControl
		{
			get { return oButtonControl; }
			set { oButtonControl = value; }
		}
	}

	class TextBoxManager : ControlManager
	{
		private TextBox oTextBoxControl;

		public TextBox TextBoxControl
		{
			get { return oTextBoxControl; }
			set { oTextBoxControl = value; }
		}
	}

	class DateManager : ControlManager
	{
		private DateTimePicker oDateControl;

		public DateTimePicker DateControl
		{
			get { return oDateControl; }
			set { oDateControl = value; }
		}

	}

	class DateRangeManager : ControlManager
	{
		private DateTimePicker oDateFromControl;
		private DateTimePicker oDateToControl;

		public DateTimePicker DateFromControl
		{
			get { return oDateFromControl; }
			set { oDateFromControl = value; }
		}

		public DateTimePicker DateToControl
		{
			get { return oDateToControl; }
			set { oDateToControl = value; }
		}
	}

	class ComboBoxManager : ControlManager
	{
		private ComboBox oComboBoxControl;

		public ComboBox ComboBoxControl
		{
			get { return oComboBoxControl; }
			set { oComboBoxControl = value; }
		}

	}

	class CheckBoxManager : ControlManager
	{
		private CheckBox oCheckBoxControl;

		public CheckBox CheckBoxControl
		{
			get { return oCheckBoxControl; }
			set { oCheckBoxControl = value; }
		}

	}

	}
