using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data; 
using System.Xml;
using CrystalDecisions.Enterprise; 
using CrystalDecisions.Enterprise.Utils;  
using CrystalDecisions.CrystalReports.Engine;   

namespace BOXIProxyDemo
{
	/// <summary>
	/// Summary description for Security.
	/// </summary>
	public class frmSecurity : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button cmdCurrentlyLoggedInUsers;
		private System.Windows.Forms.Button cmdCheckRights;
		private System.Windows.Forms.Button cmdNTGroups;
		private System.Windows.Forms.Button cmdGetObjectRights;
		private System.Windows.Forms.Button cmdGetLimits;
		private System.Windows.Forms.Button cmdAssignRights;
		private System.Windows.Forms.Button cmdViewRights;
		private System.Windows.Forms.Button cmdAssignUserToGroup;
		private System.Windows.Forms.Button cmdCreateUserGroup;
		private System.Windows.Forms.Button cmdCreateUser;
		private System.Windows.Forms.Button cmdAssignRole;
		private System.Windows.Forms.Button cmdAssignSubGroups;
		private System.Windows.Forms.Button cmdAssignLimits;
		private System.Windows.Forms.ListBox lstUsers;
		private System.Windows.Forms.Button cmdGetUsers;
		private System.Windows.Forms.ListBox lstUserGroups;
		private System.Windows.Forms.Button cmdGetUserGroups;
		private System.Windows.Forms.DataGrid dataGrid1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmSecurity()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdCurrentlyLoggedInUsers = new System.Windows.Forms.Button();
			this.cmdCheckRights = new System.Windows.Forms.Button();
			this.cmdNTGroups = new System.Windows.Forms.Button();
			this.cmdGetObjectRights = new System.Windows.Forms.Button();
			this.cmdGetLimits = new System.Windows.Forms.Button();
			this.cmdAssignRights = new System.Windows.Forms.Button();
			this.cmdViewRights = new System.Windows.Forms.Button();
			this.cmdAssignUserToGroup = new System.Windows.Forms.Button();
			this.cmdCreateUserGroup = new System.Windows.Forms.Button();
			this.cmdCreateUser = new System.Windows.Forms.Button();
			this.cmdAssignRole = new System.Windows.Forms.Button();
			this.cmdAssignSubGroups = new System.Windows.Forms.Button();
			this.cmdAssignLimits = new System.Windows.Forms.Button();
			this.lstUsers = new System.Windows.Forms.ListBox();
			this.cmdGetUsers = new System.Windows.Forms.Button();
			this.lstUserGroups = new System.Windows.Forms.ListBox();
			this.cmdGetUserGroups = new System.Windows.Forms.Button();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// cmdCurrentlyLoggedInUsers
			// 
			this.cmdCurrentlyLoggedInUsers.Location = new System.Drawing.Point(440, 72);
			this.cmdCurrentlyLoggedInUsers.Name = "cmdCurrentlyLoggedInUsers";
			this.cmdCurrentlyLoggedInUsers.Size = new System.Drawing.Size(280, 24);
			this.cmdCurrentlyLoggedInUsers.TabIndex = 66;
			this.cmdCurrentlyLoggedInUsers.Text = "Currently Logged In Users";
			this.cmdCurrentlyLoggedInUsers.Click += new System.EventHandler(this.cmdCurrentlyLoggedInUsers_Click);
			// 
			// cmdCheckRights
			// 
			this.cmdCheckRights.Location = new System.Drawing.Point(152, 8);
			this.cmdCheckRights.Name = "cmdCheckRights";
			this.cmdCheckRights.Size = new System.Drawing.Size(136, 24);
			this.cmdCheckRights.TabIndex = 65;
			this.cmdCheckRights.Text = "Check Rights";
			this.cmdCheckRights.Click += new System.EventHandler(this.cmdCheckRights_Click);
			// 
			// cmdNTGroups
			// 
			this.cmdNTGroups.Location = new System.Drawing.Point(584, 8);
			this.cmdNTGroups.Name = "cmdNTGroups";
			this.cmdNTGroups.Size = new System.Drawing.Size(136, 24);
			this.cmdNTGroups.TabIndex = 64;
			this.cmdNTGroups.Text = "NT Groups";
			this.cmdNTGroups.Click += new System.EventHandler(this.cmdNTGroups_Click);
			// 
			// cmdGetObjectRights
			// 
			this.cmdGetObjectRights.Location = new System.Drawing.Point(152, 72);
			this.cmdGetObjectRights.Name = "cmdGetObjectRights";
			this.cmdGetObjectRights.Size = new System.Drawing.Size(136, 24);
			this.cmdGetObjectRights.TabIndex = 63;
			this.cmdGetObjectRights.Text = "Get Object Rights";
			this.cmdGetObjectRights.Click += new System.EventHandler(this.cmdGetObjectRights_Click);
			// 
			// cmdGetLimits
			// 
			this.cmdGetLimits.Location = new System.Drawing.Point(152, 40);
			this.cmdGetLimits.Name = "cmdGetLimits";
			this.cmdGetLimits.Size = new System.Drawing.Size(136, 24);
			this.cmdGetLimits.TabIndex = 62;
			this.cmdGetLimits.Text = "Get Limits";
			this.cmdGetLimits.Click += new System.EventHandler(this.cmdGetLimits_Click);
			// 
			// cmdAssignRights
			// 
			this.cmdAssignRights.Location = new System.Drawing.Point(440, 40);
			this.cmdAssignRights.Name = "cmdAssignRights";
			this.cmdAssignRights.Size = new System.Drawing.Size(136, 24);
			this.cmdAssignRights.TabIndex = 61;
			this.cmdAssignRights.Text = "Assign Rights";
			this.cmdAssignRights.Click += new System.EventHandler(this.cmdAssignRights_Click);
			// 
			// cmdViewRights
			// 
			this.cmdViewRights.Location = new System.Drawing.Point(440, 8);
			this.cmdViewRights.Name = "cmdViewRights";
			this.cmdViewRights.Size = new System.Drawing.Size(136, 24);
			this.cmdViewRights.TabIndex = 60;
			this.cmdViewRights.Text = "View Rights";
			this.cmdViewRights.Click += new System.EventHandler(this.cmdViewRights_Click);
			// 
			// cmdAssignUserToGroup
			// 
			this.cmdAssignUserToGroup.Location = new System.Drawing.Point(8, 72);
			this.cmdAssignUserToGroup.Name = "cmdAssignUserToGroup";
			this.cmdAssignUserToGroup.Size = new System.Drawing.Size(136, 24);
			this.cmdAssignUserToGroup.TabIndex = 59;
			this.cmdAssignUserToGroup.Text = "Assign User To Group";
			this.cmdAssignUserToGroup.Click += new System.EventHandler(this.cmdAssignUserToGroup_Click);
			// 
			// cmdCreateUserGroup
			// 
			this.cmdCreateUserGroup.Location = new System.Drawing.Point(8, 40);
			this.cmdCreateUserGroup.Name = "cmdCreateUserGroup";
			this.cmdCreateUserGroup.Size = new System.Drawing.Size(136, 24);
			this.cmdCreateUserGroup.TabIndex = 58;
			this.cmdCreateUserGroup.Text = "Create User Group";
			this.cmdCreateUserGroup.Click += new System.EventHandler(this.cmdCreateUserGroup_Click);
			// 
			// cmdCreateUser
			// 
			this.cmdCreateUser.Location = new System.Drawing.Point(8, 8);
			this.cmdCreateUser.Name = "cmdCreateUser";
			this.cmdCreateUser.Size = new System.Drawing.Size(136, 24);
			this.cmdCreateUser.TabIndex = 57;
			this.cmdCreateUser.Text = "Create User";
			this.cmdCreateUser.Click += new System.EventHandler(this.cmdCreateUser_Click);
			// 
			// cmdAssignRole
			// 
			this.cmdAssignRole.Location = new System.Drawing.Point(296, 72);
			this.cmdAssignRole.Name = "cmdAssignRole";
			this.cmdAssignRole.Size = new System.Drawing.Size(136, 24);
			this.cmdAssignRole.TabIndex = 69;
			this.cmdAssignRole.Text = "Assign Role";
			this.cmdAssignRole.Click += new System.EventHandler(this.cmdAssignRole_Click);
			// 
			// cmdAssignSubGroups
			// 
			this.cmdAssignSubGroups.Location = new System.Drawing.Point(296, 40);
			this.cmdAssignSubGroups.Name = "cmdAssignSubGroups";
			this.cmdAssignSubGroups.Size = new System.Drawing.Size(136, 24);
			this.cmdAssignSubGroups.TabIndex = 68;
			this.cmdAssignSubGroups.Text = "Assign SubGroups";
			this.cmdAssignSubGroups.Click += new System.EventHandler(this.cmdAssignSubGroups_Click);
			// 
			// cmdAssignLimits
			// 
			this.cmdAssignLimits.Location = new System.Drawing.Point(296, 8);
			this.cmdAssignLimits.Name = "cmdAssignLimits";
			this.cmdAssignLimits.Size = new System.Drawing.Size(136, 24);
			this.cmdAssignLimits.TabIndex = 67;
			this.cmdAssignLimits.Text = "Assign Limits";
			this.cmdAssignLimits.Click += new System.EventHandler(this.cmdAssignLimits_Click);
			// 
			// lstUsers
			// 
			this.lstUsers.Location = new System.Drawing.Point(208, 112);
			this.lstUsers.Name = "lstUsers";
			this.lstUsers.Size = new System.Drawing.Size(192, 134);
			this.lstUsers.TabIndex = 73;
			// 
			// cmdGetUsers
			// 
			this.cmdGetUsers.Location = new System.Drawing.Point(208, 256);
			this.cmdGetUsers.Name = "cmdGetUsers";
			this.cmdGetUsers.Size = new System.Drawing.Size(192, 24);
			this.cmdGetUsers.TabIndex = 72;
			this.cmdGetUsers.Text = "Get Users";
			this.cmdGetUsers.Click += new System.EventHandler(this.cmdGetUsers_Click);
			// 
			// lstUserGroups
			// 
			this.lstUserGroups.Location = new System.Drawing.Point(8, 112);
			this.lstUserGroups.Name = "lstUserGroups";
			this.lstUserGroups.Size = new System.Drawing.Size(192, 134);
			this.lstUserGroups.TabIndex = 71;
			// 
			// cmdGetUserGroups
			// 
			this.cmdGetUserGroups.Location = new System.Drawing.Point(8, 256);
			this.cmdGetUserGroups.Name = "cmdGetUserGroups";
			this.cmdGetUserGroups.Size = new System.Drawing.Size(192, 24);
			this.cmdGetUserGroups.TabIndex = 70;
			this.cmdGetUserGroups.Text = "Get User Groups";
			this.cmdGetUserGroups.Click += new System.EventHandler(this.cmdGetUserGroups_Click);
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(8, 312);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(776, 256);
			this.dataGrid1.TabIndex = 74;
			// 
			// frmSecurity
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(792, 574);
			this.Controls.Add(this.dataGrid1);
			this.Controls.Add(this.lstUsers);
			this.Controls.Add(this.cmdGetUsers);
			this.Controls.Add(this.lstUserGroups);
			this.Controls.Add(this.cmdGetUserGroups);
			this.Controls.Add(this.cmdAssignRole);
			this.Controls.Add(this.cmdAssignSubGroups);
			this.Controls.Add(this.cmdAssignLimits);
			this.Controls.Add(this.cmdCurrentlyLoggedInUsers);
			this.Controls.Add(this.cmdCheckRights);
			this.Controls.Add(this.cmdNTGroups);
			this.Controls.Add(this.cmdGetObjectRights);
			this.Controls.Add(this.cmdGetLimits);
			this.Controls.Add(this.cmdAssignRights);
			this.Controls.Add(this.cmdViewRights);
			this.Controls.Add(this.cmdAssignUserToGroup);
			this.Controls.Add(this.cmdCreateUserGroup);
			this.Controls.Add(this.cmdCreateUser);
			this.Name = "frmSecurity";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Security";
			this.Load += new System.EventHandler(this.frmSecurity_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void frmSecurity_Load(object sender, System.EventArgs e)
		{
		
		}

		private void cmdGetUserGroups_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataSet oDS;

			oBOXIWebService = new localhost.BOXIWebService();

			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;     

			oDS = oBOXIWebService.GetUserGroups("Dev");

			oBOXIWebService = null;

			Shared.LoadListBox(lstUserGroups, oDS.Tables[0], "ID", "Name");
				
		}

		private void cmdGetUsers_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataSet oDS;
			string szUserGroup;
			ListItem oListItem;

			oListItem = ((ListItem) lstUserGroups.SelectedItem);  

			szUserGroup = oListItem.Value;

			oBOXIWebService = new localhost.BOXIWebService();

			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;     

			oDS = oBOXIWebService.GetUsers("Dev", szUserGroup);
 

			oBOXIWebService = null;	

			Shared.LoadListBox(lstUsers, oDS.Tables[0], "ID", "Name");
		
		}

		private void cmdCreateUser_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			string szUserID = oBOXIWebService.CreateUser("Dev", 
				"cganz", 
				"VB.NET/C# Developer", 
				"Carl Ganz, Jr.", 
				"seton.software@verizon.net", 
				false, 
				true, 
				"mypass");
		}

		private void cmdCreateUserGroup_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			string szUserGroupID = oBOXIWebService.CreateUserGroup("Dev", "FID Report Administrators", "Key users of Fixed Income reports"); 
		}

		private void cmdAssignUserToGroup_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.AssignUserToGroup("Dev", "1041", "1050"); 		
		}

		private void cmdViewRights_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataTable oDT;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			//oDT = oBOXIWebService.GetSecurityRights("Dev", "1041").Tables[0];

			//dataGrid1.DataSource = oDT;
		}

		//Listing 10-7
		private void cmdAssignRights_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			localhost.CeSystemRights[] aRights = new localhost.CeSystemRights[3];

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			aRights[0] = localhost.CeSystemRights.ceRightAdd;
			aRights[1] = localhost.CeSystemRights.ceRightEdit;
			aRights[2] = localhost.CeSystemRights.ceRightScheduleOnBehalfOf;

			oBOXIWebService.AssignSecurityRights("Dev", "1266", "1050", aRights);
		}

		private void cmdGetLimits_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataTable oDT;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oDT = oBOXIWebService.GetReportLimits("Dev", "575").Tables[0]; 	

			dataGrid1.DataSource = oDT;
		}

		private void cmdGetObjectRights_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			string szData;

			this.Cursor = Cursors.WaitCursor; 

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			szData = oBOXIWebService.GetRightsForObject("Dev", "1266");

			XmlDocument oXmlDocument;

			oXmlDocument = new XmlDocument();

			oXmlDocument.LoadXml(szData);
 
			oXmlDocument.Save(@"c:\temp\right.xml"); 	

			this.Cursor = Cursors.Default; 

		}

		//Listing 10-19
		private void cmdNTGroups_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			string szData;

			this.Cursor = Cursors.WaitCursor; 

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

//			if (oBOXIWebService.IsAuthorizedForReport("Dev", "1266", @"DOMAIN\GANZC"))
//				MessageBox.Show ("Hooray! You're in!");
//			else
//				MessageBox.Show ("Sorry, you're out of luck.");

		}

		//Listing 10-14
		private void cmdAssignLimits_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			int[][] aLimits = new int[2][];

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			//Using jagged arrays here as multi-dimensional 
			//arrays cannot be passed to web services
			aLimits[0] = new int[2];
			aLimits[1] = new int[2];

			aLimits[0][0] = ((int) CeSystemLimits.ceLimitMaxInstanceAge);
			aLimits[0][1] = 30;

			aLimits[1][0] = ((int) CeSystemLimits.ceLimitMaxInstanceCountPerUser);
			aLimits[1][1] = 50;

			oBOXIWebService.AssignSecurityLimits("Dev", "1266", "1050", aLimits, 100);
		}

		private void cmdAssignSubGroups_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;
		
			//The update to the relationship named UserGroup-User with id number 128 is 
			//not allowed because the object with id number 1050 will be part of a cycle.
			
			//SELECT *
			//FROM CI_SYSTEMOBJECTS 
			//WHERE SI_ID = 128

			oBOXIWebService.AssignSubGroup("Dev", "6103", 2); 
		}

		private void cmdAssignRole_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oBOXIWebService.AssignRole("Dev", 1041, "1266", localhost.CeRole.ceRoleNoAccess);    
		}

		//Listing 10-12
		private void cmdCheckRights_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			int[] aRights = new int[10]; 
			object aRightsStatus; 
			object[] aRightsStatusData;

			aRights[0] = ((int) CeSystemRights.ceRightAdd); 
			aRights[1] = ((int) CeSystemRights.ceRightCopy);
			aRights[2] = ((int) CeSystemRights.ceRightDelete);
			aRights[3] = ((int) CeSystemRights.ceRightDeleteInstance);
			aRights[4] = ((int) CeSystemRights.ceRightEdit);
			aRights[5] = ((int) CeSystemRights.ceRightModifyRights);
			aRights[6] = ((int) CeSystemRights.ceRightPauseResumeSchedule);
			aRights[7] = ((int) CeSystemRights.ceRightPickMachines);
			aRights[8] = ((int) CeSystemRights.ceRightReschedule);
			aRights[9] = ((int) CeSystemRights.ceRightSchedule);

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			aRightsStatus = oBOXIWebService.CheckRights("Dev", "1266", aRights);   	

			aRightsStatusData = ((object[]) aRightsStatus); 
		}

		private void cmdCurrentlyLoggedInUsers_Click(object sender, System.EventArgs e)
		{
			localhost.BOXIWebService oBOXIWebService;
			DataTable oDT;

			oBOXIWebService = new localhost.BOXIWebService();
			oBOXIWebService.Credentials = System.Net.CredentialCache.DefaultCredentials;

			oDT = oBOXIWebService.LoggedOnUserInformation("Dev").Tables[0];

			dataGrid1.DataSource = oDT;		
		}

	}
}
