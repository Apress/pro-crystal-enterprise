using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml;
using System.ServiceProcess;
using System.Web.Mail;  
using System.Threading;

 
namespace BOXIProxyDemo
{	
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMainMenu : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button cmdRAS;
		private System.Windows.Forms.Button frmIntroduction;
		private System.Windows.Forms.Button cmdScheduling;
		private System.Windows.Forms.Button cmdEnterprise;
		private System.Windows.Forms.Button cmdSecurity;
		private System.Windows.Forms.Button cmdServer;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMainMenu()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();	
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdRAS = new System.Windows.Forms.Button();
			this.frmIntroduction = new System.Windows.Forms.Button();
			this.cmdScheduling = new System.Windows.Forms.Button();
			this.cmdEnterprise = new System.Windows.Forms.Button();
			this.cmdSecurity = new System.Windows.Forms.Button();
			this.cmdServer = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// cmdRAS
			// 
			this.cmdRAS.Location = new System.Drawing.Point(64, 176);
			this.cmdRAS.Name = "cmdRAS";
			this.cmdRAS.Size = new System.Drawing.Size(136, 24);
			this.cmdRAS.TabIndex = 48;
			this.cmdRAS.Text = "RAS";
			this.cmdRAS.Click += new System.EventHandler(this.cmdRAS_Click);
			// 
			// frmIntroduction
			// 
			this.frmIntroduction.Location = new System.Drawing.Point(64, 16);
			this.frmIntroduction.Name = "frmIntroduction";
			this.frmIntroduction.Size = new System.Drawing.Size(136, 24);
			this.frmIntroduction.TabIndex = 49;
			this.frmIntroduction.Text = "Introduction";
			this.frmIntroduction.Click += new System.EventHandler(this.frmIntroduction_Click);
			// 
			// cmdScheduling
			// 
			this.cmdScheduling.Location = new System.Drawing.Point(64, 48);
			this.cmdScheduling.Name = "cmdScheduling";
			this.cmdScheduling.Size = new System.Drawing.Size(136, 24);
			this.cmdScheduling.TabIndex = 50;
			this.cmdScheduling.Text = "Scheduling";
			this.cmdScheduling.Click += new System.EventHandler(this.cmdScheduling_Click);
			// 
			// cmdEnterprise
			// 
			this.cmdEnterprise.Location = new System.Drawing.Point(64, 80);
			this.cmdEnterprise.Name = "cmdEnterprise";
			this.cmdEnterprise.Size = new System.Drawing.Size(136, 24);
			this.cmdEnterprise.TabIndex = 51;
			this.cmdEnterprise.Text = "Enterprise";
			this.cmdEnterprise.Click += new System.EventHandler(this.cmdEnterprise_Click);
			// 
			// cmdSecurity
			// 
			this.cmdSecurity.Location = new System.Drawing.Point(64, 112);
			this.cmdSecurity.Name = "cmdSecurity";
			this.cmdSecurity.Size = new System.Drawing.Size(136, 24);
			this.cmdSecurity.TabIndex = 52;
			this.cmdSecurity.Text = "Security";
			this.cmdSecurity.Click += new System.EventHandler(this.cmdSecurity_Click);
			// 
			// cmdServer
			// 
			this.cmdServer.Location = new System.Drawing.Point(64, 144);
			this.cmdServer.Name = "cmdServer";
			this.cmdServer.Size = new System.Drawing.Size(136, 24);
			this.cmdServer.TabIndex = 53;
			this.cmdServer.Text = "Server";
			this.cmdServer.Click += new System.EventHandler(this.cmdServer_Click);
			// 
			// frmMainMenu
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(272, 238);
			this.Controls.Add(this.cmdServer);
			this.Controls.Add(this.cmdSecurity);
			this.Controls.Add(this.cmdEnterprise);
			this.Controls.Add(this.cmdScheduling);
			this.Controls.Add(this.frmIntroduction);
			this.Controls.Add(this.cmdRAS);
			this.Name = "frmMainMenu";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "BusinessObjects XI Demo";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMainMenu());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{ 			

		}

		private void cmdRAS_Click(object sender, System.EventArgs e)
		{
			frmRAS oRAS;

			oRAS = new frmRAS();

			oRAS.Show();
		}

		private void frmIntroduction_Click(object sender, System.EventArgs e)
		{
			frmIntroduction oIntroduction;

			oIntroduction = new frmIntroduction();

			oIntroduction.Show();

		}

		private void cmdScheduling_Click(object sender, System.EventArgs e)
		{
			frmScheduling oScheduling;

			oScheduling = new frmScheduling();

			oScheduling.Show();
		}

		private void cmdEnterprise_Click(object sender, System.EventArgs e)
		{
			frmEnterprise oEnterprise;

			oEnterprise = new frmEnterprise();

			oEnterprise.Show();		
		}

		private void cmdSecurity_Click(object sender, System.EventArgs e)
		{
			frmSecurity oSecurity;

			oSecurity = new frmSecurity();

			oSecurity.Show();			
		}

		private void cmdServer_Click(object sender, System.EventArgs e)
		{
			frmServer oServer;

			oServer = new frmServer();

			oServer.Show();			
		}

	}

}
