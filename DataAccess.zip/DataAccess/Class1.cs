using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.OracleClient;

namespace DataAccess
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class DataAccess
	{

		public DataTable GetEmployeesSQLServer(string szCountry, int iReportsTo)
		{
			SqlConnection oSqlConnection = null;
			SqlCommand oSqlCommand = null;
			SqlDataAdapter oSqlDataAdapter = null;
			DataSet oDS;
			DataTable oDT;
			string szConnect;

			szConnect = "Data Source=(local);Initial catalog=Northwind;" +
						"Integrated security=SSPI;Persist security info=False";

			oSqlConnection = new SqlConnection(szConnect);
			oSqlConnection.Open();
					
			oSqlCommand = new SqlCommand(); 
			oSqlCommand.CommandText = "spc_sel_Employees";
			oSqlCommand.CommandType = CommandType.StoredProcedure;
			oSqlCommand.Connection = oSqlConnection;

			oSqlCommand.Parameters.Add("@Country", 
				SqlDbType.VarChar).Value = szCountry;
			oSqlCommand.Parameters.Add("@ReportsTo", 
				SqlDbType.Int).Value = iReportsTo;

			oDS = new DataSet();

			oSqlDataAdapter = new SqlDataAdapter(oSqlCommand);
			oSqlDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
			oSqlDataAdapter.Fill(oDS);

			oDT = oDS.Tables[0]; 

			return oDT;
		}

		public DataTable GetEmployeesOracle(string szJob)
		{
			OracleConnection oOracleConnection = null;
			OracleCommand oOracleCommand = null;
			OracleDataAdapter oOracleDataAdapter = null;
			DataSet oDS;
			DataTable oDT;
			string szConnect;

			szConnect = "user id=scott;data source=SETON;password=tiger;";

			oOracleConnection = new OracleConnection(szConnect);
			oOracleConnection.Open();
					
			oOracleCommand = new OracleCommand(); 
			oOracleCommand.CommandText = "spc_sel_Employees";
			oOracleCommand.CommandType = CommandType.StoredProcedure;
			oOracleCommand.Connection = oOracleConnection;

			oOracleCommand.Parameters.Add("P_IN_JOB", OracleType.VarChar).Value = szJob;
			oOracleCommand.Parameters.Add("P_OUT_REFCURSOR", 
				OracleType.Cursor).Direction = ParameterDirection.Output; 

			oDS = new DataSet();

			oOracleDataAdapter = new OracleDataAdapter(oOracleCommand);
			oOracleDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
			oOracleDataAdapter.Fill(oDS);

			oDT = oDS.Tables[0]; 


			//If bug appears
			DataTable oEmployeeDT = new DataTable();

			oEmployeeDT.Columns.Add(new DataColumn("EMPNO", typeof(string)));
			oEmployeeDT.Columns.Add(new DataColumn("ENAME", typeof(string)));
			oEmployeeDT.Columns.Add(new DataColumn("JOB", typeof(string)));
			oEmployeeDT.Columns.Add(new DataColumn("HIREDATE", typeof(System.DateTime)));
			oEmployeeDT.Columns.Add(new DataColumn("SAL", typeof(string)));

//
//			return oEmployeeDT;
			

			return oDT;

		}

	}
}
