using System; 
using System.Xml;
using System.Data;  
using CrystalDecisions.Enterprise; 
using CrystalDecisions.Enterprise.Desktop;

namespace ScheduledReports
{
	public class ScheduledReports
	{
		//Listing 9-12
		static void Main(string[] args) 
		{
			string szFolder = "Human Resources"; //args[0];
			string szReport = "Employee"; //args[1];

			RunReports(szFolder, szReport);
		}

		//Listing 9-13
		static void RunReports(string szFolder, string szReport)
		{
			InfoStore oInfoStore = null; 
			InfoObjects oFolders = null; 
			InfoObject oFolder = null; 
			InfoObjects oReports = null; 
			InfoObject oReport = null; 
			EnterpriseSession oEnterpriseSession = null;
			EnterpriseService oEnterpriseService = null;
			SchedulingInfo oSchedulingInfo = null; 
			ReportParameters oReportParameters = null; 
			ReportParameterSingleValue oReportParameterSingleValue = null; 
			ReportFormatOptions oReportFormatOpts = null; 
			PluginInterface oPluginInterface = null; 
			Report oReportPlugIn = null; 
			DataTable oDT;
			string szSQL = string.Empty; 
			string szErrorCode = string.Empty; 

			oEnterpriseSession = GetIdentity(null, null, null, null, "Dev");			

			oEnterpriseService = oEnterpriseSession.GetService("", "InfoStore");

			oInfoStore = new InfoStore(oEnterpriseService);

			//Get the folder object
			szSQL = "Select SI_ID, SI_NAME " + 
				"From CI_INFOOBJECTS " + 
				"Where SI_NAME = '" + szFolder + "' " +
				"AND SI_KIND = 'Folder'"; 

			oFolders = oInfoStore.Query(szSQL); 
			oFolder = oFolders[1]; 	

			//Now get the report that beongs to the requested folder
			szSQL = "Select SI_ID, SI_NAME, SI_PROCESSINFO.SI_PROMPTS " + 
				"From CI_INFOOBJECTS " + 
				"Where SI_NAME = '" + szReport + "' " +
				"AND SI_PARENT_FOLDER = " + oFolder.Properties["SI_ID"].ToString() +  
				" AND SI_KIND = 'CrystalReport'";

			oReports = oInfoStore.Query(szSQL); 
			oReport = oReports[1]; 	

			//Extract the Data and iterate through each row
			oDT = GetCountries();

			foreach(DataRow oDR in oDT.Rows)
			{			
				//get the report plug in reference
				oPluginInterface = oReport.GetPluginInterface(""); 
				oReportPlugIn = new Report(oPluginInterface); 
						
				//Retrieve the parameters collection
				oReportParameters = oReportPlugIn.ReportParameters; 
				
				//Create parameter objects and add the to the parameters collection
				oReportParameterSingleValue = oReportParameters[1].CreateSingleValue(); 
				oReportParameterSingleValue.Value = oDR["Code"].ToString(); 
				oReportParameters[1].CurrentValues.Clear(); 
				oReportParameters[1].CurrentValues.Add(oReportParameterSingleValue); 

				//Schedule the report to run once and immediately
				oSchedulingInfo = oReport.SchedulingInfo; 
				oSchedulingInfo.RightNow = true; 				
				oSchedulingInfo.Type = CeScheduleType.ceScheduleTypeOnce; 

				//Let's send the output to Adode Acrobat
				oReportFormatOpts = oReportPlugIn.ReportFormatOptions; 
				oReportFormatOpts.Format = CeReportFormat.ceFormatPDF;

				//Then schedule this report and move onto the next parameter
				oInfoStore.Schedule(oReports); 
			}

			oEnterpriseSession.Logoff();
 
			oInfoStore = null; 
			oFolders = null; 
			oFolder = null; 
			oReports = null; 
			oReport = null; 
			oEnterpriseSession = null;
			oEnterpriseService = null;
			oSchedulingInfo = null; 
			oReportParameters = null; 
			oReportParameterSingleValue = null; 
			oReportFormatOpts = null; 
			oPluginInterface = null; 
			oReportPlugIn = null; 
		}

		static DataTable GetCountries()
		{
			DataTable oDT;
			DataRow oDR;

			oDT = new DataTable();

			oDT.Columns.Add(new DataColumn("Code"));   
			oDT.Columns.Add(new DataColumn("Description"));
		
			oDR = oDT.NewRow(); 

			oDR["Code"] = "USA";
			oDR["Description"] = "United States";
		
			oDT.Rows.Add(oDR);

			oDR = oDT.NewRow(); 

			oDR["Code"] = "UK";
			oDR["Description"] = "United Kingdom";

			oDT.Rows.Add(oDR); 

			oDR = oDT.NewRow(); 

			oDR["Code"] = "SPN";
			oDR["Description"] = "Spain";

			oDT.Rows.Add(oDR); 

			oDR = oDT.NewRow(); 

			oDR["Code"] = "POR";
			oDR["Description"] = "Portugal";

			oDT.Rows.Add(oDR); 

			oDR = oDT.NewRow(); 

			oDR["Code"] = "FRA";
			oDR["Description"] = "France";

			oDT.Rows.Add(oDR); 

			oDR = oDT.NewRow(); 

			oDR["Code"] = "GER";
			oDR["Description"] = "Germany";

			oDT.Rows.Add(oDR); 

			return oDT;		
		}


		#region Logon methods
		
		static EnterpriseSession GetIdentity(string szUserID, 
			string szPassword, 
			string szSystem, 
			string szAuthentication, 
			string szServer)
		{
			EnterpriseSession oEnterpriseSession = null;
			SessionMgr oSessionMgr = null;
			
			//Instantiate new SessionMgr object
			oSessionMgr = new SessionMgr();
			
			//If server code - Dev, QA, Prod, etc - was used obtain 
			//connection information from XML file
			if (szServer != null)
			{
				szUserID = GetCEUserID(szServer);
				szPassword = GetCEPassword(szServer);
				szSystem = GetCEAPS(szServer);
				szAuthentication = GetCEAuthentication(szServer);
			}

			//Use your decryption technology to decrypt password
			//szPassword = DecryptData(szPassword);

			//Connect to BO XI
			oEnterpriseSession = oSessionMgr.Logon(szUserID, szPassword, 
				szSystem, szAuthentication);

			oSessionMgr.Dispose(); 

			return oEnterpriseSession;

		}

		static string GetCEUserID(string szServer)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			string szResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load("settings.xml");

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/UserID");
			szResult = oXmlNode.InnerText;

			oXmlDocument = null;
			oXmlNode = null;

			return szResult;
		}

		static string GetCEPassword(string szServer)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			string szResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load("settings.xml");

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/Password");
			szResult = oXmlNode.InnerText;

			oXmlDocument = null;
			oXmlNode = null;

			return szResult;
		}

		static string GetCEAPS(string szServer)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			string szResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load("settings.xml");

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/APS");
			szResult = oXmlNode.InnerText;

			oXmlDocument = null;
			oXmlNode = null;

			return szResult;
		}

		static string GetCEAuthentication(string szServer)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			string szResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load("settings.xml");

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/Authentication");
			szResult = oXmlNode.InnerText;

			oXmlDocument = null;
			oXmlNode = null;

			return szResult;
		}

		static string GetCEWorkingDirectory(string szServer)
		{
			XmlDocument oXmlDocument;
			XmlNode oXmlNode;
			string szResult;

			oXmlDocument = new XmlDocument();
			oXmlDocument.Load("settings.xml");

			oXmlNode = oXmlDocument.SelectSingleNode("/CrystalEnterprise/" + szServer + "/WorkingDirectory");
			szResult = oXmlNode.InnerText;

			if (szResult.Substring(szResult.Length - 1, 1) != @"\")
				szResult = szResult + @"\";
  
			oXmlDocument = null;
			oXmlNode = null;

			return szResult;
		}

		#endregion

	}
}
